package com.intern.auditor;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.intern.entity.User;

@Component
public class MockAuditorAwareService implements AuditorAware<User> {

	  private User currentAuditor;

	  @Override
	  public User getCurrentAuditor() {
	    return currentAuditor;
	  }

	  public void setCurrentAuditor(User user) {
	    currentAuditor = user;
	  }
}

package com.intern.utils;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;

import org.springframework.stereotype.Repository;

@Repository
public class MockMetamodelRepository {

	@PersistenceContext
	private EntityManager entityManager;

	private MockMetamodelRepository() {
		// private constructor to prevent instantiating.
	}

	public Set<EntityType<?>> getEntityTypes() {
		Metamodel model = entityManager.getEntityManagerFactory().getMetamodel();
		return model.getEntities();
	}

}

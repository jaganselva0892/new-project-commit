package com.intern.base;

public class BaseTestCase {

}

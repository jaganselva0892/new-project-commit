/*! Aalam Info Solutions | (c) 2016 Aalamsoft */

(function(a) {
	(jQuery.browser = jQuery.browser || {}).mobile = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i
			.test(a)
			|| /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i
					.test(a.substr(0, 4));
})(navigator.userAgent || navigator.vendor || window.opera);
function triventAjaxError() {
	alert("We're sorry. An error has occurred.");
}
function emptyOptions(elementName) {
	$('#' + elementName).empty();
	$('#' + elementName).append(
			$('<option>').text('-- Select One --').attr('value', ''));
}
function populateOptions(elementName, data) {
	$.each(data, function(index, value) {
		$('#' + elementName).append(
				$('<option>').text(value).attr('value', value));
	});
}
function populateMapOptions(elementName, mapData) {
	for ( var key in mapData) {
		$('#' + elementName).append(
				$('<option>').text(mapData[key]).attr('value', key));
	}
}
function refreshElement(element) {
	$('#' + element)
			.addClass('bounce animated')
			.one(
					'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',
					function() {
						$(this).removeClass('bounce animated');
					});
}
function submitForm(formId) {
	$('#' + formId).submit();
}
function toggleDiv(divId) {
	$('#' + divId).toggleClass('hidden');
}
function show(divId) {
	$('#' + divId).show();
}
function hide(divId) {
	$('#' + divId).hide();
}
function enableEditing(elementId) {
	$('#' + elementId).attr('readonly', false);
}
function showModel(modelName) {
	$('#' + modelName).modal({
		show : true
	});
}
function enableValidation(formName) {
	$('#' + formName).parsley('validate');
}
function initDatePicker() {
	$('.datepicker').datepicker();
	$(".datepicker").keypress(function(event) {
		event.preventDefault();
	});
}
function initChosen() {
	if ($.isFunction($.fn.chosen)) {
		$(".chosen").chosen({
			width : "100%"
		});
	}
}
function initBootstrapSwitch(element) {
	$('#' + element + " .bootstrap-switch").bootstrapSwitch({
		size : "small",
		onText : "Yes",
		offText : "No"
	});
}
var triventCommon = function() {
	function initCopyRightYear() {
		$("#copyRightYear").html((new Date).getFullYear());
	}
	function initDeleteModel() {
		$("#confirmDelete").on(
				"show.bs.modal",
				function(e) {
					$message = $(e.relatedTarget).attr("data-message");
					$(this).find(".modal-body p").text($message);
					$title = $(e.relatedTarget).attr("data-title");
					$(this).find(".modal-title").text($title);
					$("#confirmDelete").find(".modal-footer .btn-danger")
							.on(
									"click",
									function() {
										location.href = $(e.relatedTarget)
												.data("href");
									})
				})
	}
	function initToastr() {
		/*
		 * toastr.options = { "positionClass" : "toast-bottom-full-width" }
		 */
		toastr.options = {
			"closeButton" : true,
			"debug" : false,
			"newestOnTop" : false,
			"progressBar" : false,
			"positionClass" : "toast-bottom-right",
			"preventDuplicates" : false,
			"showDuration" : "300",
			"hideDuration" : "1000",
			"timeOut" : "5000",
			"extendedTimeOut" : "5000",
			"showEasing" : "swing",
			"hideEasing" : "linear",
			"showMethod" : "fadeIn",
			"hideMethod" : "fadeOut"
		}
	}
	function initPager() {
		if (!$('#appPagger').length) {
			return;
		}
		$('#appPagger').bootpag({
			total : $('#totalPages').val(),
			page : $('#pageNo').val(),
			maxVisible : 6,
			leaps : true,
			firstLastUse : true
		}).on('page', function(event, num) {
			$('#pageNo').val(num);
			submitForm('paginationForm');
		});
	}
	return {
		init : function() {
			initCopyRightYear();
			initDeleteModel();
			initPager();
			initToastr();
		}
	}
}();
$(function() {
	"use strict";
	triventCommon.init();
})
var acceptFileTypes = /(\.|\/)(jpg|jpeg|png|gif|bmp|tif|tiff|pdf|doc|docx|ppt|pptx|pps|ppsx|odt|xls|xlsx|zip|rar|mp3|m4a|ogg|wav|mp4|m4v|mov|wmv|avi|mpg|ogv|3gp|3g2|csv|xps|ISO|XML|TXT|M3U|PTX|ptx|wpd)$/i;

var errorMessages = [];
function isFileAllowed(fileName) {
	var status = false;
	if (acceptFileTypes.test(fileName)) {
		status = true;
	}
	return status;
}
function initFileUpload(uploadElementId, progressBarId, redirectUrl) {
	var fileFailureCount = 0;
	var fileUploadCount = 0;
	var fileDoneCount = 0;
	if($("#"+uploadElementId).length>0)
	{
		if (uploadElementId == "caseFileUpload") {
			
				$('#' + uploadElementId)
				.fileupload(
						{
							dataType : 'json',
							progressInterval : 1000,
							add : function(e, data) {
								 $("#case_FileUpload").attr("disabled",false);
					             $("#case_FileUploadClear").attr("disabled",false);
					             var file=data.files[0];
					             var vOutput="";
					             vOutput+="<span class='file_attachment'>"+file.name
					             //vOutput+="<td><input type='button' class='fileUpload' value='upload'></td>"
					             //vOutput+="<span><input type='button' class='case_ResultFileCancel' data-fileName='"+file.name+"' value='cancel'></span></span>"
					             vOutput+="<span><button type='button' class='case_FileCancel btn btn-xs btn-default' data-fileName='"+file.name+"'><i class='fa fa-times' style='font-size: 12px;'></i></button></span></span>"
					             $("#caseFile_Table").append(vOutput);
					             $("#case_FileUpload").eq(-1).on("click",function(){
					            	  autoRefreshCaseFileEnable = false;
					                  data.submit();
					                  $(".case_FileCancel").attr("disabled",true);
					                  $("#case_FileUpload").attr("disabled",true);
					                  $("#caseFile_ProgressBar_Modal").modal("show");
					                  var finishElm = $("#caseNewFinishBtn");
					                  if(finishElm.length > 0){
					                	  $("#caseNewFinishBtn").hide();
					                  }
					             })
					             $(".case_FileCancel").eq(-1).on("click",function(){
					                  $(this).parent().parent().remove();
					                  var cookieValues = $("#caseFileRemoved").val();
					                  var removeFileName = $(this).attr("data-fileName").trim();
					                  removeFileName = (removeFileName != null && removeFileName != "" & removeFileName != undefined) ? removeFileName : "";
					                  if(removeFileName != ""){
					                	  var newValue="";
					                	  if(cookieValues != ""){
						                	  newValue = cookieValues + "/" + removeFileName;
						                  }
					                	  else{
					                		  newValue = removeFileName;
					                	  }
					                	  //document.cookie = "caseResultFileRemove =" +newValue;
					                	  $("#caseFileRemoved").val(newValue);
					                  }
					                  if($("#caseFile_Table").children().length == 0){
					                	  reloadCurrentPage();
					                  }
					             })
					         },
							start : function(e, data) {
								progress = 0;
								$("#caseFile_ProgressBar_Modal").modal("hide");
								$('#' + progressBarId).removeClass('hide');
							},
							drop : function(e, data) {
								fileFailureCount = 0;
								fileUploadCount = 0;
								fileDoneCount = 0;
								$.each(data.files,function(index, file) {
													if (!isFileAllowed(file['name'])) {
														toastr["error"]
																(file['name']
																		+ ' is not an accepted file type.');
														fileFailureCount++;
													} else {
														fileUploadCount++;
													}
												});
								if (fileFailureCount > 0) {
									if ($.browser.mozilla) {
										// firefox doesn't reinit the
										// fileupload. so
										// refresh the page.
										$('#waitModal').modal('show');
										setTimeout(function() {
											window.location.href = redirectUrl;
										}, 5000);
									}
									return false;
								}
		
							},
							change : function(e, data) {
								fileFailureCount = 0;
								fileUploadCount = 0;
								fileDoneCount = 0;
								$.each(data.files,function(index, file) {
													if (!isFileAllowed(file['name'])) {
														toastr["error"]
																(file['name']
																		+ ' is not an accepted file type.');
														fileFailureCount++;
													} else {
														fileUploadCount++;
													}
												});
								if(data.files.length > 0){
									$("#case_FileUploadBlock").show();
									$("#caseFileUpload").parent().find("label[for='caseFileUpload']").attr("disabled",true);
								}
								if (fileFailureCount > 0) {
									if ($.browser.mozilla) {
										// firefox doesn't reinit the
										// fileupload. so
										// refresh the page.
										$('#waitModal').modal('show');
										setTimeout(function() {
											window.location.href = redirectUrl;
										}, 5000);
									}
									return false;
								}
							},
							done : function(e, data) {
								fileDoneCount++;
								if ((progress == 100 && fileUploadCount == fileDoneCount)/*
																							 * ||
																							 * (progress ==
																							 * 100 &&
																							 * fileUploadCount+1 ==
																							 * fileDoneCount)
																							 */) {
									//$("#caseFile_ProgressBar_Modal").modal("hide");
									window.location.href = redirectUrl;
								}
							},
							progressall : function(e, data) {
								progress = parseInt(data.loaded / data.total
										* 100, 10);
								$('#' + progressBarId + ' .progress-bar').css(
										'width', progress + '%');
								if(progress < 100){
									var finishElm = $("#caseNewFinishBtn");
									if(finishElm.length > 0){
										$("#caseNewFinishBtn").hide();
										$("#case_FileUploadClear").attr("disabled",true);
									}
								}
								else{
									setTimeout(function(){
										//$("#caseNewFinishBtn").show();
										//$("#case_FileUploadClear").attr("disabled",false);
									},1000)
								}
							},
							error : function(e, data) {
								$('#' + progressBarId).addClass('hide');
								$("#caseFile_ProgressBar_Modal").modal("hide");
								triventAjaxError();
								setTimeout(function() {
									window.location.href = redirectUrl;
								}, 100);
							}
						});
			
		} else if(uploadElementId == "caseResultFileUpload") {
	
			$('#' + uploadElementId)
					.fileupload(
							{
								dataType : 'json',
								progressInterval : 1000,
								add : function(e, data) {
						             var file=data.files[0];
						             $("#case_ResultFileUpload").attr("disabled",false);
						             $("#case_ResultFileUploadClear").attr("disabled",false);
						             var vOutput="";
						             vOutput+="<span class='file_attachment'>"+file.name
						             //vOutput+="<td><input type='button' class='fileUpload' value='upload'></td>"
						             //vOutput+="<span><input type='button' class='case_ResultFileCancel' data-fileName='"+file.name+"' value='cancel'></span></span>"
						             vOutput+="<span><button type='button' class='case_ResultFileCancel btn btn-xs btn-default' data-fileName='"+file.name+"'><i class='fa fa-times' style='font-size: 12px;'></i></button></span></span>"
						             $("#caseResultFile_Table").append(vOutput);
						             $("#case_ResultFileUpload").eq(-1).on("click",function(){
						                  data.submit();
						                  autoRefreshCaseResultFileEnable = false;
						                  $("#caseResultFile_ProgressBar_Modal").modal("show");
						                  $(".case_ResultFileCancel").attr("disabled", true);
						                  $("#case_ResultFileUpload").attr("disabled",true);
						             })
						             $(".case_ResultFileCancel").eq(-1).on("click",function(){
						                  $(this).parent().parent().remove();
						                  var cookieValues = $("#caseResultFileRemoved").val();
						                  var removeFileName = $(this).attr("data-fileName").trim();
						                  removeFileName = (removeFileName != null && removeFileName != "" & removeFileName != undefined) ? removeFileName : "";
						                  if(removeFileName != ""){
						                	  var newValue="";
						                	  if(cookieValues != ""){
							                	  newValue = cookieValues + "/" + removeFileName;
							                  }
						                	  else{
						                		  newValue = removeFileName;
						                	  }
						                	  //document.cookie = "caseResultFileRemove =" +newValue;
						                	  $("#caseResultFileRemoved").val(newValue);
						                  }
						                  if($("#caseResultFile_Table").children().length == 0){
						                	  reloadCurrentPage();
						                  }
						             })
						         },
								start : function(e, data) {
									progress = 0;
									$("#caseResultFile_ProgressBar_Modal").modal("hide");
									$('#' + progressBarId).removeClass('hide');
								},
								drop : function(e, data) {
									fileFailureCount = 0;
									fileUploadCount = 0;
									fileDoneCount = 0;
									$
											.each(
													data.files,
													function(index, file) {
														if (!isFileAllowed(file['name'])) {
															toastr["error"]
																	(file['name']
																			+ ' is not an accepted file type.');
															fileFailureCount++;
														} else {
															fileUploadCount++;
														}
													});
									if (fileFailureCount > 0) {
										if ($.browser.mozilla) {
											// firefox doesn't reinit the
											// fileupload. so
											// refresh the page.
											$('#waitModal').modal('show');
											setTimeout(function() {
												window.location.href = redirectUrl;
											}, 5000);
										}
										return false;
									}
	
								},
								change : function(e, data) {
									fileFailureCount = 0;
									fileUploadCount = 0;
									fileDoneCount = 0;
									$.each(
													data.files,
													function(index, file) {
														if (!isFileAllowed(file['name'])) {
															toastr["error"]
																	(file['name']
																			+ ' is not an accepted file type.');
															fileFailureCount++;
														} else {
															fileUploadCount++;
														}
													});
									if(data.files.length > 0){
										$("#case_ResultFileUploadBlock").show();
										$("#caseResultFileUpload").parent().find("label[for='caseResultFileUpload']").attr("disabled",true);
									}
									if (fileFailureCount > 0) {
										if ($.browser.mozilla) {
											// firefox doesn't reinit the
											// fileupload. so
											// refresh the page.
											$('#waitModal').modal('show');
											setTimeout(function() {
												window.location.href = redirectUrl;
											}, 5000);
										}
										return false;
									}
								},
								done : function(e, data) {
									fileDoneCount++;
									if ((progress == 100 && fileUploadCount == fileDoneCount)/*
																								 * ||
																								 * (progress ==
																								 * 100 &&
																								 * fileUploadCount+1 ==
																								 * fileDoneCount)
																								 */) {
										window.location.href = redirectUrl;
									}
								},
								progressall : function(e, data) {
									progress = parseInt(data.loaded / data.total
											* 100, 10);
									$('#' + progressBarId + ' .progress-bar').css(
											'width', progress + '%');
									if(progress < 100){
											$("#case_ResultFileUploadClear").attr("disabled",true);
									}
									else{
										setTimeout(function(){
											//$("#case_ResultFileUploadClear").attr("disabled",false);
										},1200)
									}
								},
								error : function(e, data) {
									$('#' + progressBarId).addClass('hide');
									$("#caseResultFile_ProgressBar_Modal").modal("hide");
									triventAjaxError();
									setTimeout(function() {
										window.location.href = redirectUrl;
									}, 100);
								}
							});
		} else {
	
			$('#' + uploadElementId)
					.fileupload(
							{
								dataType : 'json',
								progressInterval : 1000,
								start : function(e, data) {
									progress = 0;
									$('#' + progressBarId).removeClass('hide');
								},
								drop : function(e, data) {
									fileFailureCount = 0;
									fileUploadCount = 0;
									fileDoneCount = 0;
									$
											.each(
													data.files,
													function(index, file) {
														if (!isFileAllowed(file['name'])) {
															toastr["error"]
																	(file['name']
																			+ ' is not an accepted file type.');
															fileFailureCount++;
														} else {
															fileUploadCount++;
														}
													});
									if (fileFailureCount > 0) {
										if ($.browser.mozilla) {
											// firefox doesn't reinit the
											// fileupload. so
											// refresh the page.
											$('#waitModal').modal('show');
											setTimeout(function() {
												window.location.href = redirectUrl;
											}, 5000);
										}
										return false;
									}
	
								},
								change : function(e, data) {
									fileFailureCount = 0;
									fileUploadCount = 0;
									fileDoneCount = 0;
									$
											.each(
													data.files,
													function(index, file) {
														if (!isFileAllowed(file['name'])) {
															toastr["error"]
																	(file['name']
																			+ ' is not an accepted file type.');
															fileFailureCount++;
														} else {
															fileUploadCount++;
														}
													});
									if (fileFailureCount > 0) {
										if ($.browser.mozilla) {
											// firefox doesn't reinit the
											// fileupload. so
											// refresh the page.
											$('#waitModal').modal('show');
											setTimeout(function() {
												window.location.href = redirectUrl;
											}, 5000);
										}
										return false;
									}
								},
								done : function(e, data) {
									fileDoneCount++;
									if ((progress == 100 && fileUploadCount == fileDoneCount)/*
																								 * ||
																								 * (progress ==
																								 * 100 &&
																								 * fileUploadCount+1 ==
																								 * fileDoneCount)
																								 */) {
										window.location.href = redirectUrl;
									}
								},
								progressall : function(e, data) {
									progress = parseInt(data.loaded / data.total
											* 100, 10);
									$('#' + progressBarId + ' .progress-bar').css(
											'width', progress + '%');
								},
								error : function(e, data) {
									$('#' + progressBarId).addClass('hide');
									triventAjaxError();
								}
							});
		}
	}
}
// Add App Task
function addAppCaseTask() {
	var url = 'addCaseTask.htm';
	addTaskCommon(url);
}
// Add Case Task
function addTaskCommon(url) {
	$('#caseTaskModalBody').load(url, function(result) {
		showModel('caseTaskModal');
		enableValidation('caseTaskDetailForm');
		initDatePicker();
		initChosen();
	});
}
// Edit Case Task
function editCaseTask(caseTaskId, callbackScreen) {
	$('#caseTaskModalBody').load(
			'caseTask.htm?caseTaskId=' + caseTaskId + '&callbackScreen='
					+ callbackScreen, function(result) {
				showModel('caseTaskModal');
				enableValidation('caseTaskDetailForm');
				initDatePicker();
				initChosen();
			});
}
// Populate Case Task Text Box with predeifned values
function populatePredefinedCaseTask(targetElementId, value) {
	$('#' + targetElementId).val(value);
}

// Add App Query
function addAppCaseQuery() {
	var url = 'addCaseQuery.htm';
	addQueryCommon(url);
}
// Add Case Query
function addQueryCommon(url) {
	$('#caseQueryModalBody').load(url, function(result) {
		showModel('caseQueryModal');
		enableValidation('caseQueryDetailForm');
		initDatePicker();
		initChosen();
		initRichTextBox();
		initBootstrapSwitch("caseQueryDetailForm");
	});
}
// RichTextBox Populate Value and submit
function populateRichTextBoxAndSubmit(formId, elementId) {
	$('#' + elementId).val($.trim($('#editor').cleanHtml()));
	$('#' + formId).submit();
}

function commonjsTree(elementID, jsTreeDS, jsPlugins)
{
	if(jQuery.type(jsPlugins) == "null" || jQuery.type(jsPlugins) == "undefined" || jsPlugins == "")
	{
		jsPlugins="types";
	};
	
	if(jQuery.type(jsPlugins) != 'array')
	{
		jsPlugins=jsPlugins.split(",");
	};
		
	$(elementID).jstree({
		"core":{
			"data":jsTreeDS
		},
		"types" : {
            "default" : {
                "icon" : "fa fa-file icon-state-warning icon-lg"
            },
            "file" : {
                "icon" : "fa fa-file icon-state-warning icon-lg"
            }
        },
        "search": {
        	"case_insensitive": true,
        	"show_only_matches" : true
        },
        "plugins": jsPlugins
	});
	
	$(elementID+'_t').keyup(function () {
		
		var searchString = $(this).val();
        $(elementID).jstree('search', searchString);
		
	});
	
	$(elementID+'_b').click(function () {
		
		var SelectedNode= $(elementID).jstree("get_selected");
		$(elementID).jstree('deselect_all');
		$(elementID).jstree('close_all');
		$(elementID+'_t').val('');
		$(elementID).jstree('search', '');
		selectNode(SelectedNode);

	});
	
	function selectNode(seachselectedNode)
	{
		if(seachselectedNode!="#")
		{
			selectNode($(elementID).jstree()._model.data[seachselectedNode].parent);
			$(elementID).jstree('deselect_all');
			$(elementID).jstree("select_node", $('#'+$(elementID).jstree()._model.data[seachselectedNode].id)).trigger("select_node.jstree")
			$(elementID).jstree("open_node", $('#'+$(elementID).jstree()._model.data[seachselectedNode].id));
			document.getElementById($(elementID).jstree()._model.data[seachselectedNode].id+'_anchor').scrollIntoView();
			return 1;
		}
		else
		{
			$(elementID).jstree("open_node", $('#ROOTID_anchor'));
			return 0;
		}
	}
	
}

//Global function to get cookies value by using cookie name
function getCookie(cname) {
    var name = cname + "=",ca = document.cookie.split(';'),i,c,ca_length = ca.length;
    for (i = 0; i < ca_length; i += 1) {
        c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) !== -1) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
//Funtion to reload the page 
function reloadCurrentPage(){
	setTimeout(function(){
		window.location.reload(true);
	},300);
}

function callProgressBar(psMode, progressMessage)
{
	if(!progressMessage) { progressMessage = "Loading.."; }
	setTimeout(function(){
		$("#globalProgressBarMsgTxt").text(progressMessage);
		$("#cp_Global_ProgressBar_Modal").modal(psMode);
	},100);
}

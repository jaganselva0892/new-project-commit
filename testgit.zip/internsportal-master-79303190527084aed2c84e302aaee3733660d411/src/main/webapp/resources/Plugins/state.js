// States
var state_arr = new Array("Andaman and Nicobar Islands", "Andhra Pradesh",
		"Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh",
		"Dadra and Nagar Haveli", "Daman and Diu", "Delhi", "Goa", "Gujarat",
		"Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand",
		"Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra",
		"Manipur", "Meghalaya", "Mizoram", "Nagaland", "Orissa", "Pondicherry",
		"Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura",
		"Uttar Pradesh", "Uttaranchal", "Punjab", "West Bengal");

function populateState(stateElementId) {
	var stateElement = document.getElementById(stateElementId);
	stateElement.length = 0;
	stateElement.options[0] = new Option('Select State', '-1');
	stateElement.selectedIndex = 0;
	for (var i = 0; i < state_arr.length; i++) {
		stateElement.options[stateElement.length] = new Option(state_arr[i],
				state_arr[i]);
	}

}
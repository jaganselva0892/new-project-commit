// City
var city_arr = new Array("Arcot",
		"Chengalpattu",
		"Chennai",
		"Chidambaram",
		"Coimbatore",
		"Cuddalore",
		"Dharmapuri",
		"Dindigul",
		"Erode",
		"Kanchipuram",
		"Kanniyakumari",
		"Kodaikanal",
		"Kumbakonam",
		"Madurai",
		"Mamallapuram",
		"Nagappattinam",
		"Nagercoil",
		"Palayankottai",
		"Pudukkottai",
		"Rajapalaiyam",
		"Ramanathapuram",
		"Salem",
		"Thanjavur",
		"Tiruchchirappalli",
		"Tirunelveli",
		"Tiruppur",
		"Tuticorin",
		"Udhagamandalam",
		"Vellore");

function populateCity(cityElementId) {
    // given the id of the <select> tag as function argument, it inserts <option> tags
    var cityElement = document.getElementById(cityElementId);
    cityElement.length = 0;
    cityElement.options[0] = new Option('Select City', '-1');
    cityElement.selectedIndex = 0;
    for (var i = 0; i < city_arr.length; i++) {
        cityElement.options[cityElement.length] = new Option(city_arr[i], city_arr[i]);
    }

    // Assigned all countries. Now assign event listener for the states.

//    if (stateElementId) {
//        countryElement.onchange = function () {
//            populateStates(countryElementId, stateElementId);
//        };
//    }
}
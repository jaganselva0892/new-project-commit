function initToastr() {
	toastr.options = {
		"closeButton" : true,
		"debug" : false,
		"newestOnTop" : false,
		"progressBar" : false,
		"positionClass" : "toast-bottom-right",// toast-top-right /
		// toast-top-left /
		// toast-bottom-right /
		// toast-bottom-left
		"preventDuplicates" : false,
		"showDuration" : "300",
		"hideDuration" : "1000",
		"timeOut" : "3000",
		"extendedTimeOut" : "3000",
		"showEasing" : "swing",
		"hideEasing" : "linear",
		"showMethod" : "fadeIn",
		"hideMethod" : "fadeOut"
	}
}

function callToastr(psType, psMessage) {
	if (psMessage) {
		if (psType == "info") {
			toastr.info(psMessage);
		} else if (psType == "warning") {
			toastr.warning(psMessage);
		} else if (psType == "success") {
			toastr.success(psMessage);
		} else if (psType == "error") {
			toastr.error(psMessage);
		}
	}
}

function showCustomModel(modelName) {
	$('#' + modelName).modal({
		show : true
	});
}

function callAttachmentModal(psController, psParameter) {
	if (!psParameter)
		psParameter = "";
	$('#uploadAttachmentModalHeader').load(psController + psParameter, function(result) {
		showCustomModel('uploadAttachmentModal');
	});
}

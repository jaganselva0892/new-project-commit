$("#skillsId").select2();
$("#streamId").select2();
var strSkills = null;
var strStream = null;
var struserCity = null;
$(function() {
	populateCity("userCity");
	setTimeout(function() {
		$('.datepicker').datepicker({
			dateFormat : "yy-mm-dd"
		});
		$('.endDate').datepicker();
		$('.startAndEndDate').datepicker();
		if (strSkills != null && strSkills != "") {
			$("#skillsId").val(strSkills.split(","));
			$('#skillsId').trigger('change');
			
		}
		if (strStream != null && strStream != "") {
			$("#streamId").val(strStream.split(","));
			$('#streamId').trigger('change');
			
		}

	}, 1000);

});
function callSignInSignUpDesign(psController, psParameter) {
	if (!psParameter)
		psParameter = "";
	$('#modelSignInSignUpBody').load(psController + psParameter,
			function(result) {
				showModel('modelSignInSignUp');
			});
}

function callUserSignInUpModel(psType, psMode) {
	if (!psMode) {
		psMode = $("#psMode_id").val();
	}

	var psSendParam = "?psMode=" + psMode + "&psType=" + psType;
	callSignInSignUpDesign('callUserSignInUpModel', psSendParam);
}

function callUserTypeModel(psParam) {

	var psSendParam = "?psMode=" + psParam
	callSignInSignUpDesign('callUserTypeModel', psSendParam);
}

function showModel(modelName) {
	$('#' + modelName).modal({
		show : true
	});
}

function callStudentViewDetails(psParam) {
	$('#studentDetailsModalBody').load('getStudentDetails?userId=' + psParam,
			function(result) {
				showModel('studentDetailsModal');
			});
}
function callUserViewDetails(psParam) {
	$('#studentDetailsModalBody').load('getUserDetails?userId=' + psParam,
			function(result) {
				showModel('studentDetailsModal');
			});
}

function getUserDetails() {
	callUserViewDetails('getUserDetails');
}


function callStudentDetails(psParam) {
	$('#studentDetailsModalBody').load(
			'getStudentDetailsView?userstaggingId=' + psParam,
			function(result) {
				showModel('studentDetailsModal');
			});
}
function getStudentDetailsView() {
	callStudentDetails('getStudentDetailsView');
}


function callPostViewDetails(psParam) {
	$('#ViewPostdetailsModalBody').load('getPostDetails?id=' + psParam,
			function(result) {
				showModel('ViewPostdetails');
			});
}

function getPostDetails() {
	callStudentViewDetails('getPostDetails');
}

function callApplyModal() {
	showModel("confirmApplyModal");
}

function callSignInUpModel() {
	var psMode = "signin";
	var psSendParam = "?psMode=" + psMode;
	callSignInSignUpDesign('callUserSignInUpModel', psSendParam);
}


function callMoreDetails(psParam) {
	$('#viewMoreDetailsModalBody').load(
			'getMoreDetailsView?internId=' + psParam,
			function(result) {
				showModel('viewMoreDetailsModal');
			});
}
function getMoreDetailsView() {
	callMoreDetails('getMoreDetailsView');
}
var profileid = null;	
$('.datepicker').datepicker();
var strSkills = null;
var strStreams = null;
var strGender = null;
var strUserCity = null;
$(document).ready(function() {
	setTimeout(function(){
		if (profileid != null) {
			
			
		}
		if (strSkills != null && strSkills != "") {
			setTimeout(function(){
				$("#skillName").val(strSkills.split(","));
			});
			//$('#skills_id').on('change', strSkills);
		}
//		if (strStreams != null && strStreams != "") {
//			$("#streamName").val(strStreams.split(","));
//			//$('#skills_id').on('change', strStreams);
//		}
		
		if (strStreams != null && strStreams != "") {
			$('#AreaOfInterest').val(strStreams.split(","));
			$('#AreaOfInterest').trigger('change');
		}
		if(strSkills != null && strSkills != ""){
			$('#skills_id').val(strSkills.split(","));
			$('#skills_id').trigger('change');
		}
//		if(strGender != null && strGender != ""){
//			var genderSelect = $("#Gender").find("option");
//			for (var n = 0; n < genderSelect.length; n++) {
//				if (strGender == genderSelect[n].value) {
//					$(genderSelect[n]).attr("selected", '""');
//				}
//			}
//		}
		if(strUserCity != null && strUserCity != ""){
			setTimeout(function(){
				$("#userCity").val(strUserCity);
			},300);
		}
		//$("#skills_id").select2();
		//$('#AreaOfInterest').select2();
		//$('.datepicker').datepicker();
		populateCity("userCity");
		$('[data-toggle="tooltip"]').tooltip();
	},1000);
	
});
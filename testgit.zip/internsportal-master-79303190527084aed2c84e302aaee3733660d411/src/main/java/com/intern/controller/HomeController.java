package com.intern.controller;

import java.net.URLEncoder;
import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.utils.AppConstants;
import com.intern.auditor.AuditorAwareService;
import com.intern.auditor.SecurityUser;
import com.intern.dto.AppListItemsVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.HomeVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.SearchFilteringVO;
import com.intern.dto.UserStagingVO;
import com.intern.dto.UserVO;
import com.intern.entity.AppListItems;
import com.intern.entity.User;
import com.intern.service.AdminService;
import com.intern.service.CompanyService;
import com.intern.service.InternDetailService;
import com.intern.service.SearchService;
import com.intern.service.StudentService;
import com.intern.service.UserService;
import com.intern.service.UserStagingService;

@Controller
public class HomeController {

	@Autowired
	private SearchService searchService;

	@Autowired
	private UserService userService;

	@Autowired
	private AdminService adminService;

	@Autowired
	private StudentService studentService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private InternDetailService internDetailService;

	@Autowired
	private AuditorAwareService auditorAwareService;

	@Autowired
	private UserStagingService userStagingService;

	@Autowired
	HttpSession httpSession;

	@RequestMapping(value = "/home")
	public String homePage(ModelMap model, Principal principal, HttpServletRequest request, HttpSession session,
			HttpServletResponse response) {
		List<AppListItems> applists = searchService.SearchDetails();
		UserStagingVO userStagingVO = new UserStagingVO();
		model.addAttribute("userStagingVO", userStagingVO);
		AppListItemsVO AppListItemsVO = new AppListItemsVO();
		model.addAttribute("appListItemsVO", AppListItemsVO);
		model.addAttribute(AppConstants.SEARCH_BY_CATEGORY, applists);
		SearchFilteringVO searchFilteringVO = new SearchFilteringVO();
		model.addAttribute("searchFilteringVO", searchFilteringVO);
		User loginUser = auditorAwareService.getCurrentAuditor();
		List<HomeVO> internshipDetails = adminService.getinternshipDetails();
		model.addAttribute("internshipDetails", internshipDetails);
		List<CompanyProfileVO> listCompanyProfileVO = companyService.getCompanyDetailsAndLogo();
		model.addAttribute("listCompanyProfileVO", listCompanyProfileVO);
		return "home";
	}

	@RequestMapping(value = "/ajax/search.json", method = RequestMethod.GET)
	@ResponseBody
	public String getSearchItemsListJSON(@RequestParam String applistitemsName) {
		return searchService.SearchByCategory(applistitemsName);

	}

	@RequestMapping(value = "/home", method = RequestMethod.POST)
	public String homeSearch(@ModelAttribute SearchFilteringVO searchFilteringVO, HttpServletRequest request,
			HttpServletResponse response, ModelMap model) {
		// String searchKey = (String) request.getAttribute("searchKey");
		String searchKey = searchFilteringVO.getSearchKey();
		if (searchKey == null) {
			return "redirect:/home";
		}
		try {
			searchKey = URLEncoder.encode(searchKey, "UTF-8");
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return "redirect:/search?searchKey=" + searchKey;
	}

	
	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public String about() {
		return "about";

	}

	@RequestMapping(value = "/contact", method = RequestMethod.GET)
	public String contact(ModelMap model) {
		HomeVO homeVO = new HomeVO();
		model.addAttribute("homeVO", homeVO);
		return "contact";
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public List<User> getUsers() {
		List<User> listActiveUsers = userService.listUsers();
		// model.addAttribute("listActiveUsers", listActiveUsers);
		return listActiveUsers;
	}

	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String getActiveUsers(ModelMap model) {
		String userListCount = userService.listUsersCount();
		model.addAttribute(AppConstants.USER_LIST_COUNT, userListCount);
		String listActivePosts = internDetailService.listPosts();
		model.addAttribute(AppConstants.LIST_ACTIVE_USERS, listActivePosts);
		AppListItemsVO AppListItemsVO = new AppListItemsVO();
		String listActiveStudents = studentService.listStudents();
		model.addAttribute(AppConstants.LIST_ACTIVE_STUDENTS, listActiveStudents);
		String listActiveCompanies = companyService.listCompanies();
		model.addAttribute(AppConstants.LIST_ACTIVE_COMPANIES, listActiveCompanies);

		// String userApprovalPendings =
		// studentService.listUserApprovalPendings();
		// model.addAttribute(AppConstants.USER_APPROVAL_PENDINGS,
		// userApprovalPendings);
		// String companyApprovalPendings =
		// companyService.listCompanyApprovalPendings();
		// model.addAttribute(AppConstants.COMPANY_APPROVAL_PENDINGS,
		// companyApprovalPendings);
		// String postApprovalPendings =
		// internDetailService.listPostApprovalPendings();
		// model.addAttribute(AppConstants.POST_APPROVAL_PENDINGS,
		// postApprovalPendings);

		model.addAttribute("appListItemsVO", AppListItemsVO);
		List<UserStagingVO> userStaggingVO = userStagingService.approveUsers();
		model.addAttribute("userStaggingVO", userStaggingVO);
		List<UserVO> userVO = userService.listusers();
		model.addAttribute("userVO", userVO);
		List<InternDetailsVO> internDetailsVO = internDetailService.listinternships();
		model.addAttribute("internDetailsVO", internDetailsVO);
		return "admin";
	}

	@RequestMapping(value = "/emailQueue")
	public String getEmailQueue() {
		return "emailQueue";
	}

	@RequestMapping(value = "/emailTemplate")
	public String getEmailTemplate() {
		return "emailTemplate";
	}

	@RequestMapping(value = "/editEmailTemplate")
	public String getEditEmailTemplate() {
		return "editEmailTemplate";
	}

	@RequestMapping(value = "/queriesRequest")
	public String sendQueriesToAdmin(@ModelAttribute HomeVO homeVO, RedirectAttributes redirectAttrs) {
		try {
			adminService.sendQueries(homeVO);
			redirectAttrs.addFlashAttribute("info",
					"Thank You , Your Query has been to our admin.Plaese Wait for Respond!");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Some Error Occurs");
		}
		return "redirect:/home";

	}

	@RequestMapping(value = "/faq")
	public String getFAQ() {
		return "faq";
	}

	
	
	
}

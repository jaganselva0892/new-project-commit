package com.intern.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ddf.EscherColorRef.SysIndexSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.UserVO;
import com.intern.entity.User;
import com.intern.service.CompanyService;
import com.intern.service.InternDetailService;
import com.intern.utils.AppConstants;

@Controller
public class CompanyController {

	@Autowired
	private CompanyService companyService;

	@Autowired
	private InternDetailService internDetailService;
	
	@Autowired
	AuditorAwareService auditorAwareService;

	@RequestMapping(value = "/postInternships")
	public String callPostInternship(ModelMap model) {
		InternDetailsVO internDetailsVO = internDetailService.getInternDetails();
		model.addAttribute("internDetailsVO", internDetailsVO);
		return "postInternships";
	}

	@RequestMapping(value = "/companyProfile")
	public String updateProfile(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		CompanyProfileVO companyProfileVO = companyService.getCompanyProfile();
		model.addAttribute("companyProfileVO", companyProfileVO);
		return "companyProfile";
	}

	@RequestMapping(value = "/companyProfileUpdate", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute CompanyProfileVO companyProfileVO, RedirectAttributes redirectAttrs) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		try {
			companyService.saveCompanyDetails(companyProfileVO);
			redirectAttrs.addFlashAttribute("success", "Profile Updated successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Invalid Update");
		}
		//return "redirect:/companyView?userId=" + loginUser.getId();
		//return "redirect:/companyProfile";
		return "redirect:/companyDashboardNew";
	}

	@RequestMapping(value = "/companyDashboard")
	public String companyDashboard(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		try {
			String postInternshipsCount = internDetailService.listPostInternshipsCount();
			model.addAttribute("postInternshipsCount", postInternshipsCount);
			List<InternDetailsVO> internDetailsVO = companyService.getPostedInternships();
			model.addAttribute("internDetailsVO", internDetailsVO);
			List<AppliedHistoryVO> appliedHistoryVO = companyService.getStudentAppliedHistory();
			model.addAttribute("appliedHistoryVO", appliedHistoryVO);
			String studentsAppliedCount = Integer.toString(appliedHistoryVO.size());
			model.addAttribute("studentsAppliedCount", studentsAppliedCount);
		} catch (Exception ex) {
			ex.getMessage();
		}
		return "companyDashboard";
	}
	@RequestMapping(value = "/companyDashboardNew")
	public String companyDashboardNew(ModelMap model, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		try {
			User loginUser = auditorAwareService.getCurrentAuditor();
			
			String postInternshipsCount = internDetailService.listPostInternshipsCount();
			model.addAttribute("postInternshipsCount", postInternshipsCount);
			List<InternDetailsVO> internDetailsVO = companyService.getPostedInternships();
			model.addAttribute("internDetailsVO", internDetailsVO);
			List<AppliedHistoryVO> appliedHistoryVO = companyService.getStudentAppliedHistory();
			model.addAttribute("appliedHistoryVO", appliedHistoryVO);
			String studentsAppliedCount = Integer.toString(appliedHistoryVO.size());
			model.addAttribute("studentsAppliedCount", studentsAppliedCount);
			
			UserVO userVO = new UserVO();
			model.addAttribute("userVO", userVO);
			String totalNumberOfApplies = internDetailService.listPostInternshipsCount();
			model.addAttribute("totalNumberOfApplies", totalNumberOfApplies);
			List<CompanyProfileVO> listCompanyProfileVO = companyService.getCompanyDetailsToView(loginUser.getId());
			for (CompanyProfileVO companypro : listCompanyProfileVO) {
				model.addAttribute("companyDetail", companypro);
				String comName = companypro.getCompanyName();
				model.addAttribute("comName", comName);
				String companyDesc = companypro.getCompanyDescription();
				model.addAttribute("companyDesc", companyDesc);
				String companyWebsite = companypro.getCompanyWebsite();
				model.addAttribute("companyWebsite", companyWebsite);
			}
			model.addAttribute("listCompanyProfileVO", listCompanyProfileVO);
			
		} catch (Exception ex) {
			ex.getMessage();
		}
		return "companyDashboardNew";
	}

	@RequestMapping(value = "/editPostInternship")
	public String editPostedInternship(@RequestParam Long internId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			InternDetailsVO internDetailsVO = companyService.editPostedInternships(internId);
			model.addAttribute("internDetailsVO", internDetailsVO);
			// redirectAttrs.addFlashAttribute("error", "Post Updated
			// Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			// redirectAttrs.addFlashAttribute("error", "Invalid Update");
		}
		return "postInternships";
	}

	@RequestMapping(value = "/deleteInternshipPost")
	public String deleteInternshipPost(@RequestParam Long internId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			companyService.deleteInternPost(internId);
			redirectAttrs.addFlashAttribute("success", "Deleted successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/companyDashboardNew";

	}

	@RequestMapping(value = "/getStudentDetails")
	public String getStudentDetails(@RequestParam Long userId, ModelMap model) {
		List<StudentDetailsVO> studentDetailsVO = companyService.getStudentDetails(userId);
		model.addAttribute("studentDetailsVO", studentDetailsVO);
		return "studentDetails";

	}

	// @RequestMapping(value = "/companyProfileView/{id}")
	// public String getCompanyProfileDetails(ModelMap model,
	// @PathVariable("id") Long userId) {
	// List<CompanyProfileVO> listCompanyVO =
	// companyService.getCompanyDetailsToView(userId);
	// model.addAttribute("listCompanyVO", listCompanyVO);
	// return "companyProfileView";
	// }

	@RequestMapping(value = "/companyView")
	public String getCompanyProfileDetails(ModelMap model, Long userId) {
		UserVO userVO = new UserVO();
		model.addAttribute("userVO", userVO);
		String totalNumberOfApplies = internDetailService.listPostInternshipsCount();
		model.addAttribute("totalNumberOfApplies", totalNumberOfApplies);
		List<CompanyProfileVO> listCompanyProfileVO = companyService.getCompanyDetailsToView(userId);
		for (CompanyProfileVO companypro : listCompanyProfileVO) {
			model.addAttribute("companyDetail", companypro);
			String comName = companypro.getCompanyName();
			model.addAttribute("comName", comName);
			String companyDesc = companypro.getCompanyDescription();
			model.addAttribute("companyDesc", companyDesc);
			String companyWebsite = companypro.getCompanyWebsite();
			model.addAttribute("companyWebsite", companyWebsite);
		}
		model.addAttribute("listCompanyProfileVO", listCompanyProfileVO);
		return "companyView";
	}

	// @RequestMapping(value = "/companyView")
	// public String getViewDetails() {
	// return "companyView";
	//
	// }
}

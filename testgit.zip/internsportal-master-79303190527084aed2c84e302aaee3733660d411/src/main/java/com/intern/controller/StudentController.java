package com.intern.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.AttachmentsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserVO;
import com.intern.entity.User;
import com.intern.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService studentService;

	@Autowired
	AuditorAwareService auditorAwareService;

	@RequestMapping(value = "/studentProfile")
	public String studentProfileDetails(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		StudentProfileVO studentProfileVO = studentService.getStudentProfile();
		model.addAttribute("studentProfileVO", studentProfileVO);
		return "studentProfile";
	}

	// @RequestMapping(value = "/studentView")
	// public String viewStudentProfileDetails(ModelMap model,
	// HttpServletRequest request, HttpServletResponse response) {
	// // StudentProfileVO studentProfileVO =
	// // studentService.getStudentProfile();
	// // model.addAttribute("studentProfileVO", studentProfileVO);
	// return "studentView";
	// }

	// @RequestMapping(value = "/studentView/{id}")
	// public String studentProfileView(ModelMap model, @PathVariable("id") Long
	// id) {
	// List<StudentProfileVO> studentProfileVO =
	// studentService.getStudentProfileView(id);
	// model.addAttribute("studentProfileVO", studentProfileVO);
	// return "studentView";
	// }

	@RequestMapping(value = "/studentDashboard")
	public String StudentAppliedList(ModelMap model) {
		List<AppliedHistoryVO> appliedHistoryVO = studentService.getAppliedDetails();
		model.addAttribute("appliedHistoryVO", appliedHistoryVO);
		return "studentDashboard";
	}
	
	@RequestMapping(value = "/studentDashboardNew")
	public String StudentDashboard(ModelMap model) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		Long userId = loginUser.getId();
		
		List<AppliedHistoryVO> appliedHistoryVO = studentService.getAppliedDetails();
		model.addAttribute("appliedHistoryVO", appliedHistoryVO);
		StudentProfileVO studentProfileVO = studentService.getStudentProfile();
		model.addAttribute("studentProfileVO", studentProfileVO);
		
		UserVO userVO = new UserVO();
		model.addAttribute("userVO", userVO);
		String countOfAppliedInternship = studentService.getCountOfAppliedDetails(userId);
		model.addAttribute("countOfAppliedInternship", countOfAppliedInternship);
		List<StudentProfileVO> studentProfileVOlist = studentService.getStudentProfileView(userId);
		for (StudentProfileVO studentDetailsVO : studentProfileVOlist) {
			model.addAttribute("studentDetails", studentDetailsVO);
			String studentName = studentDetailsVO.getStudentFirstName();
			model.addAttribute("studentName", studentName);
			char isResume = studentDetailsVO.getisResume();
			model.addAttribute("isResume", isResume);
			String resumeBaseString = studentDetailsVO.getResumeBaseString();
			model.addAttribute("resumeBaseString", resumeBaseString);
			AttachmentsVO attachmentsVO = studentDetailsVO.getAttachmentsVO();
			model.addAttribute("attachmentsVO", attachmentsVO);
			// String stuEmailId = studentDetailsVO.getStudentEmail();
			// model.addAttribute("stuEmailId", stuEmailId);
			// String degree = studentDetailsVO.getStreamMap().toString();
			// model.addAttribute("degree", degree);
			// String skills = studentDetailsVO.getSkillsMap().toString();
			// model.addAttribute("skills", skills);
		}
		model.addAttribute("studentProfileVO", studentProfileVOlist);
		
		return "studentDashboardNew";
	}

	@RequestMapping(value = "/updateStudentProfile", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute StudentProfileVO studentProfileVO, RedirectAttributes redirectAttrs) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		try {
			studentService.saveStudentDetails(studentProfileVO);
			redirectAttrs.addFlashAttribute("success", "Updated successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Invalid Update");
		}
		// return "redirect:/studentProfile";
		//return "redirect:/studentView?userId=" + loginUser.getId();
		return "redirect:/studentDashboardNew";
	}

	// @RequestMapping(value = "/deleteAppliedInternship")
	// public String deleteAppliedInternPost(@RequestParam Long applyHistoryid)
	// {
	// studentService.deleteAppliedInternPost(applyHistoryid);
	// return "redirect:/studentDashboard";
	// }

	// @RequestMapping(value = "/deleteaAppliedInternship")
	// public String deleteAppliedInternPost(@RequestParam Long applyHistoryId,
	// RedirectAttributes redirectAttrs) {
	// try {
	// studentService.deleteAppliedInternPost(applyHistoryId);
	// redirectAttrs.addFlashAttribute("success", "Deleted successfully");
	// } catch (Exception ex) {
	// ex.getMessage();
	// redirectAttrs.addFlashAttribute("error", "No records found");
	// }
	// return "redirect:/studentDashboard";
	// }

	@RequestMapping(value = "/deleteAppliedInternship")
	public String deleteFromList(@RequestParam Long applyHistoryid, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			studentService.deleteAppliedInternPost(applyHistoryid);
			redirectAttrs.addFlashAttribute("success", "Deleted Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/studentDashboardNew";

	}

	@RequestMapping(value = "/studentView")
	public String studentProfileView(ModelMap model, Long userId) {
		UserVO userVO = new UserVO();
		model.addAttribute("userVO", userVO);
		String countOfAppliedInternship = studentService.getCountOfAppliedDetails(userId);
		model.addAttribute("countOfAppliedInternship", countOfAppliedInternship);
		List<StudentProfileVO> studentProfileVOlist = studentService.getStudentProfileView(userId);
		for (StudentProfileVO studentDetailsVO : studentProfileVOlist) {
			model.addAttribute("studentDetails", studentDetailsVO);
			String studentName = studentDetailsVO.getStudentFirstName();
			model.addAttribute("studentName", studentName);
			char isResume = studentDetailsVO.getisResume();
			model.addAttribute("isResume", isResume);
			String resumeBaseString = studentDetailsVO.getResumeBaseString();
			model.addAttribute("resumeBaseString", resumeBaseString);
			AttachmentsVO attachmentsVO = studentDetailsVO.getAttachmentsVO();
			model.addAttribute("attachmentsVO", attachmentsVO);
			// String stuEmailId = studentDetailsVO.getStudentEmail();
			// model.addAttribute("stuEmailId", stuEmailId);
			// String degree = studentDetailsVO.getStreamMap().toString();
			// model.addAttribute("degree", degree);
			// String skills = studentDetailsVO.getSkillsMap().toString();
			// model.addAttribute("skills", skills);
		}
		model.addAttribute("studentProfileVO", studentProfileVOlist);
		return "studentView";
	}

	// @RequestMapping(value = "/studentView/{id}")
	// public String studentProfileView(ModelMap model, @PathVariable("id") Long
	// id) {
	// List<StudentProfileVO> studentProfileVO =
	// studentService.getStudentProfileView(id);
	// model.addAttribute("studentProfileVO", studentProfileVO);
	// return "studentView";
	// }
	// @RequestMapping(value = "/ajax/account.json", method = RequestMethod.GET)
	// public Map<String, String>updateProfile(@RequestParam Long
	// studentProfileId){
	// return studentService.getStudentDetails(studentProfileId);
	//
	// }

	// @RequestMapping(value = "/ajax/account.json", method = RequestMethod.GET)
	// public Map<String, String>updateProfile(@RequestParam Long
	// studentProfileId){
	// return studentService.getStudentDetails(studentProfileId);
	//
	// }

}

package com.intern.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppListItemsVO;
import com.intern.dto.AttachmentsVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserVO;
import com.intern.entity.Attachments;
import com.intern.entity.InternDetails;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.exception.InternException;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.UserRepository;
import com.intern.service.AdminService;
import com.intern.service.AttachmentService;
import com.intern.service.CompanyService;
import com.intern.service.InternDetailService;
import com.intern.service.StudentService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;

	// @Autowired
	// private UserService userService;

	@Autowired
	private StudentService studentService;

	@Autowired
	CompanyService companyService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	private InternDetailService internDetailService;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	AttachmentService attachmentService;

	@Autowired
	InternDetailsRepository internDetailsRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = AdminController.class.getName();
	private static final String METHOD_DOWNLOAD_RESUME = "download Resume";

	@RequestMapping(value = "/categoryUpdate", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute AppListItemsVO appListItemsVO, RedirectAttributes redirectAttrs) {
		try {
			adminService.saveCategoryDetails(appListItemsVO);
			redirectAttrs.addFlashAttribute("success", "Updated Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Invalid Update");
		}

		return "redirect:/admin";
	}

	@RequestMapping(value = "/deleteFromList")
	public String deleteFromList(@RequestParam Long internId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			adminService.deletePost(internId);
			redirectAttrs.addFlashAttribute("success", "Deleted Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/admin";

	}
	
	@RequestMapping(value = "/deletePostRequest")
	public String deletePostRequest(@RequestParam Long internId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			adminService.deletePost(internId);
			redirectAttrs.addFlashAttribute("success", "Deleted Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/admin";

	}

	@RequestMapping(value = "/deleteUserFromList")
	public String deleteUserFromList(@RequestParam Long userId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			adminService.deleteUser(userId);
			redirectAttrs.addFlashAttribute("success", "Deleted Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/admin";

	}

	@RequestMapping(value = "/editUserProfile")
	public String editPostedInternship(@RequestParam Long userId, ModelMap model) {
		UserVO userVO = adminService.editUsersProfile(userId);
		// model.addAttribute("userVO", userVO);
		// UserVO userVO = new UserVO();
		if (userVO.getUserCode().equals("Student")) {

			StudentProfileVO studentProfileVO = studentService.getStudentDetails(userId);
			model.addAttribute("studentProfileVO", studentProfileVO);
			return "studentProfile";
		} else {
			CompanyProfileVO companyProfileVO = companyService.getCompanyDetails(userId);
			model.addAttribute("companyProfileVO", companyProfileVO);
			return "companyProfile";
		}
	}

	@RequestMapping(value = "/approveUserProfile")
	public String approveUserProfile(@RequestParam Long userId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			adminService.approveUser(userId);
			redirectAttrs.addFlashAttribute("success", "Approved successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No user found");
		}

		return "redirect:/admin";
	}

	@RequestMapping(value = "/approveUserRequest")
	public String approveUserRequest(@RequestParam Long userStagingId, RedirectAttributes redirectAttrs) {
		try {
			adminService.approveUserRequest(userStagingId);
			redirectAttrs.addFlashAttribute("success", "Approved successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Some Error Occurs");
		}

		return "redirect:/admin";
	}

	@RequestMapping(value = "/deleteUserRequest")
	public String deleteUserRequest(@RequestParam Long userStagingId, ModelMap model,
			RedirectAttributes redirectAttrs) {
		try {
			adminService.deleteUserRegister(userStagingId);
			redirectAttrs.addFlashAttribute("success", "Rejected Successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No records found");
		}

		return "redirect:/admin";

	}

	@RequestMapping(value = "/approveInternshipPost")
	public String approveInternshipPost(@RequestParam Long internId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			adminService.approvePost(internId);
			redirectAttrs.addFlashAttribute("success", "Approved successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No user found");
		}

		return "redirect:/admin";
	}

	@RequestMapping(value = "/getPostDetails")
	public String getPostDetails(@RequestParam Long id, ModelMap model) {
		List<InternDetailsVO> internDetailsVO = internDetailService.getPostDetails(id);
		model.addAttribute("internDetailsVO", internDetailsVO);
		return "postDetails";

	}

	@RequestMapping(value = "{type}/attachmentUpload")
	public String AttachmentForm(@PathVariable String type, ModelMap model) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		AttachmentsVO attachmentsVO = new AttachmentsVO();
		attachmentsVO.setAttachmentType(type);
		attachmentsVO.setUserId(loginUser);
		model.addAttribute("attachmentsVO", attachmentsVO);
		return "attachmentUpload";
	}

	@RequestMapping(value = "/attachmentUpload", method = RequestMethod.POST)
	public String AttachmentFormSave(@ModelAttribute AttachmentsVO attachmentsVO, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes redirectAttrs) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		boolean isSaved = attachmentService.saveAttachment(attachmentsVO);
		if (isSaved) {
			redirectAttrs.addFlashAttribute("success", "Uploaded Successfully!!");
		} else {
			redirectAttrs.addFlashAttribute("error", "Not Uploaded!!");
		}
		if (loginUser.getUserCode().equals("Student")) {
			// return "redirect:/studentView?userId=" + loginUser.getId();
			return "redirect:/studentDashboardNew";
		} else if (loginUser.getUserCode().equals("Company")) {
			// return "redirect:/companyView?userId=" + loginUser.getId();
			return "redirect:/companyDashboardNew";
		} else {
			return "home";
		}
	}

	@RequestMapping(value = "/removeCompanyLogo")
	public String CompanyLogoRemove(Long attachId, Long userId, ModelMap model, RedirectAttributes redirectAttrs) {
		boolean isRemoved = attachmentService.removeAttachment(attachId);
		if (isRemoved) {
			redirectAttrs.addFlashAttribute("success", "Logo Removed Successfully!!");
		} else {
			redirectAttrs.addFlashAttribute("error", "Logo Not Removed!!");
		}
		// return "redirect:/companyView?userId=" + userId;
		return "redirect:/companyDashboardNew";
	}

	@RequestMapping(value = "/removeAvatar")
	public String studentAvatarRemove(Long attachId, Long userId, ModelMap model, RedirectAttributes redirectAttrs) {
		boolean isRemoved = attachmentService.removeAttachment(attachId);
		// StudentProfile user = adminService.getUserId(attachId);
		if (isRemoved) {
			redirectAttrs.addFlashAttribute("success", "Avatar Removed Successfully!!");
		} else {
			redirectAttrs.addFlashAttribute("error", "Avatar Not Removed!!");
		}
		// return "redirect:/studentView?userId=" + userId;
		return "redirect:/studentDashboardNew";
	}

	@RequestMapping(value = "/removeResume")
	public String studentResumeRemove(Long attachId, Long userId, ModelMap model, RedirectAttributes redirectAttrs) {
		boolean isRemoved = attachmentService.removeAttachment(attachId);
		if (isRemoved) {
			redirectAttrs.addFlashAttribute("success", "Resume Removed Successfully!!");
		} else {
			redirectAttrs.addFlashAttribute("error", "Resume Not Removed!!");
		}
		// return "redirect:/studentView?userId=" + userId;
		return "redirect:/studentDashboardNew";
	}

	// @RequestMapping(value = "/studentView/{id}")
	// public String studentProfileView(ModelMap model, @PathVariable("id") Long
	// id) {
	// List<StudentProfileVO> studentProfileVO =
	// studentService.getStudentProfileView(id);
	// model.addAttribute("studentProfileVO", studentProfileVO);
	// return "studentView";
	// }
	@RequestMapping(value = "{id}/downloadResume")
	public void getUserProfile(@PathVariable("id") Long userId, HttpServletResponse response,
			RedirectAttributes redirectAttrs) {

		try {
			adminService.downloadResume(userId, response);
		} catch (InternException | IOException ex) {
			LOGGER.error(CLASS_NAME, METHOD_DOWNLOAD_RESUME, ex);
			redirectAttrs.addFlashAttribute("info", "No Resume is Found .Please Upload Your Resume");
		}
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("MM/dd/yyyy"), true, 10));
	}

	@RequestMapping(value = "/getStudentDetailsView")
	public String getStudentDetailsView(@RequestParam Long userstaggingId, ModelMap model) {
		List<StudentDetailsVO> studentDetailsVO = adminService.getStudentDetailsToView(userstaggingId);
		model.addAttribute("studentDetailsVO", studentDetailsVO);
		return "studentDetails";

	}

	@RequestMapping(value = "/activateOrDeactivate")
	public String getUserStatus(@RequestParam Long userId, RedirectAttributes redirectAttrs) {

		try {
			adminService.activateOrDeactiveUser(userId);
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No user found");
		}
		User user = userRepository.findOne(userId);
		if (user.getIsActive().equals('Y')) {
			redirectAttrs.addFlashAttribute("success", "Active successfully");
			return "redirect:/admin";
		} else {
			redirectAttrs.addFlashAttribute("success", "Deactive successfully");
			return "redirect:/admin";
		}
	}

	@RequestMapping(value = "/activateOrDeactivatePost")
	public String getPostStatus(@RequestParam Long internId, RedirectAttributes redirectAttrs) {
		try {
			adminService.activateOrDeactivePost(internId);
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "No post found");
		}
		InternDetails internDetails = internDetailsRepository.findOne(internId);
		if (internDetails.getIsActive().equals('Y')) {
			redirectAttrs.addFlashAttribute("success", "Active successfully");
			return "redirect:/admin";
		} else {
			redirectAttrs.addFlashAttribute("success", "Deactive successfully");
			return "redirect:/admin";
		}
	}

	@RequestMapping(value = "/getUserDetails")
	public String getUserDetails(@RequestParam Long userId, ModelMap model) {
		List<StudentDetailsVO> studentDetailsVO = adminService.getUserDetails(userId);
		model.addAttribute("studentDetailsVO", studentDetailsVO);
		return "userDetails";

	}
}
package com.intern.controller;

import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.UserStagingVO;
import com.intern.dto.UserVO;
import com.intern.entity.User;
import com.intern.exception.InternException;
import com.intern.service.UserService;
import com.intern.service.UserStagingService;
import com.intern.utils.AppConstants;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;

@Controller
public class AuthenticationController extends MultiActionController {

	@Autowired
	private UserStagingService userStagingService;

	@Autowired
	private UserService userService;

	@Autowired
	private AuditorAwareService auditorAwareService;

	@Autowired
	HttpSession httpSession;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = AuthenticationController.class.getName();
	private static final String METHOD_RESET_PASSWORD = "resetPassword";
	private static final String METHOD_FORGOT_PASSWORD = "forgotPassword";
	private static final String METHOD_CHANGE_PASSWORD = "changePassword";
	// @Autowired
	// private UserStagingService userStagingService;

	// @RequestMapping(value = "signup", method = RequestMethod.GET)
	// public String userRegistration( ModelMap model) {
	// UserStagingVO userStagingVO = new UserStagingVO();
	// model.addAttribute("userStagingVO", userStagingVO);
	// return "header";
	//
	// }

	@RequestMapping(value = "signinUserType", method = RequestMethod.GET)
	public String login(Principal principal, HttpServletRequest request, HttpSession session,
			HttpServletResponse response) {
		return "auth/signInModel";
	}

	@RequestMapping(value = "success")
	public String loginSuccess(RedirectAttributes redirectAttrs) {
		redirectAttrs.addFlashAttribute("success", "Login successfully");
		return "redirect:/search";
	}

	// @RequestMapping(value = "callUserSignInUpModel", method =
	// RequestMethod.GET)
	// public static String callSignInUpModel(@RequestParam String psMode,
	// @RequestParam String psType, ModelMap model) {
	// UserVO userVO = new UserVO();
	// model.addAttribute("userVO", userVO);
	// UserStagingVO userStagingVO = new UserStagingVO();
	// model.addAttribute("psMode", psMode);
	// model.addAttribute("psRoleType", psType);
	// // model.addAttribute("userCode", psType);
	// if (psMode.equals("signin")) {
	// return "auth/userSignIn";
	// } else {
	// model.addAttribute("userStagingVO", userStagingVO);
	// return "auth/userSignInUpModel";
	// }
	// }
	@RequestMapping(value = "callUserSignInUpModel", method = RequestMethod.GET)
	public static String callSignInUpModel(@RequestParam String psMode, @RequestParam(required = false) String psType, ModelMap model) {
		UserVO userVO = new UserVO();
		model.addAttribute("userVO", userVO);
		UserStagingVO userStagingVO = new UserStagingVO();
		model.addAttribute("psMode", psMode);
		model.addAttribute("psType", psType);
		// model.addAttribute("userCode", psType);
		if (psMode.equals("signin")) {
			return "auth/userSignIn";
		} else {
			model.addAttribute("userStagingVO", userStagingVO);
			return "auth/userSignInUpModel";
		}
	}

	@RequestMapping(value = "callUserTypeModel", method = RequestMethod.GET)
	public String callsigninUserTypeModel(@RequestParam String psMode, ModelMap model) {
		model.addAttribute("psMode", psMode);
		return "auth/userTypeModel";
	}

	@RequestMapping(value = "/callsignupUserTypeModel", method = RequestMethod.GET)
	public String callsignupUserTypeModel() {
		return "signupUserType";
	}

	@RequestMapping(value = "/callUserSignIn", method = RequestMethod.GET)
	public String userSignIn(@RequestParam String psType, ModelMap model) {
		model.addAttribute("psType", psType);
		return "userSignIn";
	}

	@RequestMapping(value = "/userSignIn", method = RequestMethod.GET)
	public String getUser(@ModelAttribute UserVO userVO, @RequestParam String loginId,
			RedirectAttributes redirectAttrs) {
		try {
			userService.getEmailId(loginId);
			redirectAttrs.addFlashAttribute("success", "Login successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("info", "Invalid username or password");
		}

		return "redirect:/home";
	}

	@RequestMapping(value = "/callUserSignUp", method = RequestMethod.GET)
	public String userSignUp() {
		return "userSignUp";
	}

	@RequestMapping(value = "/userSignUp", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute UserStagingVO userStagingVO, RedirectAttributes redirectAttrs) {
		try {
			userStagingService.saveUserDetails(userStagingVO);
			redirectAttrs.addFlashAttribute("success",
					"Registered successfully , Please wait for get Approval from our admin");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Invalid UserName and Password ");
		}

		return "redirect:/home";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String userRegistration() {
		return "register";

	}

	// @RequestMapping(value = "auth/userSignIn", method = RequestMethod.GET)
	// public String signInError(@RequestParam(required = false) String error,
	// RedirectAttributes redirectAttrs,
	// ModelMap model) {
	//
	// if (error.equals("1")) {
	// redirectAttrs.addFlashAttribute("error", "Invalid User Name or
	// Password");
	// }
	// // try {
	// // userService.getEmailId(loginId);
	// // redirectAttrs.addFlashAttribute("success", "Login successfully");
	// // } catch (Exception ex) {
	// // ex.getMessage();
	// // redirectAttrs.addFlashAttribute(ex.getMessage(), "Invalid User Name
	// // or Password");
	// // }
	// // try {
	// // userService.getEmailId(loginId);
	// // } catch (InternException e) {
	// // // TODO Auto-generated catch block
	// // e.printStackTrace();
	// // }
	// return "redirect:/home";
	// }

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String signInError(@RequestParam(required = false) String error, RedirectAttributes redirectAttrs,
			ModelMap model) {

		if (error != null) {
			redirectAttrs.addFlashAttribute("error", "Invalid User Name or Password");
		}
		User loginUser = auditorAwareService.getCurrentAuditor();
		httpSession.setAttribute(AppConstants.LOGIN_USER, loginUser);
		if (loginUser == null) {
			httpSession.setAttribute(AppConstants.USER_CODE, null);
		}
		// Redirect based on login role
		if (loginUser == null) {
			return "redirect:/home";
		} else if (loginUser.getUserCode().equalsIgnoreCase(User.USER_TYPE_STUDENT)) {
			redirectAttrs.addFlashAttribute("success", "Login successfully");
			return "redirect:/home";
		} else if (loginUser.getUserCode().equalsIgnoreCase(User.USER_TYPE_COMPANY)) {
			redirectAttrs.addFlashAttribute("success", "Login successfully");
			return "redirect:/companyDashboardNew";
		} else if (loginUser.getUserCode().equalsIgnoreCase(User.USER_TYPE_ADMIN_ROLES)) {
			redirectAttrs.addFlashAttribute("success", "Login successfully");
			return "redirect:/admin";
		} else {
			return "redirect:/home";
		}

	}

	@RequestMapping(value = "/forgotPassword")
	// public String getPasswordByEmailId(@RequestParam String loginId) {
	public String getPasswordByEmailId(@RequestParam String loginId, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			userService.getEmailId(loginId);
			redirectAttrs.addFlashAttribute("info", "Reset Your Password");
		} catch (InternException ex) {
			LOGGER.error(CLASS_NAME, METHOD_FORGOT_PASSWORD, ex);
			redirectAttrs.addFlashAttribute("error", "Invalid User Name");
			return "redirect:/home";
		}
		UserVO userVO = new UserVO();
		model.addAttribute("userVO", userVO);
		return "changePassword";
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public String getNewPassword(@ModelAttribute UserVO userVO, RedirectAttributes redirectAttrs) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		try {
			userService.changeUserPassword(userVO);
			redirectAttrs.addFlashAttribute("info",
					"Your new password has been updated. Please login with your new password.");
		} catch (InternException ex) {
			LOGGER.error(CLASS_NAME, METHOD_CHANGE_PASSWORD, ex);
			if (loginUser != null) {
				if (loginUser.getUserCode().equals("Student")) {
					redirectAttrs.addFlashAttribute("Error", "Invalid User Name");
					//return "redirect:/studentView?userId=" + loginUser.getId();
					return "redirect:/studentDashboardNew";
				} else if (loginUser.getUserCode().equals("Company")) {
					redirectAttrs.addFlashAttribute("Error", "Invalid User Name");
					//return "redirect:/companyView?userId=" + loginUser.getId();
					return "redirect:/companyDashboardNew";
				}
			}
		}
		if (loginUser != null) {
			if (loginUser.getUserCode().equals("Student")) {
				//return "redirect:/studentView?userId=" + loginUser.getId();
				return "redirect:/studentDashboardNew";
			} else if (loginUser.getUserCode().equals("Company")) {
				//return "redirect:/companyView?userId=" + loginUser.getId();
				return "redirect:/companyDashboardNew";
			}
		}
		return "redirect:/home";

	}

	@RequestMapping(value = "/activateStatus", method = RequestMethod.POST)
	public String getAccountActiveOrDeactive(@ModelAttribute UserVO userVO) {
		//User loginUser = auditorAwareService.getCurrentAuditor();
		userService.updateUserActiveStatus(userVO);
//		if (loginUser.getUserCode().equals("Student")) {
//			return "redirect:/studentView?userId=" + loginUser.getId();
//		} else {
//			return "redirect:/companyView?userId=" + loginUser.getId();
//		}
		return "redirect:/home";
	}
	// @RequestMapping(value = "profile")
	// public String getProfile(@RequestParam String psType, ModelMap model) {
	// model.addAttribute("psType", psType);
	// if (psType == "Student") {
	// return "studentProfile";
	// } else {
	// return "companyProfile";
	// }
	// }
}

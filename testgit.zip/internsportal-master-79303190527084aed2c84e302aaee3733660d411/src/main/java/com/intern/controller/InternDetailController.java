package com.intern.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.dto.InternDetailsVO;
import com.intern.service.InternDetailService;

@Controller
public class InternDetailController {

	@Autowired
	private InternDetailService internDetailService;

	@RequestMapping(value = "/postInternships", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute InternDetailsVO internDetailsVO, RedirectAttributes redirectAttrs) {
		try {
			internDetailService.saveInternDetails(internDetailsVO);
			redirectAttrs.addFlashAttribute("success", "Internship post updated");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("error", "Invalid Post");
		}
		return "redirect:/companyDashboardNew";
	}
	// @RequestMapping(value = "/admin" , method = RequestMethod.GET)
	// public String getActivePost(ModelMap model) {
	// String listActivePosts = internDetailService.listPosts();
	// model.addAttribute("listActivePosts", listActivePosts);
	// return "admin";
	// }

}

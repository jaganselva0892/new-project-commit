package com.intern.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.intern.controller.AuthenticationController;
import com.intern.auditor.AuditorAwareService;
import com.intern.utils.AppConstants;
import com.intern.dto.AppListItemsVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.SearchFilteringVO;
import com.intern.dto.StudentsSkillsVO;
import com.intern.dto.UserStagingVO;
import com.intern.entity.AppListItems;
import com.intern.entity.InternDetails;
import com.intern.entity.User;
import com.intern.exception.InternException;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.service.SearchService;
import com.intern.utils.AppConstants;

@Controller
public class SearchController {

	@Autowired
	SearchService searchService;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	HttpSession httpSession;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = SearchController.class.getName();
	private static final String METHOD_NO_SEARCH_RESULTS = "search Results not found";

	@RequestMapping(value = "/search")
	public String searchInternship(@RequestParam(required = false) String searchKey, @RequestParam(required = false) Long searchCompany , @RequestParam(required = false) String searchType,
			@RequestParam(required = false) SearchFilteringVO srcFilteringVO,
			@RequestParam(required = false) String searchFrom, ModelMap model, RedirectAttributes redirectAttrs) {
		try {
			List<InternDetailsVO> internDetailsVO = new ArrayList<>();
			// Left panel search page
			SearchFilteringVO searchFilteringVOs = searchService.getSearchDetails();
			searchFilteringVOs.setSearchKey(searchKey);
			if(srcFilteringVO != null ){
				searchFilteringVOs.setEligibility(srcFilteringVO.getEligibility());
				searchFilteringVOs.setUserCity(srcFilteringVO.getUserCity());
				searchFilteringVOs.setSkillsRequired(srcFilteringVO.getSkillsRequired());
				searchFilteringVOs.setInternshipType(srcFilteringVO.getInternshipType());
			}
			

			// Search by using keyword only
			if (searchFrom == null) {
				internDetailsVO = searchService.searchInternDetails(searchKey);
			} else if (srcFilteringVO != null) {
				internDetailsVO = searchService.leftPanelSearchPosts(srcFilteringVO);
			}
			if (searchKey == null && srcFilteringVO == null) {
				if (searchType != null) {
					searchFilteringVOs.setInternshipType(searchType.trim());
					SearchFilteringVO searchrcFilteringVO = new SearchFilteringVO();
					searchrcFilteringVO.setInternshipType(searchType);
					internDetailsVO = searchService.leftPanelSearchPosts(searchrcFilteringVO);
				}
			}
			if (searchKey == null && srcFilteringVO == null && searchType == null) {
				if(searchCompany != null){
					internDetailsVO = searchService.searchByCompany(searchCompany);
				}
			}
			// Searched Internships model
			model.addAttribute("internDetailsVO", internDetailsVO);
			// Apply internship model to be empty
			InternDetailsVO saveInternDetailsVO = new InternDetailsVO();
			model.addAttribute("saveInternDetailsVO", saveInternDetailsVO);
			model.addAttribute("searchFilteringVO", searchFilteringVOs);
			if (internDetailsVO.size() == 0) {
				redirectAttrs.addFlashAttribute("error", "Sorry ! No Results Found");
				return "search";
			} else {
				redirectAttrs.addFlashAttribute("info", "Search Results");
				return "search";
			}
		} catch (InternException | IOException ex) {
			LOGGER.error(CLASS_NAME, METHOD_NO_SEARCH_RESULTS, ex);
			redirectAttrs.addFlashAttribute("info", "Sorry ! No Results Found");
			return "search";
		}

	}

	@RequestMapping(value = "/ajax/searchStream.json", method = RequestMethod.GET)
	@ResponseBody
	public String getDetail(@RequestParam String appListItemsName, ModelMap model) {

		Map<String, Object> listName = searchService.getStreamName(appListItemsName);
		model.addAttribute("applistitemsName", listName);
		return "search";
	}

	@RequestMapping(value = "/applYForInternPost", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute InternDetailsVO saveInternDetailsVO, @RequestParam String callbackScreen,
			RedirectAttributes redirectAttrs, HttpServletRequest request) {
		try {
			searchService.saveAppliedDetails(saveInternDetailsVO);
			redirectAttrs.addFlashAttribute("success", "Applied successfully");
		} catch (Exception ex) {
			ex.getMessage();
			redirectAttrs.addFlashAttribute("info", "Already applied");
		}
		// return "redirect:" + saveInternDetailsVO.getCallbackScreen();
		String referer = request.getHeader("Referer");
		return "redirect:" + referer;
	}

	// @RequestMapping(value = "/applyforPostAfterLogin")
	// public String applyForPost(@RequestParam Long internId, ModelMap model) {
	//// String psType = null , psMode = null;
	//// com.intern.controller.AuthenticationController.callSignInUpModel(psMode,
	// psType, model);
	// User loginUser = (User)
	// httpSession.getAttribute(AppConstants.LOGIN_USER);
	// if(loginUser == null)
	// {
	// return "auth/userSignIn";
	// }
	// InternDetailsVO saveInternDetailsVO =
	// searchService.findByInternId(internId);
	// saveUser(saveInternDetailsVO);
	// return "redirect:/search";
	// }

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public String leftPanelSearch(@ModelAttribute SearchFilteringVO searchFilteringVO, ModelMap model,
			RedirectAttributes redirectAttrs) {
		// searchService.searchByVariousCategories(searchFilteringVO);
		// return "redirect:/search";
		// redirectAttrs.addFlashAttribute("info", "Search Results");
		return searchInternship(searchFilteringVO.getSearchKey(),null,AppConstants.SEARCH_BY_TYPE, searchFilteringVO, AppConstants.LEFT_SIDE, model,
				redirectAttrs.addFlashAttribute("info", "Search Results"));
	}

	@RequestMapping(value = "/getMoreDetailsView")
	public String getCompanyDetailsToView(Long internId, ModelMap model) {
		List<InternDetailsVO> internDetails = searchService.getMoreDetails(internId);
		model.addAttribute("internDetailsVO", internDetails);
		return "viewMoreDetails";

	}

}

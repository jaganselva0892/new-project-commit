package com.intern.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppListItems;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.UserContact;

public class SearchFilteringVO extends BaseVO {

	private static final long serialVersionUID = 2872758505694201459L;

	private Long id;
	private String skillsRequired;
	private String appListItemsName;
	private String eligibility;
	private String internshipType;
	private String userCity;
	private List<String> internType = null;
	private List<AppListItems> streamName;
	private List<AppListItems> skillRequired;
	
	private String searchKey = null;

	public SearchFilteringVO(){
		
	}
	
	public SearchFilteringVO(InternDetails intern) {
		BeanUtils.copyProperties(intern, this);
		this.setId(intern.getId());
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		SearchFilteringVO other = (SearchFilteringVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getAppListItemsName() {
		return appListItemsName;
	}

	public void setAppListItemsName(String appListItemsName) {
		this.appListItemsName = appListItemsName;
	}

	public String getInternshipType() {
		return internshipType;
	}

	public void setInternshipType(String internshipType) {
		this.internshipType = internshipType;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getSkillsRequired() {
		return skillsRequired;
	}

	public void setSkillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public List<AppListItems> getSkillRequired() {
		return skillRequired;
	}

	public void setSkillRequired(List<AppListItems> skillRequired) {
		this.skillRequired = skillRequired;
	}

	public List<AppListItems> getStreamName() {
		return streamName;
	}

	public void setStreamName(List<AppListItems> streamName) {
		this.streamName = streamName;
	}
	
	public String getSearchKey() {
		return searchKey;
	}

	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}

}

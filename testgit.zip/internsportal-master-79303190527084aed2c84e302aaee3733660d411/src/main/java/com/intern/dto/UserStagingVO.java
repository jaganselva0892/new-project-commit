package com.intern.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.UserStaging;
import com.intern.entity.User;

import java.util.List;

public class UserStagingVO extends BaseVO {

	private static final long serialVersionUID = 9072586263496389248L;

	private String userName;
	// private String userCode;
	private String userEmailId;
	private String userOrganization;
	private String userMobileNumber;
	private String password;
	private String userCode;
	private String userStatus;
	private String studentAdharCardNumber;
	private String companyWebsite;
	public UserStagingVO() {

	}

	public UserStagingVO(UserStaging userStaging) {
		BeanUtils.copyProperties(userStaging, this);
		this.setId(userStaging.getId());
	}

//	public UserStagingVO(UserStaging userStaging, List<UserVO> userVO) {
//		this(userStaging);
//		this.userVO = userVO;
//
//	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserStagingVO other = (UserStagingVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	// public String getUserCode() {
	// return userCode;
	// }
	//
	// public void setUserCode(String userCode) {
	// this.userCode = userCode;
	// }

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getUserOrganization() {
		return userOrganization;
	}

	public void setUserOrganization(String userOrganization) {
		this.userOrganization = userOrganization;
	}

	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getStudentAdharCardNumber() {
		return studentAdharCardNumber;
	}

	public void setStudentAdharCardNumber(String studentAdharCardNumber) {
		this.studentAdharCardNumber = studentAdharCardNumber;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
}

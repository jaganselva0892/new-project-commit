package com.intern.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppListItems;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.User;

public class HomeVO extends BaseVO {

	private static final long serialVersionUID = -7982442893773607217L;

	private String category;
	private String categoryType;
	private Map<String, String> skillsMap = null;
	private Map<String, String> streamMap = null;
	private String skills;
	private String stream;
	private String name;
	private String emailId;
	private String feedbackDesc;

	public HomeVO() {

	}

	public HomeVO(List<AppListItems> skillRequired, List<AppListItems> streamName) {
		String skillNames = "";
		for (AppListItems appSkills : skillRequired) {
			if (skillNames.equals("")) {
				skillNames = skillNames + appSkills.getAppListItemsName();
			} else {
				skillNames = skillNames + ", " + appSkills.getAppListItemsName();
			}
			skills = skillNames;
		}
		// streamMap = new LinkedHashMap<>(streamName.size());
		String streams = "";
		for (AppListItems appStream : streamName) {
			// streamMap.put(appStream.getAppListItemsType(),
			// appStream.getAppListItemsName());
			if (streams.equals("")) {
				streams = streams + appStream.getAppListItemsName();
			} else {
				streams = streams + ", " + appStream.getAppListItemsName();
			}
			stream = streams;
		}
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		HomeVO other = (HomeVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public Map<String, String> getSkillsMap() {
		return skillsMap;
	}

	public void setSkillsMap(Map<String, String> skillsMap) {
		this.skillsMap = skillsMap;
	}

	public Map<String, String> getStreamMap() {
		return streamMap;
	}

	public void setStreamMap(Map<String, String> streamMap) {
		this.streamMap = streamMap;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getFeedbackDesc() {
		return feedbackDesc;
	}

	public void setFeedbackDesc(String feedbackDesc) {
		this.feedbackDesc = feedbackDesc;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

package com.intern.dto.base;

import java.io.Serializable;

public class BaseVO implements Serializable {

	private static final long serialVersionUID = 7292640492687851787L;

	private Long id = null;

	/********************** Getters and Setters **********************/

	public Long getId() {
		return id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public boolean isNew() {
		return id == null ? true : false;
	}

	/********************** toString methods **********************/

	@Override
	public String toString() {
		return String.format("%s [id = %d]", this.getClass().getName(), this.getId());
	}

}

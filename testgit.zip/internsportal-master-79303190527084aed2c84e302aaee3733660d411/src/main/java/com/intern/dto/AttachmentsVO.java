package com.intern.dto;

//import java.util.Date;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import com.intern.dto.base.BaseVO;
import com.intern.entity.Attachments;
import com.intern.entity.User;
import com.intern.utils.AppConstants;

public class AttachmentsVO extends BaseVO {

	private static final long serialVersionUID = -4928902307094179385L;

	private String attachmentType;
	private String fileName;
	private String fileExtension;
	private String fileContentType;
	private Long fileSize;
	private byte[] attachmentData;
	private User userId;
	
	private String baseString = null;
	
	private MultipartFile attachmentFile = null;
	
	private String callBackScreen = null;

	public AttachmentsVO() {
	}

	public AttachmentsVO(Attachments attachments){
		BeanUtils.copyProperties(attachments, this);
	}
	
	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AttachmentsVO other = (AttachmentsVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getAttachmentType() {
		return attachmentType;
	}

	public void setAttachmentType(String attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String file_name) {
		this.fileName = file_name;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public byte[] getAttachmentData() {
		return attachmentData;
	}

	public void setAttachmentData(byte[] attachmentData) {
		this.attachmentData = attachmentData;
	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}
	
	public MultipartFile getAttachmentFile(){
		return attachmentFile;
	}
	
	public void setAttachmentFile(MultipartFile attachmentFile){
		this.attachmentFile = attachmentFile;
	}
	
	public String getCallBackScreen() {
		return callBackScreen;
	}

	public void setCallBackScreen(String callBackScreen) {
		this.callBackScreen = callBackScreen;
	}
	
	public String getBaseString(){
		return baseString;
	}
	
	public void setBaseString(String baseString){
		this.baseString = baseString;
	}
}

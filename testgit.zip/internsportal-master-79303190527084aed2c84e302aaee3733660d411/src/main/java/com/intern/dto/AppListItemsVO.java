package com.intern.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.CompanyProfile;
import com.intern.entity.UserContact;

public class AppListItemsVO extends BaseVO{
	
	
	private static final long serialVersionUID = -1314216406369363173L;
	
	private Long appListItemsId;
	private String appListItemsType;
	private String appListItemsName;
	
	public AppListItemsVO() {

	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppListItemsVO other = (AppListItemsVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppListItemsId() {
		return appListItemsId;
	}

	public void setAppListItemsId(Long appListItemsId) {
		this.appListItemsId = appListItemsId;
	}
	public String getAppListItemsType() {
		return appListItemsType;
	}

	public void setAppListItemsType(String appListItemsType) {
		this.appListItemsType = appListItemsType;
	}

	public String getAppListItemsName() {
		return appListItemsName;
	}

	public void setAppListItemsName(String appListItemsName) {
		this.appListItemsName = appListItemsName;
	}

}

package com.intern.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppListItems;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.UserContact;

public class StudentDetailsVO extends BaseVO {

	private static final long serialVersionUID = -4908796827557653965L;
	private String studentFirstName;
	private String studentFieldExperience;
	private Long studentYearOfPassing;
	private String studentInstitutionName;
	private String skillName;
	private String streamName;
	private String mobileNumber;
	private String userAddress;
	private String userCity;
	private String userState;
	private String userCountry;
	private String userCode;
	private String studentAdharCardNumber;
	private String companyWebsite;
	private String companyEmail;
	private String companyName;
	private Map<String, String> studentsMap;
	private Map<Long, String> skillsMap = null;
	private Map<Long, String> streamMap = null;
	private String skillNames = null;

	public StudentDetailsVO() {

	}

	public StudentDetailsVO(StudentProfile studentProfile, List<String> skillList, List<StudentsSkills> stream,
			UserContact userContact) {
		BeanUtils.copyProperties(studentProfile, this);
		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		if (skillList != null) {
			String keyAndValue = "";
			for (String strSkillName : skillList) {
				if (keyAndValue.equals("")) {
					keyAndValue = keyAndValue + strSkillName;
				} else {
					keyAndValue = keyAndValue + ", " + strSkillName;
				}

				skillNames = keyAndValue;
			}
		}
		if (stream != null) {
			streamMap = new LinkedHashMap<>(stream.size());
			for (StudentsSkills streamName : stream) {
				streamMap.put(streamName.getStudentProfileId().getId(), streamName.getSkillName());
			}
		}

	}

	public StudentDetailsVO(StudentProfile studentProfile, List<StudentsSkills> studentDetails,
			UserContact userContact) {
		BeanUtils.copyProperties(studentProfile, this);
		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		List<StudentsSkills> skillList = new ArrayList<>(studentDetails.size());
		for (StudentsSkills skillName : studentDetails) {
			// this.setSkills(skillName.getSkillName().concat(",").concat(skillName.getSkillName()));

			// skillList.add(skillName);
		}
		// this.setSkills(skillList);
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		StudentProfileVO other = (StudentProfileVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentFieldExperience() {
		return studentFieldExperience;
	}

	public void setStudentFieldExperience(String studentFieldExperience) {
		this.studentFieldExperience = studentFieldExperience;
	}

	public Long getStudentYearOfPassing() {
		return studentYearOfPassing;
	}

	public void setStudentYearOfPassing(Long studentYearOfPassing) {
		this.studentYearOfPassing = studentYearOfPassing;
	}

	public String getStudentInstitutionName() {
		return studentInstitutionName;
	}

	public void setStudentInstitutionName(String studentInstitutionName) {
		this.studentInstitutionName = studentInstitutionName;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public Map<String, String> getStudentsMap() {
		return studentsMap;
	}

	public void setStudentsMap(Map<String, String> studentsMap) {
		this.studentsMap = studentsMap;
	}

	public Map<Long, String> getSkillsMap() {
		return skillsMap;
	}

	public void setSkillsMap(Map<Long, String> skillsMap) {
		this.skillsMap = skillsMap;
	}

	public Map<Long, String> getStreamMap() {
		return streamMap;
	}

	public void setStreamMap(Map<Long, String> streamMap) {
		this.streamMap = streamMap;
	}

	public String getSkillNames() {
		return skillNames;
	}

	public void setSkillNames(String skillNames) {
		this.skillNames = skillNames;
	}

	public String getStudentAdharCardNumber() {
		return studentAdharCardNumber;
	}

	public void setStudentAdharCardNumber(String studentAdharCardNumber) {
		this.studentAdharCardNumber = studentAdharCardNumber;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

}

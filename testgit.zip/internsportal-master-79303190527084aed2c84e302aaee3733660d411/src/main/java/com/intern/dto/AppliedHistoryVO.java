package com.intern.dto;

import java.util.Date;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppliedHistory;
import com.intern.entity.InternDetails;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;

public class AppliedHistoryVO extends BaseVO {

	private static final long serialVersionUID = 6576057119764897255L;
	private Long userId;
	private InternDetails internDetailsId;
	private String appliedStatus;
	private Long viewCount;
	private String studentFieldExperience;
	private String studentEmail;
	private String streamName;
	private String internshipTitle;
	private String appliedDate;
	private String companyName;

	public AppliedHistoryVO() {

	}

	public AppliedHistoryVO(AppliedHistory appliedHistory) {
		BeanUtils.copyProperties(appliedHistory, this);
		this.setId(appliedHistory.getId());

	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppliedHistoryVO other = (AppliedHistoryVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public InternDetails getInternDetailsId() {
		return internDetailsId;
	}

	public void setInternDetailsId(InternDetails internDetailsId) {
		this.internDetailsId = internDetailsId;
	}

	public String getAppliedStatus() {
		return appliedStatus;
	}

	public void setAppliedStatus(String appliedStatus) {
		this.appliedStatus = appliedStatus;
	}

	public Long getViewCount() {
		return viewCount;
	}

	public void setViewCount(Long viewCount) {
		this.viewCount = viewCount;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentFieldExperience() {
		return studentFieldExperience;
	}

	public void setStudentFieldExperience(String studentFieldExperience) {
		this.studentFieldExperience = studentFieldExperience;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public String getInternshipTitle() {
		return internshipTitle;
	}

	public void setInternshipTitle(String internshipTitle) {
		this.internshipTitle = internshipTitle;
	}

	public String getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

}

package com.intern.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import com.intern.dto.base.BaseVO;
import com.intern.entity.CompanyProfile;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.utils.AppConstants;

public class CompanyProfileVO extends BaseVO {

	private static final long serialVersionUID = 6913644487707168469L;

	private User userId;
	private String userCode;
	private String companyName;
	private String companyShortName;
	private String companyEmail;
	private String companyAlternateEmail;
	private String companyWebsite;
	private String companyDescription;
	private String companyProfileStatus;
	private String mobileNumber;
	private String userAddress;
	private String userCity;
	private String userState;
	private String userCountry;
	private boolean isCompanyActive = true;
	private MultipartFile companyLogo = null;
	private AttachmentsVO attachmentsVO = null;
	private String logoBaseString = null;
	private Character isLogo = AppConstants.NO;
	
	public CompanyProfileVO() {

	}

	public CompanyProfileVO(CompanyProfile companyProfile, UserContact userContact) {
		BeanUtils.copyProperties(companyProfile, this);
		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		this.setId(companyProfile.getId());
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CompanyProfileVO other = (CompanyProfileVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyShortName() {
		return companyShortName;
	}

	public void setCompanyShortName(String companyShortName) {
		this.companyShortName = companyShortName;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getCompanyAlternateEmail() {
		return companyAlternateEmail;
	}

	public void setCompanyAlternateEmail(String companyAlternateEmail) {
		this.companyAlternateEmail = companyAlternateEmail;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public String getCompanyProfileStatus() {
		return companyProfileStatus;
	}

	public void setCompanyProfileStatus(String companyProfileStatus) {
		this.companyProfileStatus = companyProfileStatus;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public boolean getIsCompanyActive() {
		return isCompanyActive;
	}

	public void setIsCompanyActive(boolean isCompanyActive) {
		this.isCompanyActive = isCompanyActive;
	}
	
	public MultipartFile getCompanyLogo(){
		return companyLogo;
	}
	
	public void setCompanyLogo(MultipartFile companyLogo){
		this.companyLogo = companyLogo;
	}
	
	public AttachmentsVO getAttachmentsVO(){
		return attachmentsVO;
	}
	
	public void setAttachmentsVO(AttachmentsVO attachmentsVO){
		this.attachmentsVO = attachmentsVO;
	}
	
	public String getLogoBaseString(){
		return logoBaseString;
	}
	
	public void setLogoBaseString(String logoBaseString){
		this.logoBaseString = logoBaseString;
	}
	
	public Character getIsLogo(){
		return isLogo;
	}
	
	public void setIsLogo(Character isLogo){
		this.isLogo = isLogo;
	}
}

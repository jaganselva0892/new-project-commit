package com.intern.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppListItems;
import com.intern.entity.AppliedHistory;
import com.intern.entity.CompanyProfile;
import com.intern.entity.InternDetails;
import com.intern.entity.User;
import com.intern.entity.UserContact;

public class InternDetailsVO extends BaseVO {

	private static final long serialVersionUID = -3139309549103502607L;

	private User userId;
	private String internshipTitle;
	private String postedDate;
	private String internshipType;
	private String applyDate;
	private String duration;
	private String stipend;
	private String position;
	private String eligibility;
	private String skillsRequired;
	private String vacancies;
	private String paidOrUnpaid;
	private String industry;
	private String category;
	private String startAndEndDate;
	private String internshipDescription;
	private String perks;
	private String mobileNumber;
	private String userAddress;
	private String userCity;
	private String userState;
	private String userCountry;
	private String companyName;
	private String companyWebsite;
	private String companyDescription;
	private String appliedStatus;
	private String endDate;
	private String companyEmail;
	private String status;
	private String callbackScreen = null;
	private List<AppListItems> skillRequired;
	private List<AppListItems> streamRequired;
	private String skillNames = null;
	private String streamNames = null;
	private String isActive;

	public InternDetailsVO() {

	}

	public InternDetailsVO(InternDetails internDetails, List<AppListItems> skillRequired,
			List<AppListItems> appStream) {
		BeanUtils.copyProperties(internDetails, this);
		this.setId(internDetails.getId());
		this.setStipend(internDetails.getStipend());
		this.setInternshipType(internDetails.getInternshipType());
		List<AppListItems> appList = new ArrayList<>(skillRequired.size());
		List<AppListItems> appListStreams = new ArrayList<>(appStream.size());
		for (AppListItems skills : skillRequired) {
			appList.add(skills);
		}
		for (AppListItems stream : appStream) {
			appListStreams.add(stream);
		}
		this.setSkillRequired(appList);
		this.setStreamRequired(appListStreams);

	}

	public InternDetailsVO(InternDetails internDetails) {
		BeanUtils.copyProperties(internDetails, this);
		this.setId(internDetails.getId());

	}

	public InternDetailsVO(List<InternDetails> internDetails, CompanyProfile companyProfile) {
		BeanUtils.copyProperties(internDetails, this);
		if (companyProfile != null) {
			this.setCompanyName(companyProfile.getCompanyName());
			this.setCompanyWebsite(companyProfile.getCompanyWebsite());
		}
		this.setId(companyProfile.getId());
	}

	public InternDetailsVO(InternDetails internDetails, CompanyProfile companyProfile, UserContact userContact) {
		BeanUtils.copyProperties(internDetails, this);

		if (companyProfile != null) {
			this.setCompanyName(companyProfile.getCompanyName());
			this.setCompanyWebsite(companyProfile.getCompanyWebsite());
		}

		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		this.setId(companyProfile.getId());
	}

	public InternDetailsVO(InternDetails internDetails, AppliedHistory appliedHistory) {
		BeanUtils.copyProperties(internDetails, this);
		if (appliedHistory != null) {
			this.setAppliedStatus(appliedHistory.getAppliedStatus());

		}
		this.setId(internDetails.getId());
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		InternDetailsVO other = (InternDetailsVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public String getInternshipTitle() {
		return internshipTitle;
	}

	public void setInternshipTitle(String internshipTitle) {
		this.internshipTitle = internshipTitle;
	}

	public String getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(String postedDate) {
		this.postedDate = postedDate;
	}

	public String getInternshipType() {
		return internshipType;
	}

	public void setInternshipType(String internshipType) {
		this.internshipType = internshipType;
	}

	public String getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getStipend() {
		return stipend;
	}

	public void setStipend(String stipend) {
		this.stipend = stipend;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getSkillsRequired() {
		return skillsRequired;
	}

	public void setSkillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
	}

	public String getVacancies() {
		return vacancies;
	}

	public void setVacancies(String vacancies) {
		this.vacancies = vacancies;
	}

	public String getPaidOrUnpaid() {
		return paidOrUnpaid;
	}

	public void setPaidOrUnpaid(String paidOrUnpaid) {
		this.paidOrUnpaid = paidOrUnpaid;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getStartAndEndDate() {
		return startAndEndDate;
	}

	public void setStartAndEndDate(String startAndEndDate) {
		this.startAndEndDate = startAndEndDate;
	}

	public String getInternshipDescription() {
		return internshipDescription;
	}

	public void setInternshipDescription(String internshipDescription) {
		this.internshipDescription = internshipDescription;
	}

	public String getPerks() {
		return perks;
	}

	public void setPerks(String perks) {
		this.perks = perks;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getAppliedStatus() {
		return appliedStatus;
	}

	public void setAppliedStatus(String appliedStatus) {
		this.appliedStatus = appliedStatus;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public List<AppListItems> getSkillRequired() {
		return skillRequired;
	}

	public void setSkillRequired(List<AppListItems> skillRequired) {
		this.skillRequired = skillRequired;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCallbackScreen() {
		return callbackScreen;
	}

	public void setCallbackScreen(String callbackScreen) {
		this.callbackScreen = callbackScreen;
	}

	public String getSkillNames() {
		return skillNames;
	}

	public void setSkillNames(String skillNames) {
		this.skillNames = skillNames;
	}

	public String getStreamNames() {
		return streamNames;
	}

	public void setStreamNames(String streamNames) {
		this.streamNames = streamNames;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
	public List<AppListItems> getStreamRequired() {
		return streamRequired;
	}

	public void setStreamRequired(List<AppListItems> streamRequired) {
		this.streamRequired = streamRequired;
	}
}
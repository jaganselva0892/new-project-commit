package com.intern.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import com.intern.dto.base.BaseVO;
import com.intern.entity.AppListItems;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.UserContact;
import com.intern.utils.AppConstants;

public class StudentProfileVO extends BaseVO {
	@DateTimeFormat(pattern = "MM/dd/yyyy")

	private static final long serialVersionUID = -5709969954526480007L;

	private Long userId;
	private String userCode;
	private String studentFirstName;
	private String studentLastName;
	private String studentEmail;
	private String studentAlternateEmail;
	private String password;
	private String studentInstitutionName;
	private Character studentWorkStatus;
	private String studentFieldExperience;
	private String studentGender;
	private String studentDateOfBirth;
	private String studentSkills;
	private Character studentProfileStatus;
	private Long studentYearOfPassing;
	private String mobileNumber;
	private String userAddress;
	private String userCity;
	private String userState;
	private String userCountry;
	private String studentAdharCardNumber;
	private String skillName;
	private String streamName;
	private boolean isStudentActive = true;
	
	private MultipartFile studentImage = null;
	private MultipartFile studentResume = null;
	private List<AttachmentsVO> attachmentsVOs = null;
	
	private Map<String, String> studentsMap;
	// private Map<String, String> skillsMap;
	// private Map<String, String> streamMap;
	private Map<Long, String> skillsMap = null;
	private Map<Long, String> streamMap = null;
	private List<StudentsSkills> skillRequired;
	private List<AppListItems> appSkills;
	private List<AppListItems> appStream;
	private String skillNames = null;
	private MultipartFile avatar = null;
	private AttachmentsVO attachmentsVO = null;
	private String avatarBaseString = null;
	private Character isAvatar = AppConstants.NO;
	private Character isResume = AppConstants.NO;
	private MultipartFile resume = null;
	private String resumeBaseString = null;

	public StudentProfileVO() {

	}

	public StudentProfileVO(StudentProfile studentProfile, UserContact userContact, List<AppListItems> appSkills,
			List<AppListItems> appStream) {
		BeanUtils.copyProperties(studentProfile, this);
		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		List<AppListItems> appList = new ArrayList<>(appSkills.size());
		for (AppListItems appskill : appSkills) {
			appList.add(appskill);
		}
		this.setAppSkills(appList);
		List<AppListItems> streamName = new ArrayList<>(appStream.size());
		for (AppListItems stream : appStream) {
			streamName.add(stream);
		}
		this.setAppStream(streamName);
		this.setId(studentProfile.getId());
	}

	public StudentProfileVO(StudentProfile studentProfile, List<String> skillList, List<StudentsSkills> stream,
			UserContact userContact) {
		BeanUtils.copyProperties(studentProfile, this);
		if (userContact != null) {
			this.setMobileNumber(userContact.getMobileNumber());
			this.setUserAddress(userContact.getUserAddress());
			this.setUserCity(userContact.getUserCity());
			this.setUserCountry(userContact.getUserCountry());
			this.setUserState(userContact.getUserState());
		}
		this.setId(studentProfile.getId());
		if (skillList != null) {
			String keyAndValue = "";
			for (String strSkillName : skillList) {
				if (keyAndValue.equals("")) {
					keyAndValue = keyAndValue + strSkillName;
				} else {
					keyAndValue = keyAndValue + "," + strSkillName;
				}

				skillNames = keyAndValue;
			}
		}
		if (stream != null) {
			streamMap = new LinkedHashMap<>(stream.size());
			for (StudentsSkills streamName : stream) {
				streamMap.put(streamName.getStudentProfileId().getId(), streamName.getSkillName());
			}
		}

	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		StudentProfileVO other = (StudentProfileVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	// public String getUserStaggingId() {
	// return userStaggingId;
	// }
	//
	// public void setUserStaggingId(String userStaggingId) {
	// this.userStaggingId = userStaggingId;
	// }

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentAlternateEmail() {
		return studentAlternateEmail;
	}

	public void setStudentAlternateEmail(String studentAlternateEmail) {
		this.studentAlternateEmail = studentAlternateEmail;
	}

	public String getPassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getStudentInstitutionName() {
		return studentInstitutionName;
	}

	public void setStudentInstitutionName(String studentInstitutionName) {
		this.studentInstitutionName = studentInstitutionName;
	}

	public Character getStudentWorkStatus() {
		return studentWorkStatus;
	}

	public void setStudentWorkStatus(Character studentWorkStatus) {
		this.studentWorkStatus = studentWorkStatus;
	}

	public String getStudentFieldExperience() {
		return studentFieldExperience;
	}

	public void setStudentFieldExperience(String studentFieldExperience) {
		this.studentFieldExperience = studentFieldExperience;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentDateOfBirth() {
		return studentDateOfBirth;
	}

	public void setStudentDateOfBirth(String studentDateOfBirth) {
		this.studentDateOfBirth = studentDateOfBirth;
	}

	public String getStudentSkills() {
		return studentSkills;
	}

	public void setStudentSkills(String studentSkills) {
		this.studentSkills = studentSkills;
	}

	public Character getStudentProfileStatus() {
		return studentProfileStatus;
	}

	public void setStudentProfileStatus(Character studentProfileStatus) {
		this.studentProfileStatus = studentProfileStatus;
	}

	public Long getStudentYearOfPassing() {
		return studentYearOfPassing;
	}

	public void setStudentYearOfPassing(Long studentYearOfPassing) {
		this.studentYearOfPassing = studentYearOfPassing;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public String getStudentAdharCardNumber() {
		return studentAdharCardNumber;
	}

	public void setStudentAdharCardNumber(String studentAdharCardNumber) {
		this.studentAdharCardNumber = studentAdharCardNumber;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public boolean getIsStudentActive() {
		return isStudentActive;
	}

	public void setIsStudentActive(boolean isStudentActive) {
		this.isStudentActive = isStudentActive;
	}

	public Map<String, String> getStudentsMap() {
		return studentsMap;
	}

	public void setStudentsMap(Map<String, String> studentsMap) {
		this.studentsMap = studentsMap;
	}

	public Map<Long, String> getSkillsMap() {
		return skillsMap;
	}

	public void setSkillsMap(Map<Long, String> skillsMap) {
		this.skillsMap = skillsMap;
	}

	public Map<Long, String> getStreamMap() {
		return streamMap;
	}

	public void setStreamMap(Map<Long, String> streamMap) {
		this.streamMap = streamMap;
	}

	public List<StudentsSkills> getSkillRequired() {
		return skillRequired;
	}

	public void setSkillRequired(List<StudentsSkills> skillRequired) {
		this.skillRequired = skillRequired;
	}

	public List<AppListItems> getAppSkills() {
		return appSkills;
	}

	public void setAppSkills(List<AppListItems> appSkills) {
		this.appSkills = appSkills;
	}

	public List<AppListItems> getAppStream() {
		return appStream;
	}

	public void setAppStream(List<AppListItems> appStream) {
		this.appStream = appStream;
	}

	public String getSkillNames() {
		return skillNames;
	}

	public void setSkillNames(String skillNames) {
		this.skillNames = skillNames;
	}
	
	public MultipartFile getStudentImage(){
		return studentImage;
	}
	
	public void setStudentImage(MultipartFile studentImage){
		this.studentImage = studentImage;
	}
	
	public MultipartFile getStudentResume(){
		return studentResume;
	}
	
	public void setCompanyLogo(MultipartFile studentResume){
		this.studentResume = studentResume;
	}
	
	public List<AttachmentsVO> getAttachmentsVOs(){
		return attachmentsVOs;
	}
	
	public void setAttachmentsVOs(List<AttachmentsVO> attachmentsVOs){
		this.attachmentsVOs = attachmentsVOs;
	}

	public MultipartFile getAvatar() {
		return avatar;
	}

	public void setAvatar(MultipartFile avatar) {
		this.avatar = avatar;
	}

	public AttachmentsVO getAttachmentsVO() {
		return attachmentsVO;
	}

	public void setAttachmentsVO(AttachmentsVO attachmentsVO) {
		this.attachmentsVO = attachmentsVO;
	}

	public String getAvatarBaseString() {
		return avatarBaseString;
	}

	public void setAvatarBaseString(String avatarBaseString) {
		this.avatarBaseString = avatarBaseString;
	}

	public Character getIsAvatar() {
		return isAvatar;
	}

	public void setIsAvatar(Character isAvatar) {
		this.isAvatar = isAvatar;
	}

	public String getResumeBaseString() {
		return resumeBaseString;
	}

	public void setResumeBaseString(String resumeBaseString) {
		this.resumeBaseString = resumeBaseString;
	}

	public Character getisResume() {
		return isResume;
	}

	public void setIsResume(Character isResume) {
		this.isResume = isResume;
	}

	public MultipartFile getResume() {
		return resume;
	}

	public void setResume(MultipartFile resume) {
		this.resume = resume;
	}
}

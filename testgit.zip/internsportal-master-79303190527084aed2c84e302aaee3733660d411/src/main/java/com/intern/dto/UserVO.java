package com.intern.dto;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.CompanyProfile;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserStaging;

public class UserVO extends BaseVO {

	private static final long serialVersionUID = 8041666927150043099L;

	private String loginId;
	private String password;
	private String userCode;
	private Date dateLastLogin;
	private String status;
	private String companyName;
	private String studentFirstName;
	private String userName;
	private String isActive ;

	public UserVO() {
	}

	public UserVO(String studentsCount, String companyCount) {

	}

	public UserVO(User users, StudentProfileVO studentProfileVO, CompanyProfileVO companyProfileVO) {
		BeanUtils.copyProperties(users, this);
	}

	public UserVO(User user, List<UserVO> users, List<CompanyProfile> listComapanies,
			List<StudentProfile> listStudents) {
		BeanUtils.copyProperties(user, this);

		for (CompanyProfile companyProfile : listComapanies) {
			if (companyProfile != null) {
				this.setCompanyName(companyProfile.getCompanyName());
			}
		}
		for (StudentProfile studentProfile : listStudents) {
			if (studentProfile != null) {
				this.setStudentFirstName(studentProfile.getStudentFirstName());
			}
		}
	}

	public UserVO(User user) {
		BeanUtils.copyProperties(user, this);
		this.setId(user.getId());
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserVO other = (UserVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public Date getDateLastLogin() {
		return dateLastLogin;
	}

	public void setDateLastLogin(Date dateLastLogin) {
		this.dateLastLogin = dateLastLogin;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}
}

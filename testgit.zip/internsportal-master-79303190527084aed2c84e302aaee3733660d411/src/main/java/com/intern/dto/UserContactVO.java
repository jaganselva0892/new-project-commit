package com.intern.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.intern.dto.base.BaseVO;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.entity.UserStaging;

public class UserContactVO extends BaseVO {

	private static final long serialVersionUID = 4567260663546731851L;

	private String userId;
	private String userStaggingId;
	private String mobileNumber;
	private String userAddress;
	private String userCity;
	private String userState;
	private String userCountry;

	public UserContactVO() {

	}
public static final List<UserContactVO> populateUserContactVOs(List<UserContact> userContact){
	List<UserContactVO> userContactsVOs = null;
	UserContactVO usercontactVO = null;
	if(userContact != null)
	{
		userContactsVOs = new ArrayList<>(userContact.size());
	}
	for (UserContact userContactVO : userContact ) {
		usercontactVO = new UserContactVO(userContactVO);
		userContactsVOs.add(usercontactVO);
	}
	return userContactsVOs;
}
	public UserContactVO(UserContact userContact) {
		BeanUtils.copyProperties(userContact, this);
		this.setId(userContact.getId());
	}

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserContactVO other = (UserContactVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserStaggingId() {
		return userStaggingId;
	}

	public void setUserStaggingId(String userStaggingId) {
		this.userStaggingId = userStaggingId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

}

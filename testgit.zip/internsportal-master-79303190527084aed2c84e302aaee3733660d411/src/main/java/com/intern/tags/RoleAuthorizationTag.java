package com.intern.tags;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.jstl.core.ConditionalTagSupport;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.UserPreferences;
import com.intern.entity.User;

public class RoleAuthorizationTag extends ConditionalTagSupport {

	private static final long serialVersionUID = 8342608720537766707L;

	@Autowired
	private AuditorAwareService auditorAwareService;

	// private static final Logger LOGGER = LogManager.getLogger();
	// private static final String CLASS_NAME =
	// RoleAuthorizationTag.class.getName();

	private String userType;

	@Transactional(readOnly = true)
	protected User getCurrentUser(){
		User loginUser = auditorAwareService.getCurrentAuditor();
		return loginUser;
	}
	
	@Override
	protected boolean condition() throws JspTagException {
		try {
			UserPreferences pref = (UserPreferences) pageContext.getAttribute("scopedTarget.userPreferences", PageContext.SESSION_SCOPE);
			// if (pref == null) {
			// return false;
			// }
			User loginUser = getCurrentUser();
//			if (auditorAwareService.getCurrentAuditor() != null) {
//				return false;
//			}
//			User loginUser = auditorAwareService.getCurrentAuditor();
			if (!StringUtils.equals(loginUser.getUserCode(), userType)) {
				return false;
			}
			// if (!StringUtils.equals(pref.getRoleType(), userType)) {
			//// LOGGER.trace(CLASS_NAME, "condition", "checking user [{}] for
			// roleType [{}] in a JSP page, permission denied",
			//// pref.getUserName(), roleType);
			// return false;
			// }
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public void setUserType(String role) {
		this.userType = role;
	}
}

package com.intern.exception;

import com.intern.logging.LogManager;
import com.intern.logging.Logger;

public class InternException  extends Exception {

  private static final long serialVersionUID = 3901288427653925165L;
  private static final Logger LOGGER = LogManager.getLogger();
  private static final String CLASS_NAME = InternException.class.getName();

  private static final String METHOD_HANDLE_EXCEPTION = "handleException";

  public InternException() {
    super();
  }

  public InternException(String message) {
    super(message);
  }

  public InternException(String message, Throwable cause) {
    super(message, cause);
  }

  public static void handleException(Exception ex) {
    LOGGER.error(CLASS_NAME, METHOD_HANDLE_EXCEPTION, ex);
  }

}
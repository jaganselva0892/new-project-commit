package com.intern.auditor;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.intern.utils.AppConstants;
import com.intern.repository.UserRepository;

/**
 * A custom {@link UserDetailsService} where user information is retrieved from
 * a JPA repository
 */

@Component
@Transactional(readOnly = true)
public class AuditorUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	HttpSession httpSession;

	/**
	 * Returns a populated {@link UserDetails} object. The username is first
	 * retrieved from the database and then mapped to a {@link UserDetails}
	 * object.
	 */
	@Override
	public UserDetails loadUserByUsername(String loginId) {
		com.intern.entity.User user = userRepository.findByLoginId(loginId);
		if (user == null) {
			throw new UsernameNotFoundException("UserName " + loginId + " not found");
		} else if (user.getIsActive().equals('N')) {
			throw new UsernameNotFoundException(
					"UserName " + loginId + "Account is deactivated . please contact Admin");
		} else if (user.getIsDeleted().equals('Y')) {
			throw new UsernameNotFoundException(
					"UserName " + loginId + "Account is deactivated . please contact Admin");
		}

		// if(user.getUserCode().equals(AppConstants.USER_CODE))
		// String userCode = (String)
		// httpSession.getAttribute(AppConstants.USER_CODE);
		// if (!user.getUserCode().equals(userCode)) {
		// throw new UsernameNotFoundException("UserName " + loginId + " not
		// found");
		// }
		httpSession.setAttribute(AppConstants.LOGIN_USER, user);
		if (user != null) {
			httpSession.setAttribute(AppConstants.USER_CODE, user.getUserCode());
		}
		return new SecurityUser(user);
	}
}
package com.intern.auditor;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.intern.entity.User;

public class SecurityUser implements UserDetails {

	private static final long serialVersionUID = -5498529806964942261L;

	private final User user;

	private Collection<? extends GrantedAuthority> grantedAuthorities;

	public SecurityUser(User user) {
		this(user, new ArrayList<GrantedAuthority>(1));
	}

	public SecurityUser(User user, Collection<? extends GrantedAuthority> grantedAuthorities) {
		this.user = user;
		this.grantedAuthorities = grantedAuthorities;
		// INFO: Eager load the role and account object for logged in user.
		// Don't think that the following lines doens't do anything. It helps to
		// break the lazy loading.
		// {
		// //this.user.getTeam().getId();
		// this.user.get
		// }
	}

	/**********************
	 * hashcode, equals and toString methods
	 **********************/

//	@Override
//	public String toString() {
//		return String.format("SecurityUser [id = %d]", user.getId());
//	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getUser().getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		SecurityUser other = (SecurityUser) obj;
		return new EqualsBuilder().append(this.getUser().getId(), other.getUser().getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return grantedAuthorities;
	}

	@Override
	public String getPassword() {
		return user.getPassword();
	}

	@Override
	public String getUsername() {
		return user.getLoginId();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return user.getIsActive() != User.LOCKED;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return user.getIsActive() != User.INACTIVE;
	}

	public User getUser() {
		return user;
	}

}

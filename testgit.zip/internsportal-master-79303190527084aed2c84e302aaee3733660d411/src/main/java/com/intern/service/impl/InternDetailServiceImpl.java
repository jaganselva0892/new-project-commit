package com.intern.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.UserVO;
import com.intern.entity.AppListItems;
import com.intern.entity.AppliedHistory;
import com.intern.entity.CompanyProfile;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.AppListItemsRepository;
import com.intern.repository.AppliedHistoryRepository;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.InternDetailsSkillsRepository;
import com.intern.repository.UserContactRepository;
import com.intern.repository.UserRepository;
import com.intern.repository.UserStagingRepository;
import com.intern.service.InternDetailService;
import com.intern.service.SearchService;
import com.intern.utils.AppConstants;
import com.intern.utils.CommonUtils;

@Service
public class InternDetailServiceImpl implements InternDetailService {

	@Autowired
	UserContactRepository userContactRepository;

	@Autowired
	InternDetailsRepository internDetailsRepository;

	@Autowired
	InternDetailsSkillsRepository internDetailsSkillsRepository;

	@Autowired
	HttpSession httpSession;

	@Autowired
	SearchService searchService;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	AppListItemsRepository appListItemsRepository;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	AppliedHistoryRepository appliedHistoryRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveUserDetails";
	private static final String METHOD_GET_DETAILS = "getInternshiDetails";

	@Override
	@Transactional(readOnly = false)
	public InternDetailsVO getInternDetails() {

		InternDetails internDetails = new InternDetails();
		List<AppListItems> skillRequired = appListItemsRepository.findBySkill();
		List<AppListItems> appStream = appListItemsRepository.findByStream();
		return new InternDetailsVO(internDetails, skillRequired,appStream);

	}

	@Override
	@Transactional(readOnly = false)
	public InternDetailsVO saveInternDetails(InternDetailsVO internDetailsVO) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		String strDateFormat = "MM/dd/yyyy";
		InternDetails internDetails;
		try {

			if (internDetailsVO.isNew()) {
				internDetails = new InternDetails();
			} else {
				internDetails = internDetailsRepository.findOne(internDetailsVO.getId());
			}
			BeanUtils.copyProperties(internDetailsVO, internDetails);
			internDetails.setEligibility(null);
			internDetails.setApplyDate(CommonUtils.getCustomDateFormat(internDetailsVO.getApplyDate(), strDateFormat));
			internDetails.setEndDate(CommonUtils.getCustomDateFormat(internDetailsVO.getEndDate(), strDateFormat));
			internDetails.setStartAndEndDate(
					CommonUtils.getCustomDateFormat(internDetailsVO.getStartAndEndDate(), strDateFormat));
			// internDetails.setApplyDate(internDetailsVO.getApplyDate());
			internDetails.setUserId(loginUser);
			User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			auditorAwareService.setGuestUser(adminUser);
			// internDetails.setInternshipTitle(internDetailsVO.getInternshipTitle());
			// internDetails.setSkillsRequired(internDetailsVO.getSkillsRequired());
			// internDetails.setDuration(internDetailsVO.getDuration());
			// internDetails.setStipend(internDetailsVO.getStipend());
			// internDetails.setInternshipType(internDetailsVO.getInternshipType());
			// String applyDate = internDetailsVO.getApplyDate().toString();
			// Date appliedDate = new
			// SimpleDateFormat("MM/dd/yyyy").parse(applyDate.toString());
			// applyDate = new SimpleDateFormat("MM/dd/yyyy
			// HH:mm").format(appliedDate);

			// internDetails.setApplyDate(internDetailsVO.getApplyDate());
			internDetails.setPostStatus('N');
			internDetails = internDetailsRepository.save(internDetails);
			internDetailsVO.setId(internDetails.getId());
			InternDetails internId = internDetailsRepository.findOne(internDetailsVO.getId());
			saveInternCatagories(internDetailsVO.getSkillsRequired(), "Skills", internId);
			saveInternCatagories(internDetailsVO.getEligibility(), "Stream", internId);
			auditorAwareService.setGuestUser(null);
			return internDetailsVO;

		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
			return null;
		}
	}

	// public Converter<String, Date> getStringToDateConverter() {
	// return new Converter<String, Date>() {
	//
	// @Override
	// public Date convert(String source) {
	// SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	// try {
	// return sdf.parse(source);
	// } catch (java.text.ParseException e) {
	// return null;
	// }
	//
	// }
	// };
	// }

	@Override
	public String listPosts() {
		char isActive = AppConstants.YES;
		List<InternDetails> listPosts = internDetailsRepository.listActivePosts(isActive);
		String listActivePosts = Integer.toString(listPosts.size());
		return listActivePosts;
	}

	@Override
	@Transactional(readOnly = true)
	public List<InternDetails> getinternList(String categoryName) {
		List<InternDetails> internList = new ArrayList<InternDetails>();
		try {
			List<InternDetailsSkills> listCategories = internDetailsSkillsRepository.findByCategory(AppConstants.NO, categoryName);
			for (InternDetailsSkills internCategoryDetails : listCategories) {
				// char isDeleted = AppConstants.NO;
				if(internCategoryDetails.getInternDetailsId() != null){
					InternDetails listPosts = internDetailsRepository.findOne(internCategoryDetails.getInternDetailsId().getId());
					if(listPosts != null){
						if (!internList.contains(listPosts)) {
							internList.add(listPosts);
						}
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_GET_DETAILS, ex);
		}
		return internList;
	}

	public boolean saveInternCatagories(String categoryName, String categoryType, InternDetails id) {
		String[] arrCategoryName = categoryName.split(",");
		List<InternDetailsSkills> listCategories = internDetailsSkillsRepository.findById(id);

		for (String strCategoryName : arrCategoryName) {
			InternDetailsSkills internDetailsSkills = new InternDetailsSkills();
			internDetailsSkills.setInternDetailsId(id);

			internDetailsSkills.setCategoryType(categoryType);
			if (!listCategories.contains(strCategoryName)) {
				internDetailsSkills.setCategory(strCategoryName);
				internDetailsSkills = internDetailsSkillsRepository.save(internDetailsSkills);
			}
		}
		return true;
	}

	@Override
	public String listPostInternshipsCount() {
		char isDeleted = AppConstants.NO;
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		try {
			List<InternDetails> listPostInternshipsCount = internDetailsRepository.listActiveInternships(loginUser,
					isDeleted);
			String activeInternships = Integer.toString(listPostInternshipsCount.size());
			return activeInternships;

		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional(readOnly = false)
	public List<InternDetailsVO> listinternships() {
		try {
			List<InternDetails> listInternshiPosts = internDetailsRepository.listActiveInternships(AppConstants.NO);
			List<InternDetailsVO> internshipList = new ArrayList<InternDetailsVO>();
			for (InternDetails listPosts : listInternshiPosts) {
				InternDetailsVO internDetailsVO = new InternDetailsVO();
				internDetailsVO.setId(listPosts.getId());
				internDetailsVO.setUserId(listPosts.getUserId());
				if (listPosts.getPostStatus().equals('N')) {
					internDetailsVO.setStatus("New");
				} else if (listPosts.getPostStatus().equals('A')) {
					internDetailsVO.setStatus("Approved");
				} else {
					internDetailsVO.setStatus("Pending");
				}
				if (listPosts.getIsActive().equals('Y')) {
					internDetailsVO.setIsActive("Active");
				} else {
					internDetailsVO.setIsActive("Deactive");
				}
				internDetailsVO.setInternshipTitle(listPosts.getInternshipTitle());
				CompanyProfile companyProfile = companyProfileRepository.findProfileByUser(internDetailsVO.getUserId(),
						AppConstants.NO);
				internDetailsVO.setCompanyName(companyProfile.getCompanyName());
				internDetailsVO.setCompanyEmail(companyProfile.getCompanyEmail());
				internshipList.add(internDetailsVO);
			}

			return internshipList;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override

	public String listPostApprovalPendings() {

		char postStatus = AppConstants.NEW;
		List<InternDetails> listPostApprovalPendings = internDetailsRepository.listPostPendings(postStatus);
		String postPendings = Integer.toString(listPostApprovalPendings.size());
		return postPendings;

	}

	@Override
	public List<InternDetailsVO> getPostDetails(Long id) {
		List<InternDetails> internDetails = internDetailsRepository.findByInternId(id);
		List<InternDetailsVO> viewPosts = new ArrayList<InternDetailsVO>();
		for (InternDetails interns : internDetails) {
			CompanyProfile companyDetails = companyProfileRepository.findByUserId(interns.getUserId());
			InternDetailsVO internPostsVO = new InternDetailsVO();
			internPostsVO.setInternshipTitle(interns.getInternshipTitle());
			internPostsVO.setInternshipType(interns.getInternshipType());
			internPostsVO.setInternshipDescription(interns.getInternshipDescription());
			internPostsVO.setDuration(interns.getDuration());
			internPostsVO.setCompanyName(companyDetails.getCompanyName());
			internPostsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
			String appdate = interns.getApplyDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(interns.getApplyDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				appdate = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				appdate = interns.getApplyDate().toString();
			}
			internPostsVO.setApplyDate(appdate);
			String enddate = interns.getEndDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(interns.getEndDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				enddate = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				enddate = interns.getEndDate().toString();
			}
			internPostsVO.setEndDate(enddate);
			String date = interns.getStartAndEndDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(interns.getStartAndEndDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				date = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				date = interns.getStartAndEndDate().toString();
			}
			internPostsVO.setStartAndEndDate(date);
			viewPosts.add(internPostsVO);
		}

		return viewPosts;
	}

}

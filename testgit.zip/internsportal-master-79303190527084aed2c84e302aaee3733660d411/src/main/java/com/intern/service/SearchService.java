package com.intern.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.SearchFilteringVO;
import com.intern.dto.StudentsSkillsVO;
import com.intern.entity.AppListItems;
import com.intern.entity.InternDetails;
import com.intern.exception.InternException;

@Service
public interface SearchService {

	List<AppListItems> SearchDetails();
	
	String SearchByCategory(String applistitemsName);

	Map<String, Object> getStreamName(String appListItemsName);

	 List<AppListItems> searchCategoryDetails();

	List<AppListItems> searchSkillDetails();

	List<InternDetailsVO> searchInternDetails(String searchKey)  throws IOException, InternException;

	InternDetailsVO saveAppliedDetails(InternDetailsVO saveInternDetailsVO);

	List<SearchFilteringVO> searchByVariousCategories(SearchFilteringVO searchFilteringVO);

	SearchFilteringVO getSearchDetails();

	List<InternDetailsVO> leftPanelSearchPosts(SearchFilteringVO searchFilteringVO)  throws IOException, InternException;

	//List<AppListItems> searchCategoryDetails(String applistitemsName);
	
	List<InternDetails> filterFromLeftSide(SearchFilteringVO searchFilteringVO);

	InternDetailsVO findByInternId(Long internId);

	List<InternDetailsVO> getMoreDetails(Long internId);

	List<InternDetailsVO> searchByCompany(Long searchCompany) throws InternException ;

	
	
	
}

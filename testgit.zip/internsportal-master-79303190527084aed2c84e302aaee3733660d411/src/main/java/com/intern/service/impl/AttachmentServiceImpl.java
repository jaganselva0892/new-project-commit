package com.intern.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AttachmentsVO;
import com.intern.entity.Attachments;
import com.intern.entity.User;
import com.intern.repository.AttachmentsRepository;
import com.intern.service.AttachmentService;
import com.intern.utils.AppConstants;

@Service
public class AttachmentServiceImpl implements AttachmentService {

	
	@Autowired
	AttachmentsRepository attachmentsRepository;
	
	@Autowired
	AuditorAwareService auditorAwareService;
	
	@Override
	@Transactional(readOnly = false)
	public boolean saveAttachment(AttachmentsVO attachmentsVO){
		try{
			char isDeleted = AppConstants.NO;
			User loginUser = auditorAwareService.getCurrentAuditor();
			Byte[] attachmentData = null;
			Attachments saveAttachment = new Attachments();
			Attachments attachments = attachmentsRepository.findByUserWithType(loginUser, attachmentsVO.getAttachmentType(), isDeleted);
			

			
			if(attachments != null){
//				attachments.setAttachmentData(attachmentData);
//				attachmentsRepository.save(attachments);
				saveAttachment = attachments;
			}
			
			MultipartFile multipartFile = attachmentsVO.getAttachmentFile();
			if(multipartFile != null){
				if(multipartFile.getOriginalFilename() != null){
					saveAttachment.setFileName(multipartFile.getOriginalFilename());
					saveAttachment.setFileSize(multipartFile.getSize());
					saveAttachment.setFileContentType(multipartFile.getContentType());
					saveAttachment.setAttachmentData(multipartFile.getBytes());
					saveAttachment.setUserId(loginUser);
				}
			}
			saveAttachment.setAttachmentType(attachmentsVO.getAttachmentType());
			saveAttachment = attachmentsRepository.save(saveAttachment);
			return true;
		}
		catch(Exception ex){
			return false;
		}
	}
	
	
	@Override
	@Transactional(readOnly = false)
	public boolean removeAttachment(Long attachmentId){
		try{
			Attachments attachments = attachmentsRepository.findOne(attachmentId);
			attachmentsRepository.delete(attachments);
			return true;
		}
		catch(Exception ex){
			return false;
		}
	}
	
}
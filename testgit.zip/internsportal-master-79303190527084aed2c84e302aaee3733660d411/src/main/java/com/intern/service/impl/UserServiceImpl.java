package com.intern.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.net.URLEncoder;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.auditor.AuditorAwareService;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserStagingVO;
import com.intern.entity.AppListItems;
import com.intern.entity.CompanyProfile;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.dto.UserVO;
import com.intern.entity.UserStaging;
import com.intern.exception.InternException;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.StudentProfileRepository;
import com.intern.repository.UserRepository;
import com.intern.service.UserService;
import com.intern.service.UserStagingService;
import com.intern.utils.AppConstants;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	StringEncryptor stringEncryptor;

	@Autowired
	UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	StudentProfileRepository studentProfileRepository;

	@Autowired
	private AuditorAwareService auditorAwareService;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SEND_FORGOT_PASSWORD = "sendForgotPassword";
	private static final String METHOD_CHECK_IP = "checkIpAuthentication";
	private static final String METHOD_EXISTS_PASSWORD = "getExistPasswordHistory";

	@Override
	public List<User> listUsers() {
		List<User> listUsers = userRepository.findAll();
		return listUsers;
	}

	@Override
	public String listUsersCount() {
		try {
			char isActive = AppConstants.YES;
			List<User> listUsersCount = userRepository.listActiveUsers(isActive, AppConstants.NO);
			String activeUsers = Integer.toString(listUsersCount.size());
			// List<Integer> listUsers = userRepository.count(isActive);
			// String usersCount = listUsers.toString();
			// String activeUsers = Integer.toString(listUsers.size());
			// List<User> listActiveUsers = new ArrayList<usersCount>();
			// List<Integer> listActiveUsers = List<User>
			// List<User> newlist = new ArrayList<User>(listUsers.size());
			return activeUsers;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	public List<UserVO> listusers() {
		try {
			List<User> listUser = userRepository.listUsers(AppConstants.NO);

			List<UserVO> usersList = new ArrayList<UserVO>();
			// User user = new User();
			// for (User listOfUsers : listUser) {
			// UserVO userVO = new UserVO();
			// userVO.setEmailId(listOfUsers.getEmailId());
			// userVO.setUserCode(listOfUsers.getUserCode());
			// userVO.setStatus("Approved");
			// users.add(userVO);
			// }
			// return new UserVO(user, users, listComapanies, listStudents);
			for (User listOfUsers : listUser) {
				if (!listOfUsers.getUserCode().equals("Admin")) {
					UserVO userVO = new UserVO();
					userVO.setId(listOfUsers.getId());
					userVO.setLoginId(listOfUsers.getLoginId());
					userVO.setUserCode(listOfUsers.getUserCode());
					if (listOfUsers.getIsActive().equals('Y')) {
						userVO.setIsActive("Active");
					} else {
						userVO.setIsActive("Deactive");
					}
					User userId = userRepository.findOne(userVO.getId());
					if (userVO.getUserCode().equals("Company")) {
						CompanyProfile companyProfile = companyProfileRepository.findByUserId(userId);
						userVO.setUserName(companyProfile.getCompanyName());
						if (companyProfile.getCompanyProfileStatus().equals('N')) {
							userVO.setStatus("New");
						} else if (companyProfile.getCompanyProfileStatus().equals('A')) {
							userVO.setStatus("Approved");
						} else {
							userVO.setStatus("Pending");
						}
						// usersList.add(userVO);

					} else {
						StudentProfile studentProfile = studentProfileRepository.findByUserId(userId);
						userVO.setUserName(studentProfile.getStudentFirstName());
						if (studentProfile.getStudentProfileStatus().equals('N')) {
							userVO.setStatus("New");
						} else if (studentProfile.getStudentProfileStatus().equals('A')) {
							userVO.setStatus("Approved");
						} else {
							userVO.setStatus("Pending");
						}
						// usersList.add(userVO);

					}

					usersList.add(userVO);
				}

			}

			return usersList;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public void getEmailId(String loginId) throws InternException {
		User user = userRepository.findByLoginId(loginId);
		if (user == null) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This e-mail does not exist in our system. Please check your entry!", loginId);
			throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		}
		if (user.getIsActive().equals("N")) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This user requested for password reset, is not active in the system.", loginId);
			throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		}
		if (user.getIsDeleted().equals("Y")) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This user requested for password reset, is not found in this active user", loginId);
			throw new InternException(AppConstants.MSG_USER_NOT_FOUND);
		}
	}

	@Override
	@Transactional
	public UserVO changeUserPassword(UserVO userVO) throws InternException {
		User loginUser = auditorAwareService.getCurrentAuditor();
		User user = userRepository.findByLoginId(userVO.getLoginId());
		if (user == null) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This e-mail does not exist in our system. Please check your entry!", user);
			throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		}
		if (user.getIsActive().equals("N")) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This user requested for password reset, is not active in the system.", user);
			throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		}
		if (user.getIsDeleted().equals("Y")) {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This user requested for password reset, is not found in this active user", user);
			throw new InternException(AppConstants.MSG_USER_NOT_FOUND);
		}
		User exUser = userRepository.findByLoginId(userVO.getLoginId());
		if (exUser != null) {
			String encryptPassword = passwordEncoder.encode(userVO.getPassword());
			userRepository.updatePassword(userVO.getLoginId(), encryptPassword);
		} else {
			LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
					"{} This e-mail is mismatch with our db. Please check your entry!", user);
			throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		}
		// if (userVO.getLoginId().equals(loginUser.getLoginId())) {
		//// String encryptPassword =
		// passwordEncoder.encode(userVO.getPassword());
		//// userRepository.updatePassword(userVO.getLoginId(),
		// encryptPassword);
		// } else {
		// LOGGER.warn(CLASS_NAME, METHOD_SEND_FORGOT_PASSWORD,
		// "{} This e-mail is mismatch with our db. Please check your entry!",
		// user);
		// throw new InternException(AppConstants.MSG_ACCOUNT_NOT_ACTIVE);
		// }
		return userVO;
	}

	@Override
	public void updateUserActiveStatus(UserVO userVO) {
		User user = userRepository.findByUserId(userVO.getId());
		if (userVO.getIsActive().equals("Yes")) {
			userRepository.updateActiveStatus(userVO.getId());
		} else {
			userRepository.updateDeActiveStatus(userVO.getId());
		}

	}

	// @Override
	// public String listUserApprovalPendings() {
	// char isActive = AppConstants.NO;
	// List<User> listUserApprovalPendings =
	// userRepository.listUserPendings(isActive);
	// String userPendings = Integer.toString(listUserApprovalPendings.size());
	// return userPendings;
	// }

	//
	// String Password = user.getPassword();

	// StandardPBEStringEncryptor encryptor = new
	// StandardPBEStringEncryptor();
	// encryptor.decrypt("jasypt");
	// String decryptPassword = encryptor.decrypt(user.getPassword());
	// System.out.println(decryptPassword);
	// PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	// String decryptPassword = stringEncryptor.decrypt(user.getPassword());
	// UserVO userPassword = new UserVO();
	// userPassword.setpassword(decryptPassword);

}

package com.intern.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserStagingVO;
import com.intern.entity.AppliedHistory;
import com.intern.entity.InternDetails;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;

@Service
public interface CompanyService {

	CompanyProfileVO getCompanyProfile();

	CompanyProfileVO saveCompanyDetails(CompanyProfileVO companyProfileVO);

	List<InternDetailsVO> getPostedInternships();

	InternDetailsVO editPostedInternships(Long internId);

	void deleteInternPost(Long internId);

	CompanyProfileVO getCompanyDetails(Long userId);

	List<AppliedHistoryVO> getStudentAppliedHistory();

	List<StudentDetailsVO> getStudentDetails(Long userId);

	List<CompanyProfileVO>  getCompanyDetailsToView(Long profileId);

	String listCompanies();

	List<CompanyProfileVO> getCompanyDetailsAndLogo();

	//String getCountOfStudentsApplied();

}

package com.intern.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jasypt.encryption.StringEncryptor;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.auditor.AuditorAwareService;
import com.intern.controller.HomeController;
import com.intern.dto.UserStagingVO;
import com.intern.entity.CompanyProfile;
import com.intern.entity.StudentProfile;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.entity.User;
import com.intern.entity.UserStaging;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.StudentProfileRepository;
import com.intern.repository.UserRepository;
import com.intern.repository.UserStagingRepository;
import com.intern.service.UserStagingService;
import com.intern.utils.AppConstants;

@Service
public class UserStagingServiceImpl implements UserStagingService {

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	UserRepository userRepository;

	// @Autowired
	// private SimpleMailMessage simpleMailMessage;
	//
	// @Autowired
	// private JavaMailSender mailSender;
	//

	// @Autowired
	// PasswordEncoder passwordEncoder;

	@Autowired
	StringEncryptor stringEncryptor;

	@Autowired
	UserStagingRepository userStagingRepository;

	@Autowired
	StudentProfileRepository studentProfileRepository;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	UserStagingService userStagingService;

	@Autowired
	private MailSender messageByEmail;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveUserDetails";

	@Override
	@Transactional(readOnly = false)
	public UserStagingVO saveUserDetails(UserStagingVO userStagingVO) {
		try {
			UserStaging userStaging;
			// String password = null;
			// userRepository.findByemailId(userStagingVO.getUserEmailId());
			if (userStagingVO.isNew()) {
				userStaging = new UserStaging();
			} else {
				return null;
			}
			// User user = new User();
			// // String password =
			// //
			// stringEncryptor.encrypt(String.valueOf(userStagingVO.getPassword()));
			// String password = userStagingVO.getPassword();
			// PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			// String encode = passwordEncoder.encode(password);
			// user.setpassword(encode);
			// user.setLoginId(userStagingVO.getUserEmailId());
			// user.setUserCode(userStagingVO.getUserCode());
			//
			// StudentProfile studentProfile = new StudentProfile();
			// studentProfile.setStudentFirstName(userStagingVO.getUserName());
			// studentProfile.setStudentEmail(userStagingVO.getUserEmailId());
			// studentProfile.setStudentInstitutionName(userStagingVO.getUserOrganization());
			// studentProfile.setStudentAdharCardNumber(userStagingVO.getStudentAdharCardNumber());
			// CompanyProfile companyProfile = new CompanyProfile();
			// companyProfile.setCompanyName(userStagingVO.getUserName());
			// companyProfile.setCompanyEmail(userStagingVO.getUserEmailId());
			// companyProfile.setCompanyDescription(userStagingVO.getUserOrganization());
			// companyProfile.setCompanyWebsite(userStagingVO.getCompanyWebsite());
			// String encoded = URLEncoder.encode(password);
			// userStagingVO.setPassword(password);
			// BeanUtils.copyProperties(userStagingVO, user);
			BeanUtils.copyProperties(userStagingVO, userStaging);
			User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			// userStaging.setUserCode("Company");
			// userStaging.setCreatedBy(adminUser);
			// userStaging.setLastModifiedBy(adminUser);
			// userStaging.setCreatedDate(new
			// DateTime(System.currentTimeMillis()));
			// userStaging.setLastModifiedDate(new
			// DateTime(System.currentTimeMillis()));
			userStaging.setUserStatus("New");
			auditorAwareService.setGuestUser(adminUser);
			userStaging = userStagingRepository.save(userStaging);
			// user = userRepository.save(user);
			// if (user.getUserCode().equals("Student")) {
			// studentProfile.setUserId(user);
			// studentProfile.setStudentProfileStatus('A');
			// studentProfile = studentProfileRepository.save(studentProfile);
			// } else {
			// companyProfile.setUserId(user);
			// companyProfile.setCompanyProfileStatus('A');
			// companyProfile = companyProfileRepository.save(companyProfile);
			// }
			auditorAwareService.setGuestUser(null);
			userStagingVO.setId(userStaging.getId());
			sendEmail(userStagingVO.getUserEmailId(), "testannie10@gmail.com", "Welcome",
					"Welcome To Our InternNet . Please wait for our admin approval to get login");
			sendEmailToAdmin("seethalakshmi.balasubramanian@aalamsoft.com", "testannie10@gmail.com",
					"New User Registered",
					userStagingVO.getUserEmailId() + " " + "has been Registered to our InternNet",
					DateTime.now().toDate());
			return userStagingVO;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
			return null;
		}
	}

	public void sendEmail(String toAddr, String fromAddr, String subject, String msgBody) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setTo(toAddr);
		simpleMsg.setSubject(subject);
		simpleMsg.setText(msgBody);
		messageByEmail.send(simpleMsg);
	}

	public void sendEmailToAdmin(String toAddr, String fromAddr, String subject, String msgBody, Date date) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setTo(toAddr);
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setSubject(subject);
		// simpleMsg.setTo(msgBody);
		simpleMsg.setText(msgBody);
		// simpleMsg.setText(Description);
		simpleMsg.setSentDate(date);
		messageByEmail.send(simpleMsg);
	}

	@Override
	public List<UserStagingVO> approveUsers() {
		List<UserStaging> userList = userStagingRepository.findNewUsers(AppConstants.NO);
		List<UserStagingVO> users = new ArrayList<UserStagingVO>();
		for (UserStaging user : userList) {
			UserStagingVO userStagingVO = new UserStagingVO();
			userStagingVO.setUserName(user.getUserName());
			userStagingVO.setUserCode(user.getUserCode());
			userStagingVO.setUserEmailId(user.getUserEmailId());
			if (user.getUserStatus().equals("Approved")) {
				userStagingVO.setUserStatus("Approved");
			} else if (user.getUserStatus().equals("New")) {
				userStagingVO.setUserStatus("New");
			} else {
				userStagingVO.setUserStatus("Rejected");
			}
			userStagingVO.setId(user.getId());
			users.add(userStagingVO);
		}
		return users;
	}

	// public void sendMail(String msgTxt){
	// SimpleMailMessage mailMessage = new SimpleMailMessage();
	// mailMessage.setText(msgTxt);
	// mailSender.send(mailMessage);
	// }

	@Override
	public UserStagingVO getUser(Long userStagingId) {
		// TODO Auto-generated method stub
		return null;
	}

	// @Override
	// public Role findByRole(String userCode) {
	// return roleRepository.findByName(userCode);
	//
	// }
}
// UserStaging userStaging = new UserStaging();
// userStaging.setCreatedBy(userDetails.getCreatedBy());
// userStaging.setLastModifiedBy(userDetails.getLastModifiedBy());
// userStaging.setCreatedDate(userDetails.getCreatedDate());
// userStaging.setLastModifiedDate(userDetails.getLastModifiedDate());
// userStaging.setIsDeleted(userDetails.getIsDeleted());
// userStaging.setIsActive(userDetails.getIsActive());
// userStaging = userStagingRepository.save(userStaging);

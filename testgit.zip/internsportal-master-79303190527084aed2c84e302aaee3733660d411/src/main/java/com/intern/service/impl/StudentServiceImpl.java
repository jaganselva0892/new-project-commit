package com.intern.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.service.StudentService;
import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.AttachmentsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.entity.AppListItems;
import com.intern.entity.AppliedHistory;
import com.intern.entity.Attachments;
import com.intern.entity.CompanyProfile;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.AppListItemsRepository;
import com.intern.repository.AppliedHistoryRepository;
import com.intern.repository.AttachmentsRepository;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.StudentProfileRepository;
import com.intern.repository.StudentsSkillsRepository;
import com.intern.repository.UserContactRepository;
import com.intern.repository.UserRepository;
import com.intern.utils.AppConstants;
import com.intern.utils.CommonUtils;
import com.mysql.fabric.xmlrpc.base.Array;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	StudentService studentService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserContactRepository userContactRepository;

	@Autowired
	StudentProfileRepository studentProfileRepository;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	InternDetailsRepository internDetailsRepository;

	@Autowired
	StudentsSkillsRepository studentsSkilsRepository;

	@Autowired
	AppListItemsRepository appListItemsRepository;

	@Autowired
	AppliedHistoryRepository appliedHistoryRepository;

	@Autowired
	HttpSession httpSession;

	@Autowired
	AttachmentsRepository attachmentsRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveSearchDetails";

	@Override
	@Transactional(readOnly = true)
	public StudentProfileVO getStudentProfile() {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		StudentProfile studentProfile = studentProfileRepository.findProfileByUser(loginUser, AppConstants.NO);

		// studentProfile.setStudentDateOfBirth(new
		// DateTime(studentProfileVO.getStudentDateOfBirth()).toDate());

		// StudentProfile studentProfileId =
		// studentProfileRepository.findOne(studentProfile.getId());
		UserContact userContact = userContactRepository.findContactByUser(loginUser, AppConstants.NO);
		List<AppListItems> appSkills = appListItemsRepository.findBySkill();
		List<AppListItems> appStream = appListItemsRepository.findByStream();
		List<StudentsSkills> skillRequired = studentsSkilsRepository.findByStream(studentProfile, "Skills");
		String strSkillNames = "";
		for (StudentsSkills stuSkills : skillRequired) {
			// skillName
			if (strSkillNames.equals("")) {
				strSkillNames = stuSkills.getSkillName();
			} else {
				strSkillNames = strSkillNames + "," + stuSkills.getSkillName();
			}
		}

		List<StudentsSkills> streamRequired = studentsSkilsRepository.findByStream(studentProfile, "Stream");
		String strStreamNames = "";
		for (StudentsSkills stuStream : streamRequired) {
			// skillName
			if (strStreamNames.equals("")) {
				strStreamNames = stuStream.getSkillName();
			} else {
				strStreamNames = strStreamNames + "," + stuStream.getSkillName();
			}
		}

		StudentProfileVO studentProfileVO = new StudentProfileVO(studentProfile, userContact, appSkills, appStream);
		studentProfileVO.setSkillNames(strSkillNames);
		studentProfileVO.setStreamName(strStreamNames);
		if (studentProfile.getStudentDateOfBirth() != null) {
			String date = studentProfile.getStudentDateOfBirth().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
						.parse(studentProfile.getStudentDateOfBirth().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				date = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				date = studentProfile.getStudentDateOfBirth().toString();
			}
			studentProfileVO.setStudentDateOfBirth(date);
		}
		// studentProfileVO.setStudentDateOfBirth(new
		// DateTime(studentProfileVO.getStudentDateOfBirth()).toDate());
		Attachments attachments = attachmentsRepository.findByUserWithType(loginUser, "resume", AppConstants.NO);
		studentProfileVO.setIsResume(AppConstants.NO);
		if (attachments != null) {
			AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
			studentProfileVO.setAttachmentsVO(attachmentsVO);
			String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			String imgSrc = "data:image/" + fileExtension + ";base64," + base64String;
			studentProfileVO.setResumeBaseString(fileExtension);
			studentProfileVO.setIsResume(AppConstants.YES);
		}
		return studentProfileVO;
	}

	@Override
	@Transactional(readOnly = false)
	public StudentProfileVO saveStudentDetails(StudentProfileVO studentProfileVO) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		User user = new User();
		StudentProfile studentProfile;
		String strDateFormat = "MM/dd/yyyy";
		try {

			if (studentProfileVO.isNew()) {
				studentProfile = new StudentProfile();
			} else {
				studentProfile = studentProfileRepository.findOne(studentProfileVO.getId());
				// studentProfile.setStudentProfileStatus('P');
				// studentProfile.setStudentDateOfBirth(new
				// DateTime(studentProfileVO.getStudentDateOfBirth()).toDate());
			}

			UserContact userContact;

			// StudentProfile studentProfile =
			// studentProfileRepository.findOne(studentProfileVO.getId());
			userContact = userContactRepository.findContactByUser(loginUser, AppConstants.NO);

			// studentProfile.setUserCode(loginUser.getUserCode());
			if (userContact == null) {
				userContact = new UserContact();
			}
			// StudentsSkills studentSkills;
			// StudentProfile studentProfileid =
			// studentProfileRepository.findOne(studentProfile.getId());
			// studentSkills =
			// studentsSkilsRepository.findSkillByUser(studentProfileid,
			// AppConstants.NO);
			// if (studentSkills == null) {
			// studentSkills = new StudentsSkills();
			// }
			// studentProfileRepository.saveIsActive(studentProfileVO.getIsStudentActive()
			// ? AppConstants.YES : AppConstants.NO);

			userContact.setUserId(loginUser);
			userContact.setMobileNumber(studentProfileVO.getMobileNumber());
			userContact.setUserAddress(studentProfileVO.getUserAddress());
			userContact.setUserCity(studentProfileVO.getUserCity());
//			userContact.setUserCountry(studentProfileVO.getUserCountry());
//			userContact.setUserState(studentProfileVO.getUserState());
			userContact.setUserState("Tamil Nadu");
			userContact.setUserCountry("India");
			

			BeanUtils.copyProperties(studentProfileVO, studentProfile);

			studentProfile.setStudentDateOfBirth(
					CommonUtils.getCustomDateFormat(studentProfileVO.getStudentDateOfBirth(), strDateFormat));
			studentProfile.setStudentProfileStatus('N');
			// User adminUser =
			// userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			// auditorAwareService.setGuestUser(adminUser);
			studentProfile.setIsActive(studentProfileVO.getIsStudentActive() ? AppConstants.YES : AppConstants.NO);
			studentProfile = studentProfileRepository.save(studentProfile);

			userContact = userContactRepository.save(userContact);
			StudentProfile id = studentProfileRepository.findOne(studentProfile.getId());
			saveStudentSkills(studentProfileVO.getSkillName(), "Skills", id);
			saveStudentSkills(studentProfileVO.getStreamName(), "Stream", id);
			// auditorAwareService.setGuestUser(null);

			studentProfileVO.setId(studentProfile.getId());

			return studentProfileVO;

		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
			return null;
		}

	}

	public boolean saveStudentSkills(String skillName, String categoryType, StudentProfile Id) {

		String[] arrSkillName = skillName.split(",");
		List<StudentsSkills> studentSkillList = studentsSkilsRepository.findSkillById(Id);
		for (String strSkillName : arrSkillName) {
			StudentsSkills studentSkills = new StudentsSkills();
			studentSkills.setType(categoryType);
			studentSkills.setStudentProfileId(Id);
			if (!studentSkillList.contains(strSkillName)) {
				studentSkills.setSkillName(strSkillName);
				studentSkills = studentsSkilsRepository.save(studentSkills);
			}
		}
		return true;
	}

	@Override
	@Transactional(readOnly = true)
	public StudentProfileVO getNewStudent() {
		StudentProfileVO studentProfileVO = new StudentProfileVO();
		return studentProfileVO;

	}

	@Override
	public StudentProfileVO getStudentDetails(Long userId) {

		// User users = userRepository.findOne(userId);
		try {
			User Id = userRepository.findOne(userId);
			StudentProfile studentProfile = studentProfileRepository.findByUserId(Id);
			StudentProfile studentProfileId = studentProfileRepository.findOne(studentProfile.getId());
			StudentProfileVO studentProfileVO = new StudentProfileVO();
			studentProfileVO.setId(studentProfile.getId());
			List<AppListItems> appSkills = appListItemsRepository.findBySkill();
			UserContact userContact = userContactRepository.findByUserId(studentProfile.getUserId());
			List<AppListItems> appStream = appListItemsRepository.findByStream();
			// List<StudentsSkills> skillRequired =
			// studentsSkilsRepository.findByStream(studentProfileId, "Stream");
			studentProfileVO = new StudentProfileVO(studentProfile, userContact, appSkills, appStream);
			saveStudentDetails(studentProfileVO);
			return studentProfileVO;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<AppliedHistoryVO> getAppliedDetails() {
		User user = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		User Id = userRepository.findOne(user.getId());
		List<AppliedHistory> appliedDetailsList = appliedHistoryRepository.findByUser(Id, AppConstants.NO);

		List<AppliedHistoryVO> appliedHistoryVOList = new ArrayList<AppliedHistoryVO>();
		for (AppliedHistory appliedDetails : appliedDetailsList) {
			AppliedHistoryVO appliedHistoryVO = new AppliedHistoryVO();
			appliedHistoryVO.setId(appliedDetails.getId());
			InternDetails internDetailsid = internDetailsRepository.findOne(appliedDetails.getInternDetails().getId());
			InternDetails internDetails = internDetailsRepository
					.findByInternDetailsId(appliedDetails.getInternDetails().getId());

			CompanyProfile companyDetails = companyProfileRepository.findByUserId(internDetails.getUserId());
			String appliedDate = appliedDetails.getCreatedDate().toString();
			try {
				Date applyByDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
						.parse(appliedDetails.getCreatedDate().toString());
				appliedDate = new SimpleDateFormat("MM/dd/yyyy").format(applyByDate);
			} catch (Exception ex) {
				appliedDate = appliedDetails.getCreatedDate().toString();
			}
			appliedHistoryVO.setAppliedDate(appliedDate);
			appliedHistoryVO.setInternshipTitle(internDetails.getInternshipTitle());
			appliedHistoryVO.setCompanyName(companyDetails.getCompanyName());

			appliedHistoryVOList.add(appliedHistoryVO);
		}
		return appliedHistoryVOList;
	}

	@Override
	public String listStudents() {
		char isDeleted = AppConstants.NO;
		List<StudentProfile> listStudents = studentProfileRepository.listActiveStudents(isDeleted);
		String listActiveStudents = Integer.toString(listStudents.size());
		return listActiveStudents;
	}

	@Override
	public void deleteAppliedInternPost(Long appliedId) {
		internDetailsRepository.deleteInternByInternId(appliedId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<StudentProfileVO> getStudentProfileView(Long id) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		User user = userRepository.findOne(id);
		UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
		StudentProfile studentProfile = studentProfileRepository.findByUserId(user);
		StudentProfile studentId = studentProfileRepository.findOne(studentProfile.getId());
		List<String> skillList = studentsSkilsRepository.findBySkills(studentId, "Skills");
		List<StudentsSkills> stream = studentsSkilsRepository.findByStream(studentId, "Stream");
		StudentProfileVO studentProfileVO = new StudentProfileVO(studentProfile, skillList, stream, userContact);
		Attachments attachments = attachmentsRepository.findByUserWithType(user, "avatar", AppConstants.NO);
		studentProfileVO.setIsAvatar(AppConstants.NO);

		if (studentProfile.getStudentDateOfBirth() != null) {
			String date = studentProfile.getStudentDateOfBirth().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
						.parse(studentProfile.getStudentDateOfBirth().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				date = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				date = studentProfile.getStudentDateOfBirth().toString();
			}
			studentProfileVO.setStudentDateOfBirth(date);

		}
		if (attachments != null) {
			AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
			studentProfileVO.setAttachmentsVO(attachmentsVO);
			String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			String imgSrc = "data:image/" + fileExtension + ";base64," + base64String;
			studentProfileVO.setAvatarBaseString(imgSrc);
			studentProfileVO.setIsAvatar(AppConstants.YES);

		}
		Attachments attachments1 = attachmentsRepository.findByUserWithType(loginUser, "resume", AppConstants.NO);
		studentProfileVO.setIsResume(AppConstants.NO);

		if (attachments1 != null) {
			AttachmentsVO attachmentsVO = new AttachmentsVO(attachments1);
			studentProfileVO.setAttachmentsVO(attachmentsVO);
			String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			// String imgSrc = "data:image/" + fileExtension + ";base64," +
			// base64String;
			studentProfileVO.setResumeBaseString(fileExtension);
			studentProfileVO.setIsResume(AppConstants.YES);
		}
		studentProfileVO.setUserCountry("India");
		List<StudentProfileVO> listStudentDetails = new ArrayList<StudentProfileVO>();
		listStudentDetails.add(studentProfileVO);
		return listStudentDetails;

	}

	@Override
	public String getCountOfAppliedDetails(Long userId) {
		User user = userRepository.findOne(userId);
		List<AppliedHistory> appliedDetails = appliedHistoryRepository.findByUser(user, AppConstants.NO);
		String appliedHistory = Integer.toString(appliedDetails.size());
		return appliedHistory;
	}
}

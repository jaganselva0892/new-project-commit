package com.intern.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.intern.dto.CompanyProfileVO;
import com.intern.dto.InternDetailsVO;
import com.intern.entity.InternDetails;

@Service
public interface InternDetailService {

	InternDetailsVO getInternDetails();

	InternDetailsVO saveInternDetails(InternDetailsVO internDetailsVO);

	String listPosts();

	String listPostInternshipsCount();
	
	List<InternDetails> getinternList(String categoryName);

	List<InternDetailsVO> listinternships();

	String listPostApprovalPendings();

	List<InternDetailsVO> getPostDetails(Long id);

	
		
}

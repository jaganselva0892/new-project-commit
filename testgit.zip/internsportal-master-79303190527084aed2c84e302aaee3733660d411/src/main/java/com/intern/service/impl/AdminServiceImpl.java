package com.intern.service.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.MailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.service.AdminService;
import com.intern.service.CompanyService;
import com.intern.service.SearchService;
import com.intern.service.StudentService;
import com.intern.utils.AppConstants;
import com.intern.auditor.AuditorAwareService;
import com.intern.controller.AuthenticationController;
import com.intern.dto.AppListItemsVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.HomeVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.SearchFilteringVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserVO;
import com.intern.entity.AppListItems;
import com.intern.entity.Attachments;
import com.intern.entity.CompanyProfile;
import com.intern.entity.FeedBack;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.entity.UserStaging;
import com.intern.exception.InternException;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.AppListItemsRepository;
import com.intern.repository.AttachmentsRepository;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.FeedBackRepository;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.InternDetailsSkillsRepository;
import com.intern.repository.StudentProfileRepository;
import com.intern.repository.StudentsSkillsRepository;
import com.intern.repository.UserContactRepository;
import com.intern.repository.UserRepository;
import com.intern.repository.UserStagingRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AppListItemsRepository appListItemsRepository;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserStagingRepository userStagingRepository;

	@Autowired
	StudentService studentService;

	@Autowired
	AdminService adminService;

	@Autowired
	CompanyService companyService;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	InternDetailsRepository internDetailsRepository;

	@Autowired
	InternDetailsSkillsRepository internDetailsSkillsRepository;

	@Autowired
	UserContactRepository userContactRepository;

	@Autowired
	StudentProfileRepository studentProfileRepository;

	@Autowired
	StudentsSkillsRepository studentsSkilsRepository;

	@Autowired
	private MailSender messageByEmail;

	@Autowired
	AttachmentsRepository attachmentsRepository;

	@Autowired
	FeedBackRepository feedBackRepository;

	@Autowired
	StudentsSkillsRepository studentSkillsRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveUserDetails";
	private static final String METHOD_DOWNLOAD_RESUME = "download Resume";

	@Override
	public AppListItemsVO saveCategoryDetails(AppListItemsVO appListItemsVO) {
		try {
			AppListItems appListItems;
			if (appListItemsVO.isNew()) {
				appListItems = new AppListItems();
			} else {
				return null;
			}

			appListItems.setAppListItemsName(appListItemsVO.getAppListItemsName());
			appListItems.setAppListItemsType(appListItemsVO.getAppListItemsType());
			BeanUtils.copyProperties(appListItemsVO, appListItems);

			User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			auditorAwareService.setGuestUser(adminUser);

			appListItems = appListItemsRepository.save(appListItems);
			auditorAwareService.setGuestUser(null);
			appListItemsVO.setId(appListItems.getId());
			return appListItemsVO;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
			return null;
		}

	}

	@Override
	@Transactional
	public void deletePost(Long internId) {
		internDetailsRepository.deleteByInternId(internId);
		InternDetails internDetails = internDetailsRepository.findOne(internId);
		List<InternDetailsSkills> internSkills = internDetailsSkillsRepository.findByInternDetailsId(internDetails);
		for (InternDetailsSkills InternDetailsSkills : internSkills) {
			InternDetailsSkills.setIsDeleted('Y');
			internDetailsSkillsRepository.save(InternDetailsSkills);
		}
	}

	@Override
	@Transactional
	public void deleteUser(Long userId) {
		userRepository.deleteByuserId(userId);
		User id = userRepository.findOne(userId);
		studentProfileRepository.deleteByuserId(id);
		companyProfileRepository.deleteByuserId(id);
		List<InternDetails> intern = internDetailsRepository.findInternByUser(id, AppConstants.NO);
		for (InternDetails interns : intern) {
			interns.setIsDeleted('Y');
			internDetailsRepository.save(interns);
			List<InternDetailsSkills> internSkills = internDetailsSkillsRepository.findByInternDetailsId(interns);
			for (InternDetailsSkills InternDetailsSkills : internSkills) {
				InternDetailsSkills.setIsDeleted('Y');
				internDetailsSkillsRepository.save(InternDetailsSkills);
			}
		}

	}

	@Override
	public UserVO editUsersProfile(Long userId) {
		User userList = userRepository.findByUserId(userId);
		UserVO userVO = new UserVO();
		userVO.setUserCode(userList.getUserCode());
		return userVO;
	}

	@Override
	public void approveUser(Long userId) {
		User userList = userRepository.findByUserId(userId);
		User Id = userRepository.findOne(userId);
		if (userList.getUserCode().equals("Student")) {
			studentProfileRepository.saveStudentStatus(Id);
		} else {
			companyProfileRepository.saveCompanyStatus(Id);
		}
		sendEmail(userList.getLoginId(), "testannie10@gmail.com", "Congrantulations!",
				"Your Login request is approved , Now you are able to login to our website");

	}

	@Override
	public void approvePost(Long internId) {
		internDetailsRepository.saveInternStatus(internId);
		InternDetails internDetails = internDetailsRepository.findByInternDetailsId(internId);
		User users = internDetails.getUserId();
		sendEmail(users.getLoginId(), "testannie10@gmail.com", "Congrantulations!", "Your Post " + " "
				+ internDetails.getInternshipTitle() + " " + "has been approved, Now it is available in our website");
	}

	public void sendEmail(String toAddr, String fromAddr, String subject, String msgBody) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setTo(toAddr);
		simpleMsg.setSubject(subject);
		simpleMsg.setText(msgBody);
		messageByEmail.send(simpleMsg);
	}
	// @Override
	// public String listUserApprovalPendings() {
	// char studentProfileStatus= AppConstants.NEW;
	// List<StudentProfile> listUserApprovalPendings =
	// studentProfileRepository.listUserPendings(studentProfileStatus);
	// String studentsCount = Integer.toString(listUserApprovalPendings.size());
	// char companyStatus = AppConstants.NEW;
	// List<CompanyProfile> listCompanyApprovalPendings =
	// companyProfileRepository.listComUserPendings(companyStatus);
	// String companyCount =
	// Integer.toString(listCompanyApprovalPendings.size());
	// String user = companyCount.
	// UserVO userVO = new UserVO(studentsCount,companyCount);
	// String usersCount = userVO.toString();
	// return usersCount;
	// }

	@Override
	@Transactional(readOnly = false)
	public void approveUserRequest(Long userStagingId) {
		try {
			UserStaging userApprove = userStagingRepository.findById(userStagingId);

			User user = new User();
			// String password =
			// stringEncryptor.encrypt(String.valueOf(userStagingVO.getPassword()));
			String password = userApprove.getPassword();
			PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String encode = passwordEncoder.encode(password);
			user.setpassword(encode);
			user.setLoginId(userApprove.getUserEmailId());
			user.setUserCode(userApprove.getUserCode());
			User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			auditorAwareService.setGuestUser(adminUser);
			user = userRepository.save(user);
			if (userApprove.getUserCode().equals("Student")) {
				StudentProfile studentProfile = new StudentProfile();
				studentProfile.setStudentFirstName(userApprove.getUserName());
				studentProfile.setStudentEmail(userApprove.getUserEmailId());
				studentProfile.setStudentInstitutionName(userApprove.getUserOrganization());
				studentProfile.setStudentProfileStatus('A');
				studentProfile.setUserId(user);
				studentProfile.setStudentAdharCardNumber(userApprove.getStudentAdharCardNumber());
				studentProfile = studentProfileRepository.save(studentProfile);
			} else {
				CompanyProfile companyProfile = new CompanyProfile();
				companyProfile.setCompanyName(userApprove.getUserName());
				companyProfile.setCompanyEmail(userApprove.getUserEmailId());
				companyProfile.setCompanyDescription(userApprove.getUserOrganization());
				companyProfile.setCompanyProfileStatus('A');
				companyProfile.setUserId(user);
				companyProfile.setCompanyWebsite(userApprove.getCompanyWebsite());
				companyProfile = companyProfileRepository.save(companyProfile);
			}

			userStagingRepository.findByUserStagingId(userStagingId);
			auditorAwareService.setGuestUser(null);
			sendEmail(userApprove.getUserEmailId(), "testannie10@gmail.com", "Congrantulations!",
					"Your Login request is approved , Now you are able to login to our website");
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
		}
	}

	@Override
	public void deleteUserRegister(Long userStagingId) {
		userStagingRepository.deleteById(userStagingId);
	}

	@Override
	public List<HomeVO> getinternshipDetails() {
		List<AppListItems> listAppSkillLists = appListItemsRepository.findBySkill();
		List<AppListItems> listAppStreamLIst = appListItemsRepository.findByStream();
		HomeVO homeVO = new HomeVO(listAppSkillLists, listAppStreamLIst);
		List<HomeVO> listItems = new ArrayList<HomeVO>();
		listItems.add(homeVO);
		return listItems;
	}

	@Override
	@Transactional(readOnly = true)
	public void downloadResume(Long userId, HttpServletResponse response) throws IOException, InternException {
		User user = userRepository.findOne(userId);
		Attachments attachment = attachmentsRepository.findByUserWithType(user, "resume", AppConstants.NO);
		if (attachment != null) {
			response.setContentType(attachment.getFileContentType());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + attachment.getFileName());// fileName);
			// response.setHeader("Content-Disposition" +
			// AppConstants.RESPONSE_ATTACH_PREFIX,
			// AppConstants.RESPONSE_ATTACH_SUFFIX + attachment.getFileName());
			byte[] byteArray = attachment.getAttachmentData();
			OutputStream os = response.getOutputStream();
			try {
				os.write(byteArray, 0, byteArray.length);
			} catch (Exception e) {
				e.getMessage();
			}
			return;
		} else {
			LOGGER.warn(CLASS_NAME, METHOD_DOWNLOAD_RESUME, "{} No resume is found", user);
			throw new InternException(AppConstants.MSG_NO_RESUME_FOUND);
		}
	}

	@Override
	public void sendQueries(HomeVO homeVO) {
		User loginUser = auditorAwareService.getCurrentAuditor();
		FeedBack feedback = new FeedBack();
		feedback.setEmailId(homeVO.getEmailId());
		feedback.setFeedbackDesc(homeVO.getFeedbackDesc());
		if (loginUser != null) {
			feedback.setUserId(loginUser);
			feedback = feedBackRepository.save(feedback);
			auditorAwareService.setGuestUser(null);
			sendEmailToAdmin(homeVO.getEmailId(), "testannie10@gmail.com", "Query from User",
					homeVO.getName() + " " + "has been contacted us.");
		} else {
			User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
			auditorAwareService.setGuestUser(adminUser);
			loginUser = auditorAwareService.getCurrentAuditor();
			feedback.setUserId(loginUser);
			feedback = feedBackRepository.save(feedback);
			auditorAwareService.setGuestUser(null);
			sendEmailToAdmin(homeVO.getEmailId(), "testannie10@gmail.com", "Query from User",
					homeVO.getName() + " " + "has been contacted us.");
			auditorAwareService.setGuestUser(null);
		}

	}

	public void sendEmailToAdmin(String toAddr, String fromAddr, String subject, String msgBody) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setTo(toAddr);
		simpleMsg.setSubject(subject);
		simpleMsg.setText(msgBody);
		messageByEmail.send(simpleMsg);
	}

	@Override
	public List<StudentDetailsVO> getStudentDetailsToView(Long userstagingId) {
		List<StudentDetailsVO> listStudentDetails = new ArrayList<StudentDetailsVO>();
		try {
			UserStaging users = userStagingRepository.findOne(userstagingId);
			StudentDetailsVO usersDetails = new StudentDetailsVO();
			usersDetails.setStudentFirstName(users.getUserName());
			usersDetails.setStudentInstitutionName(users.getUserOrganization());
			usersDetails.setMobileNumber(users.getUserMobileNumber());
			usersDetails.setUserCode(users.getUserCode());
			if (users.getUserCode().equals("Student")) {
				usersDetails.setStudentAdharCardNumber(users.getStudentAdharCardNumber());
			} else {
				usersDetails.setCompanyWebsite(users.getCompanyWebsite());
			}
			listStudentDetails.add(usersDetails);
		} catch (Exception ex) {
			ex.getMessage();
		}
		return listStudentDetails;
	}

	@Override
	public void activateOrDeactiveUser(Long userId) {
		User user = userRepository.findByUserId(userId);
		if (user.getIsActive().equals('Y')) {
			userRepository.updateDeActiveStatus(userId);
		} else {
			userRepository.updateActiveStatus(userId);
		}
	}

	@Override
	public void activateOrDeactivePost(Long internId) {
		InternDetails internDetails = internDetailsRepository.findByInternDetailsId(internId);
		if (internDetails.getIsActive().equals('Y')) {
			internDetailsRepository.updateDeActiveStatus(internId);
		} else {
			internDetailsRepository.updateActiveStatus(internId);
		}

	}

	@Override
	@Transactional(readOnly = true)
	public List<StudentDetailsVO> getUserDetails(Long userId) {
		User user = userRepository.findOne(userId);
		List<StudentDetailsVO> listStudentDetails = new ArrayList<StudentDetailsVO>();
		try {
			if (user.getUserCode().equals("Company")) {
				StudentDetailsVO studentDetailsVO = new StudentDetailsVO();
				CompanyProfile companyProfile = companyProfileRepository.findProfileByUser(user, AppConstants.NO);
				if (companyProfile != null) {
					UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
					if (userContact != null) {
						studentDetailsVO.setCompanyName(companyProfile.getCompanyName());
						studentDetailsVO.setCompanyEmail(companyProfile.getCompanyEmail());
						studentDetailsVO.setCompanyWebsite(companyProfile.getCompanyEmail());
						studentDetailsVO.setMobileNumber(userContact.getMobileNumber());
						studentDetailsVO.setUserCity(userContact.getUserCity());
						studentDetailsVO.setUserAddress(userContact.getUserAddress());
						studentDetailsVO.setUserCode(user.getUserCode());
					}
				}
				listStudentDetails.add(studentDetailsVO);
			} else if (user.getUserCode().equals("Student")) {
				StudentProfile studentProfile = studentProfileRepository.findByUserId(user);
				StudentProfile studentId = studentProfileRepository.findOne(studentProfile.getId());
				UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
				List<String> skillList = studentSkillsRepository.findBySkills(studentId, "Skills");
				List<StudentsSkills> stream = studentSkillsRepository.findByStream(studentId, "Stream");
				StudentDetailsVO studentDetailsVO = new StudentDetailsVO(studentProfile, skillList, stream,
						userContact);
				studentDetailsVO.setUserCode(user.getUserCode());
				listStudentDetails.add(studentDetailsVO);
			}
			return listStudentDetails;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	// @Override
	// public getUserId(Long attachId) {
	// Attachments attachment = attachmentsRepository.findOne(attachId);
	// return null;
	// }
}
package com.intern.service;

import org.springframework.stereotype.Service;

import com.intern.dto.AttachmentsVO;

@Service
public interface AttachmentService {

	boolean saveAttachment(AttachmentsVO attachmentsVO);
	
	boolean removeAttachment(Long attachmentId);
	
}
package com.intern.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.StudentProfileVO;

@Service
public interface StudentService {

	StudentProfileVO saveStudentDetails(StudentProfileVO studentProfileVO);

	StudentProfileVO getNewStudent();

	StudentProfileVO getStudentProfile();

	StudentProfileVO getStudentDetails(Long userId);

	void deleteAppliedInternPost(Long appliedId);

	List<AppliedHistoryVO> getAppliedDetails();

	String listStudents();

	List<StudentProfileVO> getStudentProfileView(Long id);

	String getCountOfAppliedDetails(Long userId);

	// List<StudentProfileVO> getStudentProfileView(Long id);
	// void deletePost(Long internId);
	// String listUserApprovalPendings();
	// Map<String, String> getStudentDetails(Long studentProfileId);

}

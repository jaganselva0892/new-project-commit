package com.intern.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.util.StringUtil;
import org.joda.time.DateTime;
import org.json.simple.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.MailSender;

import com.intern.service.InternDetailService;
import com.intern.service.SearchService;
import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.SearchFilteringVO;
import com.intern.dto.StudentsSkillsVO;
import com.intern.entity.AppListItems;
import com.intern.entity.AppliedHistory;
import com.intern.entity.CompanyProfile;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.entity.UserStaging;
import com.intern.exception.InternException;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.AppListItemsRepository;
import com.intern.repository.AppliedHistoryRepository;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.InternDetailsSkillsRepository;
import com.intern.repository.StudentsSkillsRepository;
import com.intern.repository.UserContactRepository;
import com.intern.repository.UserRepository;
import com.intern.utils.AppConstants;

@Service("searchService")
public class SearchServiceImpl implements SearchService {

	@Autowired
	private AppListItemsRepository appListItemsRepository;

	@Autowired
	private InternDetailsRepository internDetailsRepository;

	@Autowired
	InternDetailsSkillsRepository internDetailsSkillsRepository;

	@Autowired
	private SearchService searchService;

	@Autowired
	StudentsSkillsRepository studentsSkilsRepository;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	UserContactRepository userContactRepository;

	@Autowired
	AppliedHistoryRepository appliedHistoryRepository;

	@Autowired
	HttpSession httpSession;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	private InternDetailService internDetailService;

	@Autowired
	private MailSender messageByEmail;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveSearchDetails";
	private static final String METHOD_GET_DETAILS = "getSearchDetails";
	private static final String METHOD_ALREADY_SAVE_DETAILS = "Already Applied";
	private static final String METHOD_NO_SEARCH_RESULTS = "search Results not found";

	// @Override
	// public List<AppListItems> SearchDetails(Long applistitemsId) {
	// List<AppListItems> applist = appListItemsRepository.findAll();
	// return applist ;
	// }
	@Override
	public List<AppListItems> SearchDetails() {
		// List<AppListItems> applist = new ArrayList<AppListItems>();
		List<AppListItems> applist = appListItemsRepository.findAll();
		return applist;
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public String SearchByCategory(String applistitemsName) {
		try {
			List<AppListItems> searchDetails = appListItemsRepository.findByAppListItemsName(applistitemsName);
			// List<AppListItems> listSearchDetails = new
			// ArrayList<AppListItems>();
			// listSearchDetails.addAll(searchDetails);

			JSONObject jsonObj = new JSONObject();
			for (AppListItems appListItems : searchDetails) {
				jsonObj.put("id", appListItems.getId());
				jsonObj.put("type", appListItems.getAppListItemsType());
				jsonObj.put("name", appListItems.getAppListItemsName());
			}
			String jsonStr = jsonObj.toString();
			return jsonStr;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	@Override
	@Transactional(readOnly = true)
	public Map<String, Object> getStreamName(String appListItemsName) {
		try {
			AppListItems StreamName = appListItemsRepository.findByStream(appListItemsName);
			List<AppListItems> listSearchDetails = new ArrayList<AppListItems>();
			listSearchDetails.add(StreamName);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("applistitemsName", StreamName.getAppListItemsName());
			return jsonObj;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
		// Map<String, Object> appListItemsMapObj = new
		// LinkedHashMap<>(listSearchDetails.size());
		// Map<String, String> appListItemsMap = new
		// LinkedHashMap<>(listSearchDetails.size());
		// appListItemsMap.put("id", StreamName.getId().toString());
		// appListItemsMap.put("name", StreamName.getAppListItemsName());
		// appListItemsMap.put("type", StreamName.getAppListItemsType());
		// appListItemsMapObj.put("name", StreamName);
		// return appListItemsMapObj;

	}

	@Override
	public List<AppListItems> searchCategoryDetails() {
		List<AppListItems> applist = appListItemsRepository.findByStream();
		return applist;
	}

	@Override
	public List<AppListItems> searchSkillDetails() {
		List<AppListItems> skillList = appListItemsRepository.findBySkill();
		return skillList;
	}

	// @Override
	// public InternDetailsVO searchInternDetails() {
	// InternDetails internDetail = new InternDetails();
	// List<InternDetails> internDetails = internDetailsRepository.findAll();
	// List<CompanyProfile> companyProfile = companyProfileRepository.findAll();
	// List<UserContact> userContact = userContactRepository.findAll();
	// return new
	// InternDetailsVO(internDetail,internDetails,companyProfile,userContact);
	// }

	// <<<<<<< HEAD
	// public List<InternDetailsVO> searchInternDetails(String searchKey) {
	// List<InternDetailsVO> listInternDetailsVO = new
	// ArrayList<InternDetailsVO>();
	// // List<InternDetails> internDetailsList =
	// // internDetailsRepository.listInternDetails(isDeleted);
	// List<InternDetails> internDetailsList =
	// internDetailService.getinternList(searchKey);
	// // List<InternDetailsVO> searchByVariousCategories(
	// for (InternDetails internDetails : internDetailsList) {
	// InternDetailsVO internDetailsVO = new InternDetailsVO();
	// // BeanUtils.copyProperties(internDetails, internDetailsVO);
	// internDetailsVO.setInternshipTitle(internDetails.getInternshipTitle());
	// internDetailsVO.setInternshipDescription(internDetails.getInternshipDescription());
	// internDetailsVO.setUserCity(internDetails.getStipend());
	// internDetailsVO.setStipend(internDetails.getStipend());
	// internDetailsVO.setApplyDate(internDetails.getApplyDate());
	// // String ApplyDate = internDetails.getApplyDate().toString();
	//
	// // try {
	// // Date applyDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
	// // .parse(internDetails.getApplyDate().toString());
	// // ApplyDate = new SimpleDateFormat("dd/MM/yyyy").format(applyDate);
	// // } catch (Exception ex) {
	// // ApplyDate = internDetails.getApplyDate().toString();
	// // }
	//
	// internDetailsVO.setEndDate(internDetails.getEndDate());
	// internDetailsVO.setStartAndEndDate(internDetails.getStartAndEndDate());
	// // internDetailsVO.setStartAndEndDate("15-Apr-2017 to 15-jun-2017");
	// // internDetailsVO.setApplyDate("12-Apr-2017");
	// internDetailsVO.setDuration(internDetails.getDuration());
	// internDetailsVO.setId(internDetails.getId());
	// //
	// internDetailsVO.setPostedDate(internDetails.getPostedDate().toString());
	// // internDetailsVO.setPostedDate("1-Apr-2017");
	// User userId = internDetails.getUserId();
	// char deleted = AppConstants.NO;
	// UserContact useraddr = userContactRepository.findContactByUser(userId,
	// deleted);
	// if (useraddr != null) {
	// internDetailsVO.setUserCity(useraddr.getUserCity());
	// internDetailsVO.setUserAddress(useraddr.getUserAddress());
	// }
	// CompanyProfile companyDetails =
	// companyProfileRepository.findProfileByUser(userId, deleted);
	// if (companyDetails != null) {
	// internDetailsVO.setCompanyName(companyDetails.getCompanyName());
	// internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
	// }
	// =======
	@Override
	@Transactional(readOnly = true)

	public List<InternDetailsVO> searchInternDetails(String searchKey) throws IOException, InternException {

		try {
			List<InternDetailsVO> listInternDetailsVO = new ArrayList<InternDetailsVO>();
			// List<InternDetails> internDetailsList =
			// internDetailsRepository.listInternDetails(isDeleted);
			List<InternDetails> internDetailsList = internDetailService.getinternList(searchKey);
			if (internDetailsList != null) {
				// List<InternDetailsVO> searchByVariousCategories(
				for (InternDetails internDetails : internDetailsList) {

					if (internDetails.getPostStatus().equals('A')) {
						InternDetailsVO internDetailsVO = new InternDetailsVO();
						// BeanUtils.copyProperties(internDetails,
						// internDetailsVO);
						internDetailsVO.setInternshipTitle(internDetails.getInternshipTitle());
						internDetailsVO.setInternshipDescription(internDetails.getInternshipDescription());
						internDetailsVO.setUserCity(internDetails.getStipend());
						internDetailsVO.setStipend(internDetails.getStipend());
						internDetailsVO.setUserId(internDetails.getUserId());
						// String applyDate =
						// internDetails.getApplyDate().toString();
						// try {
						// Date appDate = new
						// SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
						// .parse(internDetails.getApplyDate().toString());
						// applyDate = new
						// SimpleDateFormat("MM/dd/yyyy").format(appDate);
						// } catch (Exception ex) {
						// applyDate = internDetails.getApplyDate().toString();
						// }
						// internDetailsVO.setApplyDate(internDetails.getApplyDate());
						// internDetailsVO.setEndDate(internDetails.getEndDate());
						// internDetailsVO.setStartAndEndDate(internDetails.getStartAndEndDate());
						// internDetailsVO.setStartAndEndDate("15-Apr-2017 to
						// 15-jun-2017");
						// internDetailsVO.setApplyDate("12-Apr-2017");
						String appdate = internDetails.getApplyDate().toString();

						try {
							Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(internDetails.getApplyDate().toString());
							SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
							appdate = format.format(db);
							// date = new
							// SimpleDateFormat("MM/dd/yyyy").format(db);
							// Date dob = new Date(str);

						} catch (Exception ex) {
							appdate = internDetails.getApplyDate().toString();
						}
						internDetailsVO.setApplyDate(appdate);
						String enddate = internDetails.getEndDate().toString();

						try {
							Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(internDetails.getEndDate().toString());
							SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
							enddate = format.format(db);
							// date = new
							// SimpleDateFormat("MM/dd/yyyy").format(db);
							// Date dob = new Date(str);

						} catch (Exception ex) {
							enddate = internDetails.getEndDate().toString();
						}
						internDetailsVO.setEndDate(enddate);
						String date = internDetails.getStartAndEndDate().toString();

						try {
							Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
									.parse(internDetails.getStartAndEndDate().toString());
							SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
							date = format.format(db);
							// date = new
							// SimpleDateFormat("MM/dd/yyyy").format(db);
							// Date dob = new Date(str);

						} catch (Exception ex) {
							date = internDetails.getStartAndEndDate().toString();
						}
						internDetailsVO.setStartAndEndDate(date);
						internDetailsVO.setDuration(internDetails.getDuration());
						internDetailsVO.setId(internDetails.getId());
						// internDetailsVO.setPostedDate(internDetails.getPostedDate().toString());
						// internDetailsVO.setPostedDate("1-Apr-2017");
						User userId = internDetails.getUserId();
						char deleted = AppConstants.NO;
						UserContact useraddr = userContactRepository.findContactByUser(userId, deleted);
						if (useraddr != null) {
							internDetailsVO.setUserCity(useraddr.getUserCity());
							internDetailsVO.setUserAddress(useraddr.getUserAddress());
						}
						CompanyProfile companyDetails = companyProfileRepository.findProfileByUser(userId, deleted);
						if (companyDetails != null) {
							internDetailsVO.setCompanyName(companyDetails.getCompanyName());
							internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
							internDetailsVO.setCompanyEmail(companyDetails.getCompanyEmail());
						}
						if (!listInternDetailsVO.contains(internDetailsVO)) {
							listInternDetailsVO.add(internDetailsVO);
						}
					}
				}
//			} else {
//				internDetailsList = internDetailsRepository.findAll(AppConstants.NO);
//				for (InternDetails intern : internDetailsList) {
//					listInternDetailsVO.add(new InternDetailsVO(intern));
//				}

			}
			// List<InternDetails> internDetails = new
			// ArrayList<InternDetails>();
			// internDetails.add(internDetail);
			return listInternDetailsVO;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_NO_SEARCH_RESULTS, ex);
			return null;
		}

	}

	@Override
	@Transactional(readOnly = false)
	public InternDetailsVO saveAppliedDetails(InternDetailsVO saveInternDetailsVO) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		try {
			AppliedHistory appliedHistory = new AppliedHistory();
			// List<AppliedHistory> saveappliedHistories =
			// appliedHistoryRepository.findByUser(loginUser, AppConstants.NO);
			// for (AppliedHistory appliedHistoryList : saveappliedHistories) {
			// if
			// (appliedHistoryList.getInternDetails().equals(saveInternDetailsVO.getId()))
			// {
			// BeanUtils.copyProperties(appliedHistoryList, appliedHistory);
			// break;
			// }
			// BeanUtils.copyProperties(internDetailsVO, internDetails);

			InternDetails internId = internDetailsRepository.findOne(saveInternDetailsVO.getId());
			List<AppliedHistory> saveappliedHistorie = appliedHistoryRepository.findByUserInterDetail(loginUser,
					AppConstants.NO, internId);
			if (saveappliedHistorie.size() == 0) {
				appliedHistory.setAppliedStatus("Applied");
				appliedHistory.setInternDetails(internId);
				appliedHistory.setUserId(loginUser);
				User adminUser = userRepository.getAdminUserbyEmail("admin@aalamsoft.com");
				auditorAwareService.setGuestUser(adminUser);
				appliedHistory = appliedHistoryRepository.save(appliedHistory);

				auditorAwareService.setGuestUser(null);
				String userMailId = loginUser.getLoginId().toString();
				sendEmailToUser(userMailId, "testannie10@gmail.com", "Success Message",
						"You are Successfully Applied for the Internship" + " "
								+ saveInternDetailsVO.getInternshipTitle());
				sendEmailToCompany(saveInternDetailsVO.getCompanyEmail(), "testannie10@gmail.com", "Applied Messge",
						userMailId + " " + "applied for the Your Internship" + " "
								+ saveInternDetailsVO.getInternshipTitle());
			} else {
				LOGGER.info(CLASS_NAME, METHOD_ALREADY_SAVE_DETAILS, "{} You are already applied for this post.",
						loginUser.getLoginId());
				System.out.println("Already Applied By You");
			}
			return saveInternDetailsVO;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, "{} You are already applied for this post.",
					loginUser.getLoginId());
			return null;
		}
	}

	public void sendEmailToUser(String loginUser, String fromAddr, String subject, String msgBody) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setTo(loginUser);
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setSubject(subject);
		simpleMsg.setText(msgBody);
		messageByEmail.send(simpleMsg);
	}

	public void sendEmailToCompany(String loginUser, String fromAddr, String subject, String msgBody) {
		SimpleMailMessage simpleMsg = new SimpleMailMessage();
		simpleMsg.setTo(loginUser);
		simpleMsg.setFrom(fromAddr);
		simpleMsg.setSubject(subject);
		simpleMsg.setText(msgBody);
		messageByEmail.send(simpleMsg);
	}

	@Override
	@Transactional(readOnly = true)
	public List<SearchFilteringVO> searchByVariousCategories(SearchFilteringVO searchFilteringVO) {
		try {
			char isDeleted = AppConstants.NO;

			// List<InternDetails> listInternPosts =
			// internDetailsRepository.listInternDetails(isDeleted);
			// List<InternDetailsSkills> listCatagories = new
			// ArrayList<InternDetailsSkills>();
			List<UserContact> listContacts = userContactRepository.listContacts(isDeleted);
			// List<UserContact> listContacts = new ArrayList<UserContact>();
			List<InternDetails> internList = internDetailsRepository.listInternDetails(isDeleted);

			List<InternDetails> internListReturn = new ArrayList<InternDetails>();

			List<InternDetailsSkills> catagoriesSkills = new ArrayList<InternDetailsSkills>();
			// if (!StringUtils.isEmpty(searchFilteringVO.getSkillsRequired())
			// && !StringUtils.isEmpty(searchFilteringVO.getEligibility())) {
			// catagoriesSkills = internDetailsSkillsRepository
			// .findByCategoryName(searchFilteringVO.getSkillsRequired(),
			// searchFilteringVO.getEligibility());
			// if (catagoriesSkills.size() == 0) {
			// return null;
			// }}
			if (!StringUtils.isEmpty(searchFilteringVO.getEligibility())) {
				catagoriesSkills = internDetailsSkillsRepository.findByCategory(isDeleted,
						searchFilteringVO.getEligibility());
				// if (catagoriesSkills.size() == 0) {
				// return null;
				// }
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getSkillsRequired())) {
				catagoriesSkills = internDetailsSkillsRepository.findByCategory(isDeleted,
						searchFilteringVO.getSkillsRequired());
				// if (catagoriesSkills.size() == 0) {
				// return null;
				// }
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getInternshipType())) {
				internList = internDetailsRepository.findByType(searchFilteringVO.getInternshipType(), AppConstants.NO);
				// if (internList.size() == 0) {
				// return null;
				// }
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getUserCity())) {
				listContacts = userContactRepository.findContactByCity(searchFilteringVO.getUserCity(),
						AppConstants.NO);
				// if (listContacts.size() == 0) {
				// return null;
				// }
			}
			internListReturn = internList;
			if (catagoriesSkills.size() > 0) {
				internListReturn = new ArrayList<InternDetails>();
				for (InternDetailsSkills internDetailsSkills : catagoriesSkills) {

					for (InternDetails intern : internList) {
						if (intern.getId().equals(internDetailsSkills.getInternDetailsId().getId())) {
							internListReturn.add(intern);
						}
					}
				}
				internList = new ArrayList<InternDetails>();
				internList = internListReturn;
			}
			if (listContacts.size() > 0) {
				internListReturn = new ArrayList<InternDetails>();
				for (UserContact listContact : listContacts) {

					for (InternDetails intern : internList) {
						if (intern.getUserId().equals(listContact.getUserId())) {
							internListReturn.add(intern);
						}
					}
				}
				internList = new ArrayList<InternDetails>();
				internList = internListReturn;
			}

			List<SearchFilteringVO> internDetailsVO = new ArrayList<SearchFilteringVO>();
			for (InternDetails intern : internListReturn) {
				internDetailsVO.add(new SearchFilteringVO(intern));
			}
			return internDetailsVO;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_GET_DETAILS, ex);
			return null;
		}

	}

	@Override
	@Transactional(readOnly = true)
	public SearchFilteringVO getSearchDetails() {
		try {
			SearchFilteringVO searchFilteringVO = new SearchFilteringVO();
			// InternDetails internDetails = new InternDetails();
			// internDetails = internDetailsRepository.findOne(Id);
			List<AppListItems> appListSkill = appListItemsRepository.findBySkill();
			List<AppListItems> appListStream = appListItemsRepository.findByStream();
			searchFilteringVO.setSkillRequired(appListSkill);
			searchFilteringVO.setStreamName(appListStream);
			return searchFilteringVO;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	// <<<<<<< HEAD
	// public List<InternDetailsVO> leftPanelSearchPosts(SearchFilteringVO
	// searchFilteringVO) {
	//
	// List<InternDetails> internDetailsList =
	// filterFromLeftSide(searchFilteringVO);
	// List<InternDetailsVO> internDetailsVOList = new
	// ArrayList<InternDetailsVO>();
	// for (InternDetails internDetails : internDetailsList) {
	// if (internDetails != null) {
	// // InternDetails internDetailsVO =
	// // internDetailsRepository.getOne(internDetails.getId());
	// // InternDetails internDetailsVO = internDetails;
	//
	// // BeanUtils.copyProperties(internDetails, internDetailsVO);
	// // internDetailsVO.setInternshipTitle(internDetails);
	// //
	// internDetailsVO.setInternshipDescription(internDetails.getInternshipDescription());
	// // internDetailsVO.setUserCity(internDetails);
	// // internDetailsVO.setStipend(internDetails.getStipend());
	// // //
	// // internDetailsVO.setApplyDate(internDetails.getApplyDate().toString());
	//
	// // internDetails.setStartAndEndDate(DateTime.now().toDate());
	// // internDetails.setApplyDate(DateTime.now().toDate());
	// // internDetailsVO.setDuration(internDetails.getDuration());
	// // internDetailsVO.setId(internDetails.getId());
	// //
	// internDetailsVO.setPostedDate(internDetails.getPostedDate().toString());
	// // internDetails.setPostedDate(DateTime.now().toDate());
	//
	// InternDetailsVO internDetailsVO = new InternDetailsVO(internDetails);
	// User userId = internDetails.getUserId();
	// char deleted = AppConstants.NO;
	//
	// UserContact useraddr = userContactRepository.findContactByUser(userId,
	// deleted);
	// if (useraddr != null) {
	// internDetailsVO.setUserCity(useraddr.getUserCity());
	// internDetailsVO.setUserAddress(useraddr.getUserAddress());
	// }
	// CompanyProfile companyDetails =
	// companyProfileRepository.findProfileByUser(userId, deleted);
	// if (companyDetails != null) {
	// internDetailsVO.setCompanyName(companyDetails.getCompanyName());
	// internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
	// }
	//
	//
	// internDetailsVOList.add(internDetailsVO);
	// }
	// =======
	//
	@Override
	@Transactional(readOnly = true)

	public List<InternDetailsVO> leftPanelSearchPosts(SearchFilteringVO searchFilteringVO)
			throws IOException, InternException {
		try {

			List<InternDetails> internDetailsList = filterFromLeftSide(searchFilteringVO);
			List<InternDetailsVO> internDetailsVOList = new ArrayList<InternDetailsVO>();
			for (InternDetails internDetails : internDetailsList) {
				if (internDetails.getPostStatus().equals('A')) {
					// InternDetails internDetailsVO =
					// internDetailsRepository.getOne(internDetails.getId());
					// InternDetails internDetailsVO = internDetails;

					// BeanUtils.copyProperties(internDetails, internDetailsVO);
					// internDetailsVO.setInternshipTitle(internDetails);
					// internDetailsVO.setInternshipDescription(internDetails.getInternshipDescription());
					// internDetailsVO.setUserCity(internDetails);
					// internDetailsVO.setStipend(internDetails.getStipend());
					// //
					// internDetailsVO.setApplyDate(internDetails.getApplyDate().toString());

					// internDetails.setStartAndEndDate(DateTime.now().toDate());
					// internDetails.setApplyDate(DateTime.now().toDate());
					// internDetailsVO.setDuration(internDetails.getDuration());
					// internDetailsVO.setId(internDetails.getId());
					// internDetailsVO.setPostedDate(internDetails.getPostedDate().toString());
					// internDetails.setPostedDate(DateTime.now().toDate());
					InternDetailsVO internDetailsVO = new InternDetailsVO(internDetails);
					internDetailsVO.setUserId(internDetails.getUserId());
					String appdate = internDetails.getApplyDate().toString();

					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getApplyDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						appdate = format.format(db);
						// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
						// Date dob = new Date(str);

					} catch (Exception ex) {
						appdate = internDetails.getApplyDate().toString();
					}
					internDetailsVO.setApplyDate(appdate);
					String enddate = internDetails.getEndDate().toString();

					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getEndDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						enddate = format.format(db);
						// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
						// Date dob = new Date(str);

					} catch (Exception ex) {
						enddate = internDetails.getEndDate().toString();
					}
					internDetailsVO.setEndDate(enddate);
					String date = internDetails.getStartAndEndDate().toString();

					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getStartAndEndDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						date = format.format(db);
						// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
						// Date dob = new Date(str);

					} catch (Exception ex) {
						date = internDetails.getStartAndEndDate().toString();
					}
					internDetailsVO.setStartAndEndDate(date);

					User userId = internDetails.getUserId();
					char deleted = AppConstants.NO;

					UserContact useraddr = userContactRepository.findContactByUser(userId, deleted);
					internDetailsVO.setUserCity(useraddr.getUserCity());
					internDetailsVO.setUserAddress(useraddr.getUserAddress());
					CompanyProfile companyDetails = companyProfileRepository.findProfileByUser(userId, deleted);
					internDetailsVO.setCompanyName(companyDetails.getCompanyName());
					internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
					internDetailsVO.setCompanyEmail(companyDetails.getCompanyEmail());

					internDetailsVOList.add(internDetailsVO);
				}
			}
			// List<InternDetails> internDetails = new
			// ArrayList<InternDetails>();
			// internDetails.add(internDetail);
			return internDetailsVOList;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_NO_SEARCH_RESULTS, ex);
			throw new InternException(AppConstants.NO_RESULTS_FOUND);
		}

	}

	@Override
	@Transactional(readOnly = true)
	public List<InternDetails> filterFromLeftSide(SearchFilteringVO searchFilteringVO) {
		try {
			char isDeleted = AppConstants.NO;
			List<InternDetails> internListReturn = new ArrayList<InternDetails>();

			if (!StringUtils.isEmpty(searchFilteringVO.getEligibility())) {
				List<InternDetailsSkills> catagoriesSkills = internDetailsSkillsRepository.findByCategory(isDeleted,
						searchFilteringVO.getEligibility());
				for (InternDetailsSkills catagoriesSkill : catagoriesSkills) {
					// <<<<<<< HEAD
					// if (catagoriesSkill.getInternDetailsId() != null) {
					// InternDetails internDetails = internDetailsRepository
					// .findByInternDetailId(catagoriesSkill.getInternDetailsId().getId(),
					// isDeleted);
					// if (internListReturn.contains(internDetails)) {
					// internListReturn.add(internDetails);
					// }
					// =======
					InternDetails internDetails = internDetailsRepository
							.findOne(catagoriesSkill.getInternDetailsId().getId());
					if (!internListReturn.contains(internDetails)) {
						internListReturn.add(internDetails);
					}
				}
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getSkillsRequired())) {
				List<InternDetailsSkills> catagoriesSkills = internDetailsSkillsRepository.findByCategory(isDeleted,
						searchFilteringVO.getSkillsRequired());
				for (InternDetailsSkills catagoriesSkill : catagoriesSkills) {
					if (catagoriesSkill.getInternDetailsId() != null) {
						InternDetails internDetails = internDetailsRepository
								.findByInternDetailId(catagoriesSkill.getInternDetailsId().getId(), isDeleted);
						if (!internListReturn.contains(internDetails)) {
							internListReturn.add(internDetails);
						}
					}
				}
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getInternshipType())) {
				List<InternDetails> internDetailList = internDetailsRepository
						.findByType(searchFilteringVO.getInternshipType(), AppConstants.NO);
				for (InternDetails internDetail : internDetailList) {
					if (!internListReturn.contains(internDetail)) {
						internListReturn.add(internDetail);
					}
				}
			}
			if (!StringUtils.isEmpty(searchFilteringVO.getUserCity())) {
				List<UserContact> listContacts = userContactRepository
						.findContactByCity(searchFilteringVO.getUserCity(), AppConstants.NO);
				for (UserContact userContact : listContacts) {
					List<InternDetails> internDetails = internDetailsRepository
							.findInternByUser(userContact.getUserId(), AppConstants.NO);
					for (InternDetails internDetail : internDetails) {
						if (!internListReturn.contains(internDetail)) {
							internListReturn.add(internDetail);
						}
					}
				}

			}
			// internListReturn = internList;
			// if (catagoriesSkills.size() > 0) {
			// internListReturn = new ArrayList<InternDetails>();
			// for (InternDetailsSkills internDetailsSkills : catagoriesSkills)
			// {
			//
			// for (InternDetails intern : internList) {
			// if
			// (intern.getId().equals(internDetailsSkills.getInternDetailsId().getId()))
			// {
			// internListReturn.add(intern);
			// }
			// }
			// }
			// internList = new ArrayList<InternDetails>();
			// internList = internListReturn;
			// }

			// if (listContacts.size() > 0) {
			// internListReturn = new ArrayList<InternDetails>();
			// for (UserContact listContact : listContacts) {
			//
			// for (InternDetails intern : internList) {
			// if (intern.getUserId().equals(listContact.getUserId())) {
			// internListReturn.add(intern);
			// }
			// }
			// }
			// internList = new ArrayList<InternDetails>();
			// internList = internListReturn;
			// }

			// List<SearchFilteringVO> internDetailsVO = new
			// ArrayList<SearchFilteringVO>();
			// for (InternDetails intern : internListReturn) {
			// internDetailsVO.add(new SearchFilteringVO(intern));
			// }
			return internListReturn;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_GET_DETAILS, ex);
			return null;
		}

	}

	@Override
	public InternDetailsVO findByInternId(Long internId) {
		InternDetailsVO internDetailsVO = internDetailsRepository.findById(internId);
		return internDetailsVO;
	}

	@Override
	public List<InternDetailsVO> getMoreDetails(Long internId) {
		InternDetailsVO internDetailsVO = new InternDetailsVO();
		InternDetails internDetails = internDetailsRepository.findOne(internId);
		internDetailsVO.setInternshipTitle(internDetails.getInternshipTitle());
		internDetailsVO.setDuration(internDetails.getDuration());
		internDetailsVO.setPosition(internDetails.getPosition());
		internDetailsVO.setVacancies(internDetails.getVacancies());
		internDetailsVO.setInternshipDescription(internDetails.getInternshipDescription());
		internDetailsVO.setPerks(internDetails.getPerks());
		internDetailsVO.setInternshipType(internDetails.getInternshipType());

		CompanyProfile companyDetails = companyProfileRepository.findByUserId(internDetails.getUserId());
		internDetailsVO.setCompanyEmail(companyDetails.getCompanyEmail());
		internDetailsVO.setCompanyName(companyDetails.getCompanyName());
		internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
		internDetailsVO.setCompanyDescription(companyDetails.getCompanyDescription());
		List<String> listCategories = internDetailsSkillsRepository.findByInternshipId(internDetails, "Skills");

		if (listCategories != null) {
			String keyAndValue = "";
			for (String strSkillName : listCategories) {
				if (keyAndValue.equals("")) {
					keyAndValue = keyAndValue + strSkillName;
				} else {
					keyAndValue = keyAndValue + "," + strSkillName;
				}

				internDetailsVO.setSkillNames(keyAndValue);

			}
			List<String> listStream = internDetailsSkillsRepository.findByInternshipId(internDetails, "Stream");
			String stream = "";
			for (String strStream : listStream) {
				if (stream.equals("")) {
					stream = stream + strStream;
				} else {
					stream = stream + "," + strStream;
				}
				internDetailsVO.setStreamNames(stream);
			}
		}
		List<InternDetailsVO> listDetails = new ArrayList<InternDetailsVO>();
		listDetails.add(internDetailsVO);
		return listDetails;
	}

	@Override
	@Transactional(readOnly = false)
	public List<InternDetailsVO> searchByCompany(Long searchCompany) throws InternException {
		try {
			char isDeleted = AppConstants.NO;
			InternDetails intern = internDetailsRepository.findByInternDetailId(searchCompany, isDeleted);
			User user = userRepository.findOne(intern.getUserId().getId());
			List<InternDetails> internDetailsList = internDetailsRepository.findInternByUser(user, isDeleted);
			List<InternDetailsVO> internDetailsVOList = new ArrayList<InternDetailsVO>();
			for (InternDetails internDetails : internDetailsList) {
				if (internDetails.getPostStatus().equals('A')) {
					InternDetailsVO internDetailsVO = new InternDetailsVO(internDetails);
					internDetailsVO.setUserId(internDetails.getUserId());
					String appdate = internDetails.getApplyDate().toString();
					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getApplyDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						appdate = format.format(db);

					} catch (Exception ex) {
						appdate = internDetails.getApplyDate().toString();
					}
					internDetailsVO.setApplyDate(appdate);
					String enddate = internDetails.getEndDate().toString();
					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getEndDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						enddate = format.format(db);
					} catch (Exception ex) {
						enddate = internDetails.getEndDate().toString();
					}
					internDetailsVO.setEndDate(enddate);
					String date = internDetails.getStartAndEndDate().toString();
					try {
						Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
								.parse(internDetails.getStartAndEndDate().toString());
						SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
						date = format.format(db);

					} catch (Exception ex) {
						date = internDetails.getStartAndEndDate().toString();
					}
					internDetailsVO.setStartAndEndDate(date);
					User userId = internDetails.getUserId();
					char deleted = AppConstants.NO;
					UserContact useraddr = userContactRepository.findContactByUser(userId, deleted);
					internDetailsVO.setUserCity(useraddr.getUserCity());
					internDetailsVO.setUserAddress(useraddr.getUserAddress());
					CompanyProfile companyDetails = companyProfileRepository.findProfileByUser(userId, deleted);
					internDetailsVO.setCompanyName(companyDetails.getCompanyName());
					internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
					internDetailsVO.setCompanyEmail(companyDetails.getCompanyEmail());
					internDetailsVOList.add(internDetailsVO);
				}
			}

			return internDetailsVOList;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_NO_SEARCH_RESULTS, ex);
			throw new InternException(AppConstants.NO_RESULTS_FOUND);
		}

	}

}

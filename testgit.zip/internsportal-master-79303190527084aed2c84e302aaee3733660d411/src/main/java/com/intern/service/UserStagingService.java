package com.intern.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.intern.dto.UserStagingVO;
import com.intern.entity.User;
import com.intern.entity.UserStaging;

@Service
public interface UserStagingService {

	UserStagingVO saveUserDetails(UserStagingVO userStagingVO); 

	UserStagingVO getUser(Long userStagingId);

	List<UserStagingVO> approveUsers();
}

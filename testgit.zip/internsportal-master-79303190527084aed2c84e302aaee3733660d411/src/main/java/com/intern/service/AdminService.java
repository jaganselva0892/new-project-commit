package com.intern.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.intern.dto.AppListItemsVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.HomeVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.UserVO;
import com.intern.entity.InternDetails;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.exception.InternException;

@Service
public interface AdminService {

	AppListItemsVO saveCategoryDetails(AppListItemsVO appListItemsVO);

	void deletePost(Long internId);

	void deleteUser(Long userId);

	UserVO editUsersProfile(Long userId);

	void approveUser(Long userId);

	void approvePost(Long internId);

	void approveUserRequest(Long userStagingId);

	void deleteUserRegister(Long userStagingId);

	List<HomeVO> getinternshipDetails();

	void downloadResume(Long userId,HttpServletResponse response)  throws IOException, InternException ;

	void sendQueries(HomeVO homeVO);

	List<StudentDetailsVO> getStudentDetailsToView(Long userId);

	void activateOrDeactiveUser(Long userId);

	void activateOrDeactivePost(Long internId);

	List<StudentDetailsVO> getUserDetails(Long userId);

	//StudentProfile getUserId(Long attachId);
	
	//String listUserApprovalPendings();
	
}

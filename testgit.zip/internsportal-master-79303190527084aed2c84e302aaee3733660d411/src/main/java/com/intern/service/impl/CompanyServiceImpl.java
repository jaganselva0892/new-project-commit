package com.intern.service.impl;

import java.text.SimpleDateFormat;
import java.text.DateFormat;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.jsoup.Connection.Request;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.service.CompanyService;
import com.intern.service.StudentService;
import com.intern.auditor.AuditorAwareService;
import com.intern.dto.AppliedHistoryVO;
import com.intern.dto.AttachmentsVO;
import com.intern.dto.CompanyProfileVO;
import com.intern.dto.InternDetailsVO;
import com.intern.dto.StudentDetailsVO;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.StudentsSkillsVO;
import com.intern.entity.AppListItems;
import com.intern.entity.AppliedHistory;
import com.intern.entity.Attachments;
import com.intern.entity.CompanyProfile;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.logging.LogManager;
import com.intern.logging.Logger;
import com.intern.repository.AppListItemsRepository;
import com.intern.repository.AppliedHistoryRepository;
import com.intern.repository.AttachmentsRepository;
import com.intern.repository.CompanyProfileRepository;
import com.intern.repository.InternDetailsRepository;
import com.intern.repository.InternDetailsSkillsRepository;
import com.intern.repository.StudentProfileRepository;
import com.intern.repository.StudentsSkillsRepository;
import com.intern.repository.UserContactRepository;
import com.intern.repository.UserRepository;
import com.intern.utils.AppConstants;
import com.intern.utils.CommonUtils;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	HttpSession httpSession;

	@Autowired
	CompanyService companyService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserContactRepository userContactRepository;

	@Autowired
	CompanyProfileRepository companyProfileRepository;

	@Autowired
	StudentProfileRepository studentProfileRepository;

	@Autowired
	StudentsSkillsRepository studentSkillsRepository;

	@Autowired
	InternDetailsRepository internDetailsRepository;

	@Autowired
	AppListItemsRepository appListItemsRepository;

	@Autowired
	AppliedHistoryRepository appliedHistoryRepository;

	@Autowired
	AuditorAwareService auditorAwareService;

	@Autowired
	AttachmentsRepository attachmentsRepository;

	@Autowired
	InternDetailsSkillsRepository internDetailsSkillsRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserStagingServiceImpl.class.getName();
	private static final String METHOD_SAVE_DETAILS = "saveUserDetails";

	@Override
	@Transactional(readOnly = false)
	public CompanyProfileVO getCompanyProfile() {

		char isDeleted = AppConstants.NO;
		User loginUser = auditorAwareService.getCurrentAuditor();
		CompanyProfile companyProfile = companyProfileRepository.findProfileByUser(loginUser, AppConstants.NO);
		UserContact userContact = userContactRepository.findContactByUser(loginUser, AppConstants.NO);
		CompanyProfileVO companyProfileVO = new CompanyProfileVO(companyProfile, userContact);
		Attachments attachments = attachmentsRepository.findByUserWithType(loginUser, "logo", isDeleted);
		if (attachments != null) {
			AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
			companyProfileVO.setAttachmentsVO(attachmentsVO);
			String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			String imgSrc = "data:image/" + fileExtension + ";base64," + base64String;
			companyProfileVO.setLogoBaseString(imgSrc);
			companyProfileVO.setIsLogo(AppConstants.YES);
		}
		return companyProfileVO;
	}
	// =======
	// User loginUser = (User)
	// httpSession.getAttribute(AppConstants.LOGIN_USER);
	// try {
	// CompanyProfile companyProfile =
	// companyProfileRepository.findProfileByUser(loginUser, AppConstants.NO);
	// UserContact userContact =
	// userContactRepository.findContactByUser(loginUser, AppConstants.NO);
	// CompanyProfileVO companyProfileVO = new CompanyProfileVO(companyProfile,
	// userContact);
	// // Attachments attachments =
	// // attachmentsRepository.findByUserWithType(loginUser, "logo",
	// // AppConstants.NO);
	// // if (attachments != null) {
	// // AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
	// // companyProfileVO.setAttachmentsVO(attachmentsVO);
	// // String base64String = new
	// // sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
	// // String fileExtension =
	// // CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
	// // String imgSrc =
	// // "data:image/"+fileExtension+";base64,"+base64String;
	// // companyProfileVO.setLogoBaseString(imgSrc);
	// // companyProfileVO.setIsLogo(AppConstants.YES);
	// // }
	// return companyProfileVO;
	// } catch (Exception ex) {
	// ex.printStackTrace();
	// return null;
	// }
	// >>>>>>> 58edc42c54faa2ec29b3c7a8829d57c6e27a0e55

	// }
	// @Override
	// @Transactional(readOnly = false)
	// public InternDetailsVO editIntenrDetails() {
	// InternDetails internDetails = new InternDetails();
	// List<AppListItems> skillRequired = appListItemsRepository.findBySkill();
	// return new InternDetailsVO(internDetails, skillRequired);
	//
	// }

	@Override
	@Transactional(readOnly = false)
	public CompanyProfileVO saveCompanyDetails(CompanyProfileVO companyProfileVO) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		User user = new User();
		CompanyProfile companyProfile;
		try {

			if (companyProfileVO.isNew()) {
				companyProfile = new CompanyProfile();
			} else {

				companyProfile = companyProfileRepository.findOne(companyProfileVO.getId());
				companyProfileVO.setUserId(loginUser);
			}
			UserContact userContact;
			userContact = userContactRepository.findContactByUser(loginUser, AppConstants.NO);

			// companyProfileVO.setUserCode(user.getUserCode());
			if (userContact == null) {
				userContact = new UserContact();
			}

			userContact.setUserId(loginUser);
			userContact.setMobileNumber(companyProfileVO.getMobileNumber());
			userContact.setUserAddress(companyProfileVO.getUserAddress());
			userContact.setUserCity(companyProfileVO.getUserCity());
			// userContact.setUserState(companyProfileVO.getUserState());
			// userContact.setUserCountry(companyProfileVO.getUserCountry());
			userContact.setUserState("Tamil Nadu");
			userContact.setUserCountry("India");
			BeanUtils.copyProperties(companyProfileVO, companyProfile);

			companyProfile.setCompanyProfileStatus('N');
			companyProfile.setIsActive(companyProfileVO.getIsCompanyActive() ? AppConstants.YES : AppConstants.NO);
			companyProfile = companyProfileRepository.save(companyProfile);
			userContact = userContactRepository.save(userContact);

			companyProfileVO.setId(companyProfile.getId());

			return companyProfileVO;

		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_SAVE_DETAILS, ex);
			return null;
		}

	}

	// @Override
	// public List<InternDetails> getInternshipPost() {
	// User loginUser = (User)
	// httpSession.getAttribute(AppConstants.LOGIN_USER);
	// char isDeleted = AppConstants.NO;
	// List<InternDetails> listPostInternships =
	// internDetailsRepository.listPostedInternships(loginUser, isDeleted);
	// return listPostInternships;
	// }

	@Override
	public InternDetailsVO editPostedInternships(Long internId) {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		try {

			InternDetails internDetails = internDetailsRepository.findOne(internId);
			InternDetailsVO internDetailsVO = new InternDetailsVO(internDetails);
			internDetailsVO.setInternshipTitle(internDetails.getInternshipTitle());
			List<String> listCategories = internDetailsSkillsRepository.findByInternshipId(internDetails, "Skills");

			if (listCategories != null) {
				String keyAndValue = "";
				for (String strSkillName : listCategories) {
					if (keyAndValue.equals("")) {
						keyAndValue = keyAndValue + strSkillName;
					} else {
						keyAndValue = keyAndValue + "," + strSkillName;
					}

					internDetailsVO.setSkillsRequired(keyAndValue);
				}
			}

			List<String> listStreamCategories = internDetailsSkillsRepository.findByInternshipId(internDetails,
					"Stream");

			if (listCategories != null) {
				String keyAndValue = "";
				for (String strStreamName : listStreamCategories) {
					if (keyAndValue.equals("")) {
						keyAndValue = keyAndValue + strStreamName;
					} else {
						keyAndValue = keyAndValue + "," + strStreamName;
					}

					internDetailsVO.setEligibility(keyAndValue);
				}
			}

			// internDetailsVO.setSkillsRequired(internDetails.getSkillsRequired());
			internDetailsVO.setDuration(internDetails.getDuration());
			internDetailsVO.setStipend(internDetails.getStipend());
			internDetailsVO.setInternshipType(internDetails.getInternshipType());
			// internDetailsVO.setApplyDate(internDetails.getApplyDate());
			// internDetailsVO.setEndDate(internDetails.getEndDate());
			// internDetailsVO.setStartAndEndDate(internDetails.getStartAndEndDate());
			String appdate = internDetails.getApplyDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(internDetails.getApplyDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				appdate = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				appdate = internDetails.getApplyDate().toString();
			}
			internDetailsVO.setApplyDate(appdate);
			String enddate = internDetails.getEndDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(internDetails.getEndDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				enddate = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				enddate = internDetails.getEndDate().toString();
			}
			internDetailsVO.setEndDate(enddate);
			String date = internDetails.getStartAndEndDate().toString();

			try {
				Date db = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
						.parse(internDetails.getStartAndEndDate().toString());
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
				date = format.format(db);
				// date = new SimpleDateFormat("MM/dd/yyyy").format(db);
				// Date dob = new Date(str);

			} catch (Exception ex) {
				date = internDetails.getStartAndEndDate().toString();
			}
			internDetailsVO.setStartAndEndDate(date);
			List<AppListItems> skillRequired = appListItemsRepository.findBySkill();
			internDetailsVO.setSkillRequired(skillRequired);
			List<AppListItems> streamRequired = appListItemsRepository.findByStream();
			internDetailsVO.setStreamRequired(streamRequired);
			internDetailsVO.setPosition(internDetails.getPosition());
			internDetailsVO.setVacancies(internDetails.getVacancies());
			List<CompanyProfile> companyProfile = companyProfileRepository
					.findProfileDetailsByUser(internDetails.getUserId(), AppConstants.NO);
			for (CompanyProfile companyDetails : companyProfile) {
				internDetailsVO.setCompanyName(companyDetails.getCompanyName());
				internDetailsVO.setCompanyWebsite(companyDetails.getCompanyWebsite());
				internDetailsVO.setCompanyEmail(companyDetails.getCompanyEmail());
			}
			UserContact userDetails = userContactRepository.findByUserId(loginUser);
			internDetailsVO.setUserAddress(userDetails.getUserAddress());
			// InternDetailsVO internDetailVO = new
			// InternDetailsVO(internDetails,
			// companyProfile);
			return internDetailsVO;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;

		}

	}

	@Override
	public List<InternDetailsVO> getPostedInternships() {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		char isDeleted = AppConstants.NO;
		List<InternDetailsVO> listPostInternships = internDetailsRepository.listPostedInternships(loginUser, isDeleted);
		return listPostInternships;
	}

	@Override
	public void deleteInternPost(Long internId) {
		internDetailsRepository.deleteByInternId(internId);
	}

	@Override
	public CompanyProfileVO getCompanyDetails(Long userId) {
		User users = userRepository.findOne(userId);
		try {
			CompanyProfileVO companyProfileVO = new CompanyProfileVO();
			User Id = userRepository.findOne(users.getId());
			CompanyProfile companyProfile = companyProfileRepository.findByUserId(Id);
			companyProfileVO.setId(companyProfile.getId());
			UserContact userContact = userContactRepository.findByUserId(companyProfile.getUserId());
			companyProfileVO = new CompanyProfileVO(companyProfile, userContact);

			// Attachments attachments =
			// attachmentsRepository.findByUserWithType(users, "logo",
			// AppConstants.NO);
			// if (attachments != null) {
			// AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
			// companyProfileVO.setAttachmentsVO(attachmentsVO);
			// String base64String = new
			// sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			// String fileExtension =
			// CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			// String imgSrc =
			// "data:image/"+fileExtension+";base64,"+base64String;
			// companyProfileVO.setLogoBaseString(imgSrc);
			// companyProfileVO.setIsLogo(AppConstants.YES);
			// }

			return companyProfileVO;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<AppliedHistoryVO> getStudentAppliedHistory() {
		User loginUser = (User) httpSession.getAttribute(AppConstants.LOGIN_USER);
		try {
			char isDeleted = AppConstants.NO;
			List<AppliedHistoryVO> studentAppliedHistory = new ArrayList<AppliedHistoryVO>();
			List<InternDetails> listPostInternships = internDetailsRepository.listActiveInternships(loginUser,
					isDeleted);

			List<AppliedHistory> listDetails = appliedHistoryRepository.listAppliedInternships(AppConstants.NO);
			for (AppliedHistory appDetails : listDetails) {
				if (listPostInternships.contains(appDetails.getInternDetails())) {
					List<StudentProfile> listStudentDetails = studentProfileRepository
							.findstudentProfileByUser(appDetails.getUserId(), AppConstants.NO);
					List<InternDetails> internList = internDetailsRepository
							.findByInternId(appDetails.getInternDetails().getId());
					for (InternDetails interndetails : internList) {
						AppliedHistoryVO appliedHistory = new AppliedHistoryVO();
						appliedHistory.setInternshipTitle(interndetails.getInternshipTitle());
						for (StudentProfile studentDetails : listStudentDetails) {
							appliedHistory.setStudentEmail(studentDetails.getStudentEmail());
							appliedHistory.setStudentFieldExperience(studentDetails.getStudentFieldExperience());
							appliedHistory.setUserId(studentDetails.getUserId().getId());
							appliedHistory.setId(appDetails.getId());
							StudentProfile studentId = studentProfileRepository.findOne(studentDetails.getId());
							List<StudentsSkills> studentSkillsList = studentSkillsRepository.findByStream(studentId,
									"Stream");
							for (StudentsSkills studentsSkills : studentSkillsList) {
								appliedHistory.setStreamName(studentsSkills.getSkillName());
							}
						}
						studentAppliedHistory.add(appliedHistory);
					}
				}

			}

			return studentAppliedHistory;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<StudentDetailsVO> getStudentDetails(Long userId) {
		User user = userRepository.findOne(userId);
		try {

			StudentProfile studentProfile = studentProfileRepository.findByUserId(user);
			StudentProfile studentId = studentProfileRepository.findOne(studentProfile.getId());
			UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
			List<String> skillList = studentSkillsRepository.findBySkills(studentId, "Skills");
			List<StudentsSkills> stream = studentSkillsRepository.findByStream(studentId, "Stream");

			StudentDetailsVO studentDetailsVO = new StudentDetailsVO(studentProfile, skillList, stream, userContact);
			List<StudentDetailsVO> listStudentDetails = new ArrayList<StudentDetailsVO>();
			listStudentDetails.add(studentDetailsVO);
			return listStudentDetails;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	@Override
	public List<CompanyProfileVO> getCompanyDetailsToView(Long userId) {
		User user = userRepository.findOne(userId);
		CompanyProfile companyProfile = companyProfileRepository.findProfileByUser(user, AppConstants.NO);
		UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
		CompanyProfileVO companyProfileVO = new CompanyProfileVO(companyProfile, userContact);
		Attachments attachments = attachmentsRepository.findByUserWithType(user, "logo", AppConstants.NO);
		companyProfileVO.setIsLogo(AppConstants.NO);
		if (attachments != null) {
			AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
			companyProfileVO.setAttachmentsVO(attachmentsVO);
			String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
			String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
			String imgSrc = "data:image/" + fileExtension + ";base64," + base64String;
			companyProfileVO.setLogoBaseString(imgSrc);
			companyProfileVO.setIsLogo(AppConstants.YES);
		}
		companyProfileVO.setUserCountry("India");
		List<CompanyProfileVO> companyDetailsList = new ArrayList<CompanyProfileVO>();
		companyDetailsList.add(companyProfileVO);
		return companyDetailsList;
	}

	@Override
	public String listCompanies() {
		char isDeleted = AppConstants.NO;
		List<CompanyProfile> listCompanies = companyProfileRepository.listActiveCompanies(isDeleted);
		String listActiveCompanies = Integer.toString(listCompanies.size());
		return listActiveCompanies;
	}

	@Override
	@Transactional(readOnly = false)
	public List<CompanyProfileVO> getCompanyDetailsAndLogo() {

		char isDeleted = AppConstants.NO;
		List<CompanyProfileVO> listCompanies = new ArrayList<CompanyProfileVO>();
		List<User> listUser = userRepository.findByUserCode("Company", AppConstants.NO);
		for (User user : listUser) {
			CompanyProfile companyProfile = companyProfileRepository.findProfileByUser(user, AppConstants.NO);
			UserContact userContact = userContactRepository.findContactByUser(user, AppConstants.NO);
			CompanyProfileVO companyProfileVO = new CompanyProfileVO(companyProfile, userContact);
			Attachments attachments = attachmentsRepository.findByUserWithType(user, "logo", isDeleted);
			if (attachments != null) {
				AttachmentsVO attachmentsVO = new AttachmentsVO(attachments);
				companyProfileVO.setAttachmentsVO(attachmentsVO);
				String base64String = new sun.misc.BASE64Encoder().encode(attachmentsVO.getAttachmentData());
				String fileExtension = CommonUtils.getFileNameWithOutExtenstion(attachmentsVO.getFileName());
				String imgSrc = "data:image/" + fileExtension + ";base64," + base64String;
				companyProfileVO.setLogoBaseString(imgSrc);
				companyProfileVO.setIsLogo(AppConstants.YES);
				listCompanies.add(companyProfileVO);
			}
		}
		return listCompanies;
	}

}

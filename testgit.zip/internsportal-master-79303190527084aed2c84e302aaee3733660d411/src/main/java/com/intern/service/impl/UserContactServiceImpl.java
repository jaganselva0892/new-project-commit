package com.intern.service.impl;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.intern.service.StudentService;
import com.intern.service.UserStagingService;
import com.intern.dto.StudentProfileVO;
import com.intern.dto.UserStagingVO;
import com.intern.entity.AppListItems;
import com.intern.entity.StudentProfile;
import com.intern.repository.AppListItemsRepository;
import com.intern.utils.AppConstants;

import com.intern.service.UserContactService;

@Service
public class UserContactServiceImpl  implements UserContactService {

}

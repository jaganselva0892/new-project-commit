package com.intern.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.intern.dto.UserVO;
import com.intern.entity.User;
import com.intern.exception.InternException;

@Service
public interface UserService {

	List<User> listUsers();

	String listUsersCount();

	List<UserVO> listusers();

	void getEmailId(String LoginId) throws InternException;

	UserVO changeUserPassword(UserVO userVO) throws InternException;

	void updateUserActiveStatus(UserVO userVO);

	//String listUserApprovalPendings();

}

package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.dto.InternDetailsVO;
import com.intern.entity.InternDetails;
import com.intern.entity.User;

public interface InternDetailsRepository extends JpaRepository<InternDetails, Long> {

	@Query("from InternDetails a where a.isActive = ?1")
	List<InternDetails> listActivePosts(char isActive);

	@Query("from InternDetails a where a.deleted = ?1")
	List<InternDetails> listInternDetails(char deleted);

	@Query("from InternDetails a where a.deleted = ?1 Order by a.createdDate desc")
	List<InternDetails> listActiveInternships(char isDeleted);

	@Query("select a from InternDetails a where a.userId = ?1 and a.deleted = ?2")
	List<InternDetails> listActiveInternships(User user, char isDeleted);

	@Query("from InternDetails a where a.userId = ?1")
	InternDetails findByUserId(User userId);

	@Query("select a from InternDetails a where a.userId = ?1 and a.deleted = ?2")
	List<InternDetails> findInternByUser(User user, char deleted);

	@Query("select a from InternDetails a where a.internshipType LIKE CONCAT('%',?1,'%') and a.deleted = ?2")
	List<InternDetails> findByType(String internshipType, char deleted);

	@Query("select a from InternDetails a where a.userId = ?1 and a.deleted = ?2")
	List<InternDetailsVO> listPostedInternships(User loginUser, char isDeleted);

	@Query("select a from InternDetails a where a.userId = ?1 and a.deleted = ?2")
	List<InternDetails> findByLoginId(User loginUser, char no);

	@Modifying
	@Transactional
	@Query("Update InternDetails i set i.deleted = 'Y' where i.id = ?1")
	int deleteByInternId(Long internId);

	@Modifying
	@Transactional
	@Query("Update AppliedHistory i set i.deleted = 'Y' where i.id = ?1")
	int deleteInternByInternId(Long applyHistoryId);

	@Query("from InternDetails a where a.id = ?1")
	InternDetailsVO findById(Long internId);

	@Modifying
	@Transactional
	@Query("Update InternDetails i set i.postStatus = 'A' where i.id = ?1")
	int saveInternStatus(Long internId);

	@Query("select a from InternDetails a where a.id = ?1")
	List<InternDetails> findByInternId(Long id);

	@Query("select a from InternDetails a JOIN FETCH a.userId where a.id = ?1")
	InternDetails findByInternDetailsId(Long id);

	@Query("from InternDetails a where a.postStatus = ?1")
	List<InternDetails> listPostPendings(char postStatus);

	@Modifying
	@Transactional
	@Query("Update InternDetails i set i.isActive = 'N' where i.id = ?1")
	int updateDeActiveStatus(Long internId);

	@Modifying
	@Transactional
	@Query("Update InternDetails i set i.isActive = 'Y' where i.id = ?1")
	int updateActiveStatus(Long internId);

	// @Query("SELECT app FROM InternDetails app WHERE app.appListItemsName LIKE
	// CONCAT('%',?1,'%')")
	// List<InternDetails> findByAppListItemsName(String applistitemsName);

	@Query("from InternDetails a where a.id = ?1 and a.deleted = ?2")
	InternDetails findByInternDetailId(Long internId, char isDeleted);

	@Query("from InternDetails a where a.deleted = ?1")
	List<InternDetails> findAll(char isDeleted);

}

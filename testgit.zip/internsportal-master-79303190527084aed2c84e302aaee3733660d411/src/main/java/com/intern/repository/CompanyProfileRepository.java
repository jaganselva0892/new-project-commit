package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.entity.CompanyProfile;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;

public interface CompanyProfileRepository extends JpaRepository<CompanyProfile, Long> {

	@Query("select a from CompanyProfile a where a.userId = ?1 and a.deleted=?2")
	CompanyProfile findProfileByUser(User user, char isDeleted);

	@Query("select a from CompanyProfile a where  a.deleted=?1")
	List<CompanyProfile> listAllUsers(char isDeleted);

	@Query("select a from CompanyProfile a where a.userId = ?1 and a.deleted=?2")
	List<CompanyProfile> findProfileDetailsByUser(User userId, char no);

	@Query("select a from CompanyProfile a where a.userId = ?1")
	CompanyProfile findByUserId(User userId);

	@Modifying
	@Transactional
	@Query("Update CompanyProfile i set i.companyProfileStatus = 'A' where i.userId = ?1")
	int saveCompanyStatus(User id);

	@Query("from CompanyProfile a where a.companyProfileStatus = ?1")
	List<CompanyProfile> listComUserPendings(char companyProfileStatus);

	@Query("select a from CompanyProfile a where a.userId = ?1")
	List<CompanyProfile> findByProfileId(User userId);

	@Query("select a from CompanyProfile a where a.deleted = ?1")
	List<CompanyProfile> listActiveCompanies(char isDeleted);

	@Modifying
	@Transactional
	@Query("Update CompanyProfile i set i.deleted = 'Y' where i.userId = ?1")
	int deleteByuserId(User id);

}

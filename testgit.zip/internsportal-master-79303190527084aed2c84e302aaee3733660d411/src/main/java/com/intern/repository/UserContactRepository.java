package com.intern.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserContact;
import com.intern.entity.UserStaging;

public interface UserContactRepository  extends JpaRepository<UserContact, Long>{

	@Query("select a from UserContact a where a.userId = ?1 and a.deleted=?2")
	UserContact findContactByUser(User user, char isDeleted);
	
	@Query("select a from UserContact a where a.userCity  LIKE CONCAT('%',?1,'%') and a.deleted=?2")
	List<UserContact> findContactByCity(String userCity, char isDeleted);

	@Query("select a from UserContact a where a.deleted=?1")
	List<UserContact> listContacts(char isDeleted);

	@Query("select a from UserContact a where a.userId = ?1")
	UserContact findByUserId(User userId);	
	
}

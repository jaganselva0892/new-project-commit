package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.dto.StudentsSkillsVO;
import com.intern.entity.AppListItems;
import com.intern.entity.StudentProfile;
import com.intern.entity.StudentsSkills;
import com.intern.entity.User;
import com.intern.entity.UserContact;

public interface StudentsSkillsRepository extends JpaRepository<StudentsSkills, Long> {

	@Query("select s from StudentsSkills s where s.studentProfileId = ?1 and s.deleted=?2")
	StudentsSkills findSkillByUser(StudentProfile studentProfileId, char isDeleted);

	@Query("select s from StudentsSkills s where s.streamName = ?1")
	StudentsSkillsVO findByStream(String streamName);

	@Query("select s from StudentsSkills s where s.studentProfileId = ?1 and s.deleted=?2")
	List<StudentsSkills> findByStudentId(StudentProfile studentProfileId, char isDeleted);

	@Query("select s from StudentsSkills s where s.studentProfileId = ?1 and s.type=?2")
	List<StudentsSkills> findBySkill(StudentProfile studentId, String type);

	@Query("select s from StudentsSkills s where s.studentProfileId = ?1 and s.type=?2")
	List<StudentsSkills> findByStream(StudentProfile studentId, String type);

	@Query("select  skillName from StudentsSkills s where s.studentProfileId = ?1 and s.type=?2")
	List<String> findBySkills(StudentProfile studentId, String string);

	@Query("select  skillName from StudentsSkills s where s.studentProfileId = ?1")
	List<StudentsSkills> findSkillById(StudentProfile id);
}

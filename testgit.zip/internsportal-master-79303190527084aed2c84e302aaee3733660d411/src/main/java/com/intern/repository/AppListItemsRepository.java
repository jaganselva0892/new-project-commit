package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.entity.AppListItems;

public interface AppListItemsRepository extends JpaRepository<AppListItems, Long> {

	@Query("SELECT app FROM AppListItems app WHERE app.appListItemsName LIKE CONCAT('%',?1,'%')")
	List<AppListItems> findByAppListItemsName(String applistitemsName);

	@Query("select a from AppListItems a where  a.appListItemsName = ?1")
	AppListItems  findByStream(String appListItemsName);
	
	@Query("select  a from AppListItems a where a.appListItemsType='?1'")
	List<AppListItems> findByStreamName(String skills);

	@Query("select a from AppListItems a where a.appListItemsType='?1'")
	List<AppListItems> findBySkillName(String stream);

	@Query("select  a from AppListItems a where a.appListItemsType='Stream'")
	List<AppListItems> findByStream();
	
	@Query("select a from AppListItems a where a.appListItemsType='Skills'")
	List<AppListItems> findBySkill();
}
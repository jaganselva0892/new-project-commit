package com.intern.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.entity.AppListItems;
import com.intern.entity.Attachments;
import com.intern.entity.User;


public interface AttachmentsRepository extends JpaRepository<Attachments, Long>{

	@Query("select a from Attachments a where a.userId = ?1 and a.attachmentType = ?2 and a.deleted = ?3")
	Attachments findByUserWithType(User userId, String type, char isDeleted);
	
}

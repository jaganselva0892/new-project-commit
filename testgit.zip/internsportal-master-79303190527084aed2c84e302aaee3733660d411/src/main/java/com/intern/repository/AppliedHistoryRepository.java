package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.entity.AppliedHistory;
import com.intern.entity.InternDetails;
import com.intern.entity.User;

public interface AppliedHistoryRepository extends JpaRepository<AppliedHistory, Long>{

	@Query("select a from AppliedHistory a where a.userId = ?1 and a.deleted = ?2")
	List<AppliedHistory> findByUser(User user, char deleted);

	@Query("select a from AppliedHistory a where a.deleted = ?1")
	List<AppliedHistory> listAppliedInternships(char deleted);
	
	@Modifying
	@Transactional
	@Query("Update AppliedHistory i set i.deleted = 'Y' where i.id = ?1")
	int deleteByAppliedHistoryId(Long appliedHistoryId);
	
	@Query("select a from AppliedHistory a where a.userId = ?1 AND a.internDetails = ?3 and a.deleted = ?2")
	List<AppliedHistory> findByUserInterDetail(User user, char deleted, InternDetails internDetails);

	
}

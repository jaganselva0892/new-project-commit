package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.entity.User;
import com.intern.entity.UserStaging;

public interface UserStagingRepository extends JpaRepository<UserStaging, Long> {

	public User findByuserEmailId(String userEmailId);

	@Query("from UserStaging a where a.deleted = ?1 Order by a.createdDate desc")
	List<UserStaging> findNewUsers(char isDeleted);

	@Modifying
	@Transactional
	@Query("Update UserStaging i set i.userStatus = 'Approved' where i.id = ?1")
	int findByUserStagingId(Long userStagingId);

	@Query("from UserStaging a where a.id = ?1")
	UserStaging findById(Long userStagingId);

	@Modifying
	@Transactional
	@Query("Update UserStaging i set i.userStatus = 'Rejected' where i.id = ?1")
	int deleteById(Long userStagingId);
}

package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.entity.AppListItems;
import com.intern.entity.InternDetails;
import com.intern.entity.InternDetailsSkills;
import com.intern.entity.User;

public interface InternDetailsSkillsRepository extends JpaRepository<InternDetailsSkills, Long> {

	@Query("select i from InternDetailsSkills i where i.deleted = ?1 and i.category LIKE CONCAT('%',?2,'%')")
	List<InternDetailsSkills> findByCategory(char isDeleted, String categoryName);

	// @Query("select i from InternDetailsSkills i where i.category LIKE
	// CONCAT('%',?1,'%')")
	// List<InternDetailsSkills> findByCategory(String categoryName);

	@Query("select i from InternDetailsSkills i where i.category IN (?1,?2)")
	List<InternDetailsSkills> findByCategoryName(String skillsName, String streamsName);

	@Query("select category from InternDetailsSkills i where i.internDetailsId = ?1 ")
	List<InternDetailsSkills> findById(InternDetails id);

	@Query("select i from InternDetailsSkills i where i.internDetailsId = ?1 ")
	List<InternDetailsSkills> findByInternDetailsId(InternDetails id);

	
	@Query("select category from InternDetailsSkills i where i.internDetailsId = ?1 and i.categoryType = ?2")
	List<String> findByInternshipId(InternDetails id, String catagoryType);

	

	// @Query("select s from StudentsSkills s where s.userId = ?1 and
	// s.deleted=?2")
	// InternDetailsSkills findSkillByUser(User user, char isDeleted);
}

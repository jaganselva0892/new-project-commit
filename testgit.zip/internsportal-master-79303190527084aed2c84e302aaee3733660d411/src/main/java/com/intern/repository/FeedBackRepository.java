package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.entity.AppListItems;
import com.intern.entity.FeedBack;

public interface FeedBackRepository extends JpaRepository<FeedBack, Long> {

}

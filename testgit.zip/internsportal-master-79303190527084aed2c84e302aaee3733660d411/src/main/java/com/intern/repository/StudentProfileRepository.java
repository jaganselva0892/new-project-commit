package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.entity.StudentProfile;
import com.intern.entity.User;
import com.intern.entity.UserStaging;

public interface StudentProfileRepository extends JpaRepository<StudentProfile, Long> {

	@Query("select a from StudentProfile a where a.userId = ?1 and a.deleted=?2")
	StudentProfile findProfileByUser(User user, char isDeleted);

	@Query("select a from StudentProfile a where  a.deleted=?1")
	List<StudentProfile> listStudents(char no);

	@Query("select a from StudentProfile a where a.userId = ?1 and a.deleted=?2")
	List<StudentProfile> findstudentProfileByUser(User userId, char no);

	@Query("select a from StudentProfile a where a.userId = ?1")
	StudentProfile findByUserId(User userId);

	@Modifying
	@Transactional
	@Query("Update StudentProfile i set i.deleted = 'Y' where i.id = ?1")
	String saveIsActive(char c);

	@Modifying
	@Transactional
	@Query("Update StudentProfile i set i.studentProfileStatus = 'A' where i.userId = ?1")
	int saveStudentStatus(User userId);

	@Query("from StudentProfile a where a.studentProfileStatus = ?1")
	List<StudentProfile> listUserPendings(char studentProfileStatus);

	@Query("from StudentProfile a where a.deleted = ?1")
	List<StudentProfile> listActiveStudents(char isDeleted);

	@Modifying
	@Transactional
	@Query("Update StudentProfile i set i.deleted = 'Y' where i.userId = ?1")
	int deleteByuserId(User userId);

	

}

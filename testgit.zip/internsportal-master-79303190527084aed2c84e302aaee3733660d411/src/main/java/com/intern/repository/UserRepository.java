package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.intern.dto.UserVO;
import com.intern.entity.InternDetails;
import com.intern.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	@Query("select u from User u where u.userCode = ?1")
	User getUserCode(String userCode);

	@Query("select u from User u where u.loginId = ?1")
	User getAdminUserbyEmail(String email);

	public User findByLoginId(String loginId);

	@Query("select u from User u where u.password = ?1")
	String getPassword(String password);

	// public User findByLoginId();
	// @Query("from User a where a.isActive = ?1")
	// List<Integer> count(char isActive);

	@Query("from User a where a.isActive = ?1 and a.deleted=?2")
	List<User> listActiveUsers(char isActive, char isDeleted);

	@Query("from User a where a.deleted = ?1 Order by a.createdDate desc")
	List<User> listUsers(char isDeleted);

	@Modifying
	@Transactional
	@Query("Update User i set i.deleted = 'Y' where i.id = ?1")
	int deleteByuserId(Long userId);

	@Query("select a from User a where a.id = ?1")
	User findByUserId(Long userId);

	@Query("select a from User a where a.deleted = ?1")
	List<UserVO> listAllUsers(char isDeleted);

	// @Modifying
	// @Query(value = "UPDATE users SET password = ?2 WHERE user_id = ?1",
	// nativeQuery = true)
	// int updatePassword(Long userId, String password);

	@Modifying
	@Query(value = "UPDATE users  SET password = ?2 WHERE email_id = ?1", nativeQuery = true)
	int updatePassword(String LoginId, String password);

	@Modifying
	@Transactional
	@Query("Update User i set i.isActive = 'N' where i.id = ?1")
	int updateDeActiveStatus(Long userId);

	@Modifying
	@Transactional
	@Query("Update User i set i.isActive = 'Y' where i.id = ?1")
	int updateActiveStatus(Long userId);

	@Query("select a from User a where a.userCode = ?1 and a.deleted = ?2")
	List<User> findByUserCode(String userCode, char isDeleted);

	// @Query("from User a where a.isActive = ?1")
	// List<User> listUserPendings(char isActive);

}

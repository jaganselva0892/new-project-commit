package com.intern.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.intern.entity.InternshipHistory;
import com.intern.entity.StudentProfile;
import com.intern.entity.User;

public interface InternshipHistoryRepository extends JpaRepository<InternshipHistory, Long>  {

//	@Query("SELECT app FROM InternDetails app WHERE app.appListItemsName LIKE CONCAT('%',?1,'%')")
//	List<InternshipHistory> findByAppListItemsName(String applistitemsName);
}


package com.intern.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CommonUtils {

	public static String getFileNameWithOutExtenstion(String fileName) {
		return fileName.substring(0, fileName.lastIndexOf(AppConstants.DOT_SEPARATOR));
	}
	
	public static Date getCustomDateFormat(String dateString, String dateFormat){
		 try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);
			Date customDate = dateFormatter.parse(dateString);
			return customDate;
		} catch (Exception e) {
			return null;
		}
	}

}


package com.intern.utils;

import org.springframework.data.domain.Sort;

public class AppConstants {

	public static final String SEARCH_BY_CATEGORY = "SearchByCategory";
	public static final String SEARCH_BY_SKILL = "SearchBySkill";
	public static final char NO = 'N';
	public static final char YES = 'Y';
	public static final char NEW = 'N';
	public static final String UI_MESSAGE = "message";

	public static final String EMPTY_STRING = "";
	public static final String LOGIN_USER = "loginUser";
	public static final String LEFT_SIDE = "leftSide";
	public static final String SEARCH_BY_TYPE = "searchByType";
	public static final String USER_LIST_COUNT = "userListCount";
	public static final String LIST_ACTIVE_USERS = "listActivePosts";
	public static final String USER_APPROVAL_PENDINGS = "userApprovalPendings";
	public static final String COMPANY_APPROVAL_PENDINGS = "companyApprovalPendings";
	public static final String POST_APPROVAL_PENDINGS = "postApprovalPendings";
	public static final String HYPEN_SEPARATOR = "-";
	public static final String STUDENT_ROLE = "Student";
	public static final String COMPANY_ROLE = "Company";
	public static final String USER_CODE = "psType";
	public static final String ADMIN_ROLE = "Admin";

	public static final String DOT_SEPARATOR = ".";
	public static final String MSG_NO_RESUME_FOUND = "No Resume Found";
	public static final String MSG_ACCOUNT_NOT_ACTIVE = "Your account is not active. Please contact system admin.";
	public static final String MSG_USER_NOT_FOUND = "Your account is not valid!";
	public static final String RESET_PWD_SUCCESS = "Your new password has been updated. Please login with your new password.";
	public static final String LIST_ACTIVE_STUDENTS = "listActiveStudents";
	public static final String LIST_ACTIVE_COMPANIES = "listActiveCompanies";
	public static final String RESPONSE_ATTACH_PREFIX = "attachment; filename=\"";
	public static final String RESPONSE_ATTACH_SUFFIX = "\";";
	public static final String NO_RESULTS_FOUND = "No Results Found";
	public static final String SEARCH_RESULTS = "Search Results";
}

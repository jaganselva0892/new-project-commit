package com.intern.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.util.Date;

import org.joda.time.DateTime;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "company_profile")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "company_profile_id")) })
public class CompanyProfile extends BaseEntity {

	private static final long serialVersionUID = -5802290778765117882L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_company_1"))
	private User userId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_code", foreignKey = @ForeignKey(name = "fk_company_2"))
	private User userCode;
	
	@Column(name = "company_name", length = 80)
	private String companyName;
	
	@Column(name = "company_shorttname", length = 80)
	private String companyShortName;
	
	@Column(name = "company_email", length = 80)
	private String companyEmail;
	
	@Column(name = "company_alternate_email", length = 80)
	private String companyAlternateEmail;
	
	@Column(name = "company_website", length = 80)
	private String companyWebsite;
	
	@Column(name = "company_description", length = 80)
	private String companyDescription;
	
	@Column(name = "company_profile_status", length = 80)
	private Character companyProfileStatus;
	
	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CompanyProfile other = (CompanyProfile) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	
	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public User getUserCode() {
		return userCode;
	}

	public void setUserCode(User userCode) {
		this.userCode = userCode;
	}
	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyShortName() {
		return companyShortName;
	}

	public void setCompanyShortName(String companyShortName) {
		this.companyShortName = companyShortName;
	}
	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}
	public String getCompanyAlternateEmail() {
		return companyAlternateEmail;
	}

	public void setCompanyAlternateEmail(String companyAlternateEmail) {
		this.companyAlternateEmail = companyAlternateEmail;
	}
	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}
	public Character getCompanyProfileStatus() {
		return companyProfileStatus;
	}

	public void setCompanyProfileStatus(Character companyProfileStatus) {
		this.companyProfileStatus = companyProfileStatus;
	}
	
	
}

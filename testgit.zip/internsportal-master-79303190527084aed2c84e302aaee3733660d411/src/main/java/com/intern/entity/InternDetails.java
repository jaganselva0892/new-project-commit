package com.intern.entity;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "intern_details")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "intern_details_id")) })

public class InternDetails extends BaseEntity {

	private static final long serialVersionUID = -159342444163040959L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, unique = true, foreignKey = @ForeignKey(name = "fk_users"))
	private User userId;

	@Column(name = "internship_title", length = 40)
	private String internshipTitle;

	@Column(name = "posted_date", length = 40)
	private Date postedDate;

	@Column(name = "internship_type", length = 40)
	private String internshipType;

	//@Temporal(TemporalType.DATE)
	@Column(name = "end_date", length = 40)
	private Date endDate;
	
	//@Temporal(TemporalType.DATE)
	@Column(name = "apply_date", length = 40)
	private Date applyDate;

	@Column(name = "duration", length = 40)
	private String duration;

	@Column(name = "stipend", length = 40)
	private String stipend;

	@Column(name = "position", length = 40)
	private String position;

	@Column(name = "eligibility", length = 40)
	private String eligibility;

	@Column(name = "skills_required", length = 40)
	private String skillsRequired;

	@Column(name = "vacancies", length = 40)
	private String vacancies;

	@Column(name = "paid_or_unpaid", length = 40)
	private String paidOrUnpaid;

	@Column(name = "industry", length = 40)
	private String industry;

	@Column(name = "category", length = 40)
	private String category;

//	@Temporal(TemporalType.DATE)
	@Column(name = "start_and_end_date", length = 40)
	private Date startAndEndDate;

	@Column(name = "internship_description", length = 40)
	private String internshipDescription;

	@Column(name = "perks", length = 40)
	private String perks;

	@Column(name = "postStatus", nullable = false)
	private Character postStatus;





	/********************** hashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		InternDetails other = (InternDetails) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public String getInternshipTitle() {
		return internshipTitle;
	}

	public void setInternshipTitle(String internshipTitle) {
		this.internshipTitle = internshipTitle;
	}

	public Date getPostedDate() {
		return postedDate;
	}

	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}

	public String getInternshipType() {
		return internshipType;
	}

	public void setInternshipType(String internshipType) {
		this.internshipType = internshipType;
	}

	public Date getApplyDate() {
		return applyDate;
	}

	public void setApplyDate(Date applyDate) {
		this.applyDate = applyDate;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getStipend() {
		return stipend;
	}

	public void setStipend(String stipend) {
		this.stipend = stipend;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getSkillsRequired() {
		return skillsRequired;
	}

	public void setSkillsRequired(String skillsRequired) {
		this.skillsRequired = skillsRequired;
	}

	public String getVacancies() {
		return vacancies;
	}

	public void setVacancies(String vacancies) {
		this.vacancies = vacancies;
	}

	public String getPaidOrUnpaid() {
		return paidOrUnpaid;
	}

	public void setPaidOrUnpaid(String paidOrUnpaid) {
		this.paidOrUnpaid = paidOrUnpaid;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getStartAndEndDate() {
		return startAndEndDate;
	}

	public void setStartAndEndDate(Date startAndEndDate) {
		this.startAndEndDate = startAndEndDate;
	}

	public String getInternshipDescription() {
		return internshipDescription;
	}

	public void setInternshipDescription(String internshipDescription) {
		this.internshipDescription = internshipDescription;
	}

	public String getPerks() {
		return perks;
	}

	public void setPerks(String perks) {
		this.perks = perks;
	}
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Character getPostStatus() {
		return postStatus;
	}

	public void setPostStatus(Character postStatus) {
		this.postStatus = postStatus;
	}

}

package com.intern.entity;

import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "applied_history")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "applied_history_id")) })
public class AppliedHistory extends BaseEntity {


	private static final long serialVersionUID = -1698128607676556841L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_usertable"))
	private User userId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "intern_details_id", nullable = false, foreignKey = @ForeignKey(name = "fk_interndetailtable"))
	private InternDetails internDetails;

	@Column(name = "applied_status", length = 20)
	private String appliedStatus;

	@Column(name = "view_count", length = 20)
	private Long viewCount;

	/********************** hashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppliedHistory other = (AppliedHistory) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public InternDetails getInternDetails() {
		return internDetails;
	}

	public void setInternDetails(InternDetails internDetails) {
		this.internDetails = internDetails;
	}

	public String getAppliedStatus() {
		return appliedStatus;
	}

	public void setAppliedStatus(String appliedStatus) {
		this.appliedStatus = appliedStatus;
	}

	public Long getViewCount() {
		return viewCount;
	}

	public void setViewCount(Long viewCount) {
		this.viewCount = viewCount;
	}

}

package com.intern.entity;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.joda.time.DateTime;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "student_profile")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "student_profile_id")) })
public class StudentProfile extends BaseEntity {

	private static final long serialVersionUID = -3229736745155707874L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_student_1"))
	private User userId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_code", foreignKey = @ForeignKey(name = "fk_student_2"))
	private User userCode;

//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "user_stagging_id", nullable = false, foreignKey = @ForeignKey(name = "fk_student_3"))
//	private UserStaging userStaggingId;

	@Column(name = "student_firstname", length = 80)
	private String studentFirstName;

	@Column(name = "student_lastname", length = 80)
	private String studentLastName;
	

	@Column(name = "student_email", length = 80, unique = true)
	private String studentEmail;

	@Column(name = "student_alternate_email", length = 80, unique = true)
	private String studentAlternateEmail;

	@Column(name = "student_institution_name", length = 80)
	private String studentInstitutionName;

	@Column(name = "student_work_status")
	private Character studentWorkStatus;

	@Column(name = "student_fieldexperience", length = 80)
	private String studentFieldExperience;

	@Column(name = "student_gender")
	private String studentGender;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "student_dateofbirth", length = 80)
	private Date studentDateOfBirth;

	@Column(name = "student_profile_status")
	private Character studentProfileStatus;

	@Column(name = "student_yearofpassing", length = 80)
	private Long studentYearOfPassing;

	@Column(name = "student_adharcardnumber", length = 80)
	private String studentAdharCardNumber;

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		StudentProfile other = (StudentProfile) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	public User getUserCode() {
		return userCode;
	}

	public void setUserCode(User userCode) {
		this.userCode = userCode;
	}

//	public UserStaging getUserStaggingId() {
//		return userStaggingId;
//	}
//
//	public void setUserStaggingId(UserStaging userStaggingId) {
//		this.userStaggingId = userStaggingId;
//	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}
	
	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentAlternateEmail() {
		return studentAlternateEmail;
	}

	public void setStudentAlternateEmail(String studentAlternateEmail) {
		this.studentAlternateEmail = studentAlternateEmail;
	}

	public String getStudentInstitutionName() {
		return studentInstitutionName;
	}

	public void setStudentInstitutionName(String studentInstitutionName) {
		this.studentInstitutionName = studentInstitutionName;
	}

	public Character getStudentWorkStatus() {
		return studentWorkStatus;
	}

	public void setStudentWorkStatus(Character studentWorkStatus) {
		this.studentWorkStatus = studentWorkStatus;
	}

	public String getStudentFieldExperience() {
		return studentFieldExperience;
	}

	public void setStudentFieldExperience(String studentFieldExperience) {
		this.studentFieldExperience = studentFieldExperience;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public Date getStudentDateOfBirth() {
		return studentDateOfBirth;
	}

	public void setStudentDateOfBirth(Date studentDateOfBirth) {
		this.studentDateOfBirth = studentDateOfBirth;
	}

	public Character getStudentProfileStatus() {
		return studentProfileStatus;
	}

	public void setStudentProfileStatus(Character studentProfileStatus) {
		this.studentProfileStatus = studentProfileStatus;
	}

	public Long getStudentYearOfPassing() {
		return studentYearOfPassing;
	}

	public void setStudentYearOfPassing(Long studentYearOfPassing) {
		this.studentYearOfPassing = studentYearOfPassing;
	}
	
	public String getStudentAdharCardNumber() {
		return studentAdharCardNumber;
	}

	public void setStudentAdharCardNumber(String studentAdharCardNumber) {
		this.studentAdharCardNumber = studentAdharCardNumber;
	}
}

package com.intern.entity;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "users")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "user_id")) })
public class User extends BaseEntity {

	private static final long serialVersionUID = 5744338912408041094L;
	
	public static final String USER_TYPE_ADMIN_ROLES = "Admin";
	public static final String USER_TYPE_COMPANY = "Company";
	public static final String USER_TYPE_STUDENT = "Student";

	public static final char ACTIVE = 'A';
	public static final char INACTIVE = 'I';
	public static final char LOCKED = 'L';

	@Column(name = "email_id", length = 40, nullable = false, unique = true)
	private String loginId;

	@Column(name = "password", length = 100, unique = true)
	private String password;

	@Column(name = "user_code", length = 40, nullable = false, unique = true)
	private String userCode;

	@Column(name = "date_lastlogin", length = 40, nullable = true, unique = true)
	private Date dateLastLogin;

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		User other = (User) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public Date getDateLastLogin() {
		return dateLastLogin;
	}

	public void setDateLastLogin(Date dateLastLogin) {
		this.dateLastLogin = dateLastLogin;
	}

}

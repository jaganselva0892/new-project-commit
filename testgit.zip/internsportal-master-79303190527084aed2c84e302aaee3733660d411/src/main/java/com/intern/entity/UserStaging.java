package com.intern.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "users_stagging")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "user_stagging_id")) })
public class UserStaging extends BaseEntity {

	private static final long serialVersionUID = 6228470842427311754L;

	public static final int NAME_MAX_LENGTH = 20;
	public static final String STATUS_NEW = "New";

	@Column(name = "user_name", length = 40, nullable = false)
	private String userName;

	@Column(name = "user_code")
	private String userCode;

	@Column(name = "user_emailid", length = 40)
	private String userEmailId;

	@Column(name = "password", length = 100, nullable = false)
	private String password;

	@Column(name = "user_organization", length = 40)
	private String userOrganization;

	@Column(name = "user_mobilenumber", length = 40)
	private String userMobileNumber;

	@Column(name = "user_status")
	private String userStatus;

	@Column(name = "stu_aadhar_card_no", length = 80)
	private String studentAdharCardNumber;

	@Column(name = "com_website", length = 80)
	private String companyWebsite;

	/********************** hashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserStaging other = (UserStaging) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getPassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public String getUserOrganization() {
		return userOrganization;
	}

	public void setUserOrganization(String userOrganization) {
		this.userOrganization = userOrganization;
	}

	public String getUserMobileNumber() {
		return userMobileNumber;
	}

	public void setUserMobileNumber(String userMobileNumber) {
		this.userMobileNumber = userMobileNumber;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getStudentAdharCardNumber() {
		return studentAdharCardNumber;
	}

	public void setStudentAdharCardNumber(String studentAdharCardNumber) {
		this.studentAdharCardNumber = studentAdharCardNumber;
	}

	public String getCompanyWebsite() {
		return companyWebsite;
	}

	public void setCompanyWebsite(String companyWebsite) {
		this.companyWebsite = companyWebsite;
	}
}

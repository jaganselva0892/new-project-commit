package com.intern.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "students_skills")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "skills_id")) })
public class StudentsSkills extends BaseEntity {

	private static final long serialVersionUID = 2816681297009439296L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "student_profile_id", nullable = false, foreignKey = @ForeignKey(name = "students_skills_ibfk_1"))
	private StudentProfile studentProfileId;

	@Column(name = "skill_name", length = 80)
	private String skillName;

	@Column(name = "stream_name", length = 80)
	private String streamName;
	
	@Column(name = "type", length = 80)
	private String type;

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		StudentsSkills other = (StudentsSkills) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public StudentProfile getStudentProfileId() {
		return studentProfileId;
	}

	public void setStudentProfileId(StudentProfile studentProfileId) {
		this.studentProfileId = studentProfileId;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}

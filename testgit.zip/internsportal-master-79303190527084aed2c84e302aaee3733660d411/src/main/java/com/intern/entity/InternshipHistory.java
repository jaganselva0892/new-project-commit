package com.intern.entity;
import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
@Entity
@Table(name = "internship_history")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "internship_history_id")) })
public class InternshipHistory extends BaseEntity {

/**
	 * 
	 */
	private static final long serialVersionUID = -2178067392574224659L;

//private static final long serialVersionUID = -159342444163040959L;


	@Column(name = "user_code", length = 40, nullable = false,  unique = true)
	private String userCode;

	@Column(name = "user_stagging_id", length = 40, nullable = false, unique = true)
	private String userStaggingId;

	@Column(name = "intern_details_id", length = 40, nullable = false, unique = true)
	private String internDetailsId;
	
	@Column(name = "user_status", length = 40)
	private String userStatus;

	@Column(name = "intern_post_status", length = 40)
	private String internPostStatus;

	@Column(name = "user_approval_status", length = 40)
	private String userApprovalStatus;
	
	@Column(name = "intern_approval_status", length = 40)
	private String internApprovalStatus;
	
	@Column(name = "user_permissions", length = 40)
	private String userPermissions;
	
	@Column(name = "user_permission_type", length = 40)
	private String userPermissionType;
	
	@Column(name = "about_details", length = 40)
	private String aboutDetails;
	
	@Column(name = "user_contact_id", length = 40)
	private String userContactId;
	
	@Column(name = "contact_details", length = 40)
	private String contactDetails;
	
	@Column(name = "is_expired", length = 40)
	private Date isExpired;
	
	@Column(name = "user_approval_date", length = 40)
	private Date userApprovalDate;
	
	@Column(name = "intern_post_approval_date", length = 40)
	private Date internPostApprovalDate;
	

	/********************** hashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		InternshipHistory other = (InternshipHistory) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserStaggingId() {
		return userStaggingId;
	}

	public void setUserStaggingId(String userStaggingId) {
		this.userStaggingId = userStaggingId;
	}

	public String getInternDetailsId() {
		return internDetailsId;
	}

	public void setInternDetailsId(String internDetailsId) {
		this.internDetailsId = internDetailsId;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	
	public String getInternPostStatus() {
		return internPostStatus;
	}

	public void setInternPostStatus(String internPostStatus) {
		this.internPostStatus = internPostStatus;
	}
	
	public String getUserApprovalStatus() {
		return userApprovalStatus;
	}

	public void setUserApprovalStatus(String userApprovalStatus) {
		this.userApprovalStatus = userApprovalStatus;
	}
	
	public String getInternApprovalStatus() {
		return internApprovalStatus;
	}

	public void setInternApprovalStatus(String internApprovalStatus) {
		this.internApprovalStatus = internApprovalStatus;
	}
	
	public String getUserPermissions() {
		return userPermissions;
	}

	public void setUserPermissions(String userPermissions) {
		this.userPermissions = userPermissions;
	}
	public String getUserPermissionType() {
		return userPermissionType;
	}

	public void setUserPermissionType(String userPermissionType) {
		this.userPermissionType = userPermissionType;
	}
	
	public String getAboutDetails() {
		return aboutDetails;
	}

	public void setAboutDetails(String aboutDetails) {
		this.aboutDetails = aboutDetails;
	}
	
	public String getUserContactId() {
		return userContactId;
	}

	public void setUserContactId(String userContactId) {
		this.userContactId = userContactId;
	}
	public String getContactDetails() {
		return contactDetails;
	}

	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}
		
	public Date getIsExpired() {
		return isExpired;
	}

	public void setIsExpired(Date isExpired) {
		this.isExpired = isExpired;
	}
	
	public Date getUserApprovalDate() {
		return userApprovalDate;
	}

	public void setUserApprovalDate(Date userApprovalDate) {
		this.userApprovalDate = userApprovalDate;
	}
	
	public Date getInternPostApprovalDate() {
		return internPostApprovalDate;
	}

	public void setInternPostApprovalDate(Date internPostApprovalDate) {
		this.internPostApprovalDate = internPostApprovalDate;
	}
}

package com.intern.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "app_list_items")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_list_items_id")) })
public class AppListItems extends BaseEntity {

	private static final long serialVersionUID = -3422830464510211652L;
	public static final int NAME_MAX_LENGTH = 150;

	@Column(name = "app_list_items_type", length = 150)
	private String appListItemsType;

	@Column(name = "app_list_items_name", length = 150)
	private String appListItemsName;

	/******************* HashCode and Equals Methods ************************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppListItems dblog = (AppListItems) obj;
		return new EqualsBuilder().append(this.getId(), dblog.getId()).isEquals();
	}

	/**************** Getter and Setter *************************/

	public String getAppListItemsType() {
		return appListItemsType;
	}

	public void setAppListItemsType(String appListItemsType) {
		this.appListItemsType = appListItemsType;
	}

	public String getAppListItemsName() {
		return appListItemsName;
	}

	public void setAppListItemsName(String appListItemsName) {
		this.appListItemsName = appListItemsName;
	}

}

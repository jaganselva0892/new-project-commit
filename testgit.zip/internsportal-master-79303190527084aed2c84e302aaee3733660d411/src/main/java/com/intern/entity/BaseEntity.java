package com.intern.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import com.intern.entity.User;
import com.intern.utils.AppConstants;
//import com.intern.utils.EncryptionUtils;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import org.joda.time.DateTime;
import org.springframework.data.domain.Auditable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@MappedSuperclass
@EntityListeners({ AuditingEntityListener.class })
public class BaseEntity implements Auditable<User, Long> {

	private static final long serialVersionUID = -8795442643129623L;

	@Id
	@GeneratedValue
	private Long id;

	@Transient
	private String encryptedId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", nullable = false)
	private User createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date", nullable = false)
	private Date createdDate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "modified_by", nullable = false)
	private User lastModifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified_date", nullable = false)
	private Date lastModifiedDate;

	@Column(name = "is_deleted", nullable = false)
	private Character deleted = AppConstants.NO;

	@Column(name = "is_active", nullable = false)
	private Character isActive = AppConstants.YES;

	/********************** HashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		BaseEntity other = (BaseEntity) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** toString methods **********************/
	@Override
	public String toString() {
		return String.format("%s [id = %d]", this.getClass().getName(), this.getId());
	}

	/********************** Transient **********************/

	@Transient
	public boolean isNew() {
		return null == getId();
	}

	/********************** Getters and Setters **********************/

	public Long getId() {
		return id;
	}

	protected void setId(final Long id) {
		this.id = id;
	}

//	public String getEncryptedId() {
//		if (encryptedId == null) {
//			setEncryptedId(EncryptionUtils.encryptId(id));
//		}
//		return encryptedId;
//	}

	public User getCreatedBy() {
		// User user1 = new User();
		// user1.setId(Long.parseLong("2"));
		// return createdBy == null ? user1 : createdBy;
		return createdBy;
	}

	public void setCreatedBy(final User createdBy) {
		this.createdBy = createdBy;
	}

	public DateTime getCreatedDate() {
		return null == createdDate ? null : new DateTime(createdDate);
	}

	public void setCreatedDate(final DateTime createdDate) {
		this.createdDate = null == createdDate ? null : createdDate.toDate();
	}

	public User getLastModifiedBy() {
		// User user1 = new User();
		// user1.setId(Long.parseLong("2"));
		// return lastModifiedBy == null ? user1 : lastModifiedBy;
		return lastModifiedBy;
	}

	public void setLastModifiedBy(final User lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public DateTime getLastModifiedDate() {
		return null == lastModifiedDate ? null : new DateTime(lastModifiedDate);
	}

	public void setLastModifiedDate(final DateTime lastModifiedDate) {
		this.lastModifiedDate = null == lastModifiedDate ? null : lastModifiedDate.toDate();
	}

	public Character getIsDeleted() {
		return deleted;
	}

	public void setIsDeleted(final Character deleted) {
		this.deleted = deleted;
	}

	public Character getIsActive() {
		return isActive;
	}

	public void setIsActive(final Character isActive) {
		this.isActive = isActive;
	}

}

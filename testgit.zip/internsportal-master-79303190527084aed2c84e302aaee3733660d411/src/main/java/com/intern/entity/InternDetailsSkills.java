package com.intern.entity;

import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;


@Entity
@Table(name = "intern_details_skills")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "intern_details_skills")) })
public class InternDetailsSkills extends BaseEntity {


	private static final long serialVersionUID = -6554637034878093879L;

	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "intern_details_id", nullable = false, foreignKey = @ForeignKey(name = "fk_intern_details_id"))
	private InternDetails internDetailsId;

	@Column(name = "category", length = 20)
	private String category;
	
	@Column(name = "category_type", length = 20)
	private String categoryType;


	/********************** hashCode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		InternDetailsSkills other = (InternDetailsSkills) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	
	public InternDetails getInternDetailsId() {
		return internDetailsId;
	}

	public void setInternDetailsId(InternDetails internDetailsId) {
		this.internDetailsId = internDetailsId;
	}
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}	
	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}	
}

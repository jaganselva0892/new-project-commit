package com.intern.interceptors;

import java.io.Serializable;
import java.util.Iterator;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Interceptor;
import org.hibernate.type.Type;

public class StaticDelegateInterceptor extends EmptyInterceptor {

	private static final long serialVersionUID = 8811755406572418773L;

	private static Interceptor interceptor;

	public static void setInterceptor(Interceptor interceptor) {
		StaticDelegateInterceptor.interceptor = interceptor;
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		return StaticDelegateInterceptor.interceptor.onSave(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		return StaticDelegateInterceptor.interceptor.onFlushDirty(entity, id, currentState, previousState,
				propertyNames, types);
	}

	@Override
	public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		StaticDelegateInterceptor.interceptor.onDelete(entity, id, state, propertyNames, types);
	}

	// called after committed into database
	@Override
	public void postFlush(@SuppressWarnings("rawtypes") Iterator iterator) {
		StaticDelegateInterceptor.interceptor.postFlush(iterator);
	}
}

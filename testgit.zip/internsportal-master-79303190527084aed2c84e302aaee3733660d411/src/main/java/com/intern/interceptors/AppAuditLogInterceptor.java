package com.intern.interceptors;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class AppAuditLogInterceptor extends EmptyInterceptor {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7739524886579116102L;

	@PostConstruct
	public void init() {
		StaticDelegateInterceptor.setInterceptor(this);
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		return false;
	}

	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {

		return false;
	}

	@Override
	public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {

	}

	// called after committed into database
	@Override
	public void postFlush(@SuppressWarnings("rawtypes") Iterator iterator) {
		try {

		} finally {

		}
	}

	@Transactional
	private void processList(Set<Object> processSet, String process) {
		
	}

}
